package de.mossgrabers.convertwithmoss.compat.sound;

import java.io.IOException;
import java.io.InputStream;


/** Stream of audio data with a format (replacement for javax.sound.sampled.AudioInputStream). */
public class AudioInputStream extends InputStream
{
    private final InputStream stream;
    private final AudioFormat format;
    private final long        frameLength;


    /**
     * Constructor.
     *
     * @param stream The raw audio data
     * @param format The format of the data
     * @param frameLength The number of frames, -1 if not known
     */
    public AudioInputStream (final InputStream stream, final AudioFormat format, final long frameLength)
    {
        this.stream = stream;
        this.format = format;
        this.frameLength = frameLength;
    }


    /**
     * Get the format.
     *
     * @return The format
     */
    public AudioFormat getFormat ()
    {
        return this.format;
    }


    /**
     * Get the number of frames.
     *
     * @return The frames, -1 if not known
     */
    public long getFrameLength ()
    {
        return this.frameLength;
    }


    /** {@inheritDoc} */
    @Override
    public int read () throws IOException
    {
        return this.stream.read ();
    }


    /** {@inheritDoc} */
    @Override
    public int read (final byte [] b, final int off, final int len) throws IOException
    {
        return this.stream.read (b, off, len);
    }


    /** {@inheritDoc} */
    @Override
    public int available () throws IOException
    {
        return this.stream.available ();
    }


    /** {@inheritDoc} */
    @Override
    public void close () throws IOException
    {
        this.stream.close ();
    }
}
