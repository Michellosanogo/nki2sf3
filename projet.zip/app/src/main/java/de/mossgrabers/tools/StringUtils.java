package de.mossgrabers.tools;

import java.util.ArrayList;
import java.util.List;


/** String helper functions (compatible re-implementation for Android). */
public class StringUtils
{
    private static final char [] REMOVABLE_CHARS =
    {
        ' ', '_', '-', 'a', 'e', 'i', 'o', 'u'
    };


    private StringUtils ()
    {
        // Intentionally empty
    }


    /**
     * Split a text at commas and trim the parts.
     *
     * @param text The text
     * @return The parts
     */
    public static String [] splitByComma (final String text)
    {
        return split (text, ",");
    }


    /**
     * Split a text at the given delimiter and trim the parts.
     *
     * @param text The text
     * @param delimiter The delimiter
     * @return The parts
     */
    public static String [] split (final String text, final String delimiter)
    {
        if (text == null || text.isBlank ())
            return new String [0];
        final List<String> result = new ArrayList<> ();
        for (final String part: text.split (java.util.regex.Pattern.quote (delimiter)))
        {
            final String trimmed = part.trim ();
            if (!trimmed.isEmpty ())
                result.add (trimmed);
        }
        return result.toArray (new String [0]);
    }


    /**
     * Pad a text with spaces on the left.
     *
     * @param str The text
     * @param n The number of spaces to add
     * @return The padded text
     */
    public static String padLeftSpaces (final String str, final int n)
    {
        final int width = str.length () + n;
        final StringBuilder sb = new StringBuilder (width);
        for (int i = 0; i < n; i++)
            sb.append (' ');
        return sb.append (str).toString ();
    }


    /**
     * Shorten a name to the given length by removing characters.
     *
     * @param name The name
     * @param maxLength The maximum length
     * @return The shortened name
     */
    public static String optimizeName (final String name, final int maxLength)
    {
        if (name == null)
            return "";
        String result = name;
        for (final char c: REMOVABLE_CHARS)
        {
            if (result.length () <= maxLength)
                return result;
            int index;
            while ((index = result.indexOf (c)) != -1)
            {
                result = result.substring (0, index) + result.substring (index + 1);
                if (result.length () <= maxLength)
                    return result;
            }
        }
        return result.length () <= maxLength ? result : result.substring (0, maxLength);
    }


    /**
     * Replace all non-ASCII characters with ASCII equivalents.
     *
     * @param text The text
     * @return The ASCII text
     */
    public static String fixASCII (final String text)
    {
        if (text == null)
            return "";
        final StringBuilder sb = new StringBuilder ();
        for (int i = 0; i < text.length (); i++)
        {
            final char c = text.charAt (i);
            if (c <= 127)
            {
                sb.append (c);
                continue;
            }
            switch (c)
            {
                case 196 -> sb.append ("Ae");
                case 228 -> sb.append ("ae");
                case 214, 338 -> sb.append ("Oe");
                case 246, 339 -> sb.append ("oe");
                case 220 -> sb.append ("Ue");
                case 252 -> sb.append ("ue");
                case 223 -> sb.append ("ss");
                case 233 -> sb.append ("e");
                case 8594 -> sb.append ("->");
                case 9839 -> sb.append ("#");
                default -> sb.append ("?");
            }
        }
        return sb.toString ();
    }


    /**
     * Remove everything after the first zero character.
     *
     * @param text The text
     * @return The text up to the first zero
     */
    public static String removeCharactersAfterZero (final String text)
    {
        final int index = text.indexOf ('\u0000');
        return index < 0 ? text : text.substring (0, index);
    }


    /**
     * Format a byte array for logging.
     *
     * @param data The data
     * @return The text
     */
    public static String formatArray (final byte [] data)
    {
        if (data.length == 0)
            return "[]";
        final StringBuilder sb = new StringBuilder ("[");
        for (int i = 0; i < data.length; i++)
        {
            if (i > 0)
                sb.append (", ");
            sb.append (data[i]);
        }
        return sb.append (']').toString ();
    }


    /**
     * Format a byte array as hex numbers for logging.
     *
     * @param data The data
     * @return The text
     */
    public static String formatHexStr (final byte [] data)
    {
        final StringBuilder sb = new StringBuilder ();
        for (int i = 0; i < data.length; i++)
        {
            if (i > 0)
                sb.append (' ');
            sb.append (String.format ("%02X", Integer.valueOf (data[i] & 0xFF)));
        }
        return sb.toString ();
    }


    /**
     * Format an integer as a hex number for logging.
     *
     * @param value The value
     * @return The text
     */
    public static String formatHexStr (final int value)
    {
        return String.format ("%X", Integer.valueOf (value));
    }
}
