// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.core.model;

import java.util.Date;

import de.mossgrabers.convertwithmoss.core.settings.IMetadataConfig;


/**
 * Several descriptive fields for a multi-sample.
 *
 * @author Jürgen Moßgraber
 */
public interface IMetadata
{
    /**
     * Get a description of the multi-sample.
     *
     * @return The description
     */
    String getDescription ();


    /**
     * Get the creator (author) of the multi-sample.
     *
     * @return The creator
     */
    String getCreator ();


    /**
     * Get the date/time when the multi-sample was created.
     *
     * @return The date/time
     */
    Date getCreationDateTime ();


    /**
     * Get the sound category of the multi-sample.
     *
     * @return The category
     */
    String getCategory ();


    /**
     * Get the keywords of the multi-sample.
     *
     * @return The keywords
     */
    String [] getKeywords ();


    /**
     * Set the description.
     *
     * @param description The description
     */
    void setDescription (String description);


    /**
     * Set the creator (author).
     *
     * @param creator The creator (author) of the multi-sample
     */
    void setCreator (String creator);


    /**
     * Set the date/time when the multi-sample was created.
     *
     * @param time The date/time
     */
    void setCreationDateTime (Date time);


    /**
     * Set the category.
     *
     * @param category The sound category of the multi-sample
     */
    void setCategory (String category);


    /**
     * Set the keywords.
     *
     * @param keywords The keywords of the multi-sample
     */
    void setKeywords (String... keywords);


    /**
     * Adds a keyword to the keyword list.
     *
     * @param keyword The keyword to add
     */
    void addKeyword (String keyword);


    /**
     * Detect metadata (creator, category, keywords) from the given text parts.
     *
     * @param configuration Some configuration settings
     * @param parts The text parts
     */
    void detectMetadata (IMetadataConfig configuration, String [] parts);


    /**
     * Detect metadata (creator, category, keywords) from the given text parts.
     *
     * @param configuration Some configuration settings
     * @param parts The text parts
     * @param category If the category is not null, it is assigned and not detected
     */
    void detectMetadata (IMetadataConfig configuration, String [] parts, String category);


    /**
     * Detect metadata (creator, category, keywords) from the given text parts of the multi-sample
     * and the names of the folders which contain it. A folder name only provides keywords if it
     * describes the sound of its content (e.g. 'Analog Synths') and not if it is the title of a
     * library.
     *
     * @param configuration Some configuration settings
     * @param parts The text parts of the multi-sample itself, e.g. its name
     * @param folderNames The names of the folders which contain the multi-sample, the innermost
     *            first
     * @param category If the category is not null, it is assigned and not detected
     */
    void detectMetadata (IMetadataConfig configuration, String [] parts, String [] folderNames, String category);
}
