package com.nki2sf2.app;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.documentfile.provider.DocumentFile;

import de.mossgrabers.convertwithmoss.android.NkiToSf2Converter;


/**
 * Simple screen: choose the folder with the NKI files, choose the output folder, convert.
 */
public class MainActivity extends Activity
{
    private static final int REQUEST_SOURCE = 1;
    private static final int REQUEST_OUTPUT = 2;
    private static final int MAX_LOG_CHARS  = 20000;

    private Uri              sourceUri;
    private Uri              outputUri;
    private TextView         sourceLabel;
    private TextView         outputLabel;
    private Button           convertButton;
    private ProgressBar      progress;
    private TextView         logView;
    private ScrollView       logScroll;
    private final StringBuilder logText = new StringBuilder ();


    @Override
    protected void onCreate (final Bundle savedInstanceState)
    {
        super.onCreate (savedInstanceState);

        final int pad = (int) (16 * getResources ().getDisplayMetrics ().density);
        final LinearLayout root = new LinearLayout (this);
        root.setOrientation (LinearLayout.VERTICAL);
        root.setPadding (pad, pad * 2, pad, pad);

        final TextView title = new TextView (this);
        title.setText ("NKI vers SF2");
        title.setTextSize (24);
        root.addView (title);

        final TextView help = new TextView (this);
        help.setText ("Convertit des instruments Kontakt (.nki) non protégés en SoundFont (.sf2).\n"
                + "Le dossier source doit contenir les .nki ET leurs fichiers audio.");
        help.setPadding (0, pad / 2, 0, pad);
        root.addView (help);

        final Button sourceButton = new Button (this);
        sourceButton.setText ("1. Choisir le dossier des NKI");
        sourceButton.setOnClickListener (v -> this.pickFolder (REQUEST_SOURCE));
        root.addView (sourceButton);
        this.sourceLabel = new TextView (this);
        this.sourceLabel.setText ("Aucun dossier choisi");
        root.addView (this.sourceLabel);

        final Button outputButton = new Button (this);
        outputButton.setText ("2. Choisir le dossier de sortie");
        outputButton.setOnClickListener (v -> this.pickFolder (REQUEST_OUTPUT));
        root.addView (outputButton);
        this.outputLabel = new TextView (this);
        this.outputLabel.setText ("Aucun dossier choisi");
        root.addView (this.outputLabel);

        this.convertButton = new Button (this);
        this.convertButton.setText ("3. Convertir");
        this.convertButton.setEnabled (false);
        this.convertButton.setOnClickListener (v -> this.startConversion ());
        root.addView (this.convertButton);

        this.progress = new ProgressBar (this, null, android.R.attr.progressBarStyleHorizontal);
        this.progress.setIndeterminate (true);
        this.progress.setVisibility (View.GONE);
        root.addView (this.progress);

        this.logScroll = new ScrollView (this);
        this.logView = new TextView (this);
        this.logView.setTextSize (12);
        this.logView.setTextIsSelectable (true);
        this.logScroll.addView (this.logView);
        final LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams (LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollParams.gravity = Gravity.TOP;
        root.addView (this.logScroll, scrollParams);

        this.setContentView (root);
    }


    private void pickFolder (final int requestCode)
    {
        final Intent intent = new Intent (Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        this.startActivityForResult (intent, requestCode);
    }


    @Override
    protected void onActivityResult (final int requestCode, final int resultCode, final Intent data)
    {
        super.onActivityResult (requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData () == null)
            return;
        final Uri uri = data.getData ();
        final DocumentFile folder = DocumentFile.fromTreeUri (this, uri);
        final String name = folder == null || folder.getName () == null ? uri.toString () : folder.getName ();
        if (requestCode == REQUEST_SOURCE)
        {
            this.sourceUri = uri;
            this.sourceLabel.setText (name);
        }
        else if (requestCode == REQUEST_OUTPUT)
        {
            this.outputUri = uri;
            this.outputLabel.setText (name);
        }
        this.convertButton.setEnabled (this.sourceUri != null && this.outputUri != null);
    }


    private void log (final String line)
    {
        if (line == null || line.isBlank ())
            return;
        this.runOnUiThread ( () -> {
            this.logText.append (line.strip ()).append ('\n');
            if (this.logText.length () > MAX_LOG_CHARS)
                this.logText.delete (0, this.logText.length () - MAX_LOG_CHARS);
            this.logView.setText (this.logText);
            this.logScroll.post ( () -> this.logScroll.fullScroll (View.FOCUS_DOWN));
        });
    }


    private void startConversion ()
    {
        this.convertButton.setEnabled (false);
        this.progress.setVisibility (View.VISIBLE);
        this.logText.setLength (0);
        this.logView.setText ("");

        final Uri source = this.sourceUri;
        final Uri output = this.outputUri;
        final Thread worker = new Thread (null, () -> this.runConversion (source, output), "nki2sf2", 64L * 1024 * 1024);
        worker.start ();
    }


    private void runConversion (final Uri sourceTree, final Uri outputTree)
    {
        final File work = new File (this.getCacheDir (), "work");
        try
        {
            deleteRecursively (work);
            final File inFolder = new File (work, "in");
            final File outFolder = new File (work, "out");
            if (!inFolder.mkdirs () || !outFolder.mkdirs ())
                throw new IOException ("Impossible de préparer le dossier de travail.");

            this.log ("Copie des fichiers…");
            final DocumentFile sourceDoc = DocumentFile.fromTreeUri (this, sourceTree);
            if (sourceDoc == null)
                throw new IOException ("Dossier source illisible.");
            final int copied = this.copyTree (sourceDoc, inFolder);
            this.log (copied + " fichier(s) copié(s). Conversion…");

            final NkiToSf2Converter converter = new NkiToSf2Converter (this::log);
            final int count = converter.convert (inFolder, outFolder);

            final DocumentFile outputDoc = DocumentFile.fromTreeUri (this, outputTree);
            if (outputDoc == null)
                throw new IOException ("Dossier de sortie illisible.");
            final List<File> results = new ArrayList<> ();
            collect (outFolder, results);
            int saved = 0;
            for (final File result: results)
            {
                final DocumentFile existing = outputDoc.findFile (result.getName ());
                if (existing != null)
                    existing.delete ();
                final DocumentFile target = outputDoc.createFile ("application/octet-stream", result.getName ());
                if (target == null)
                    throw new IOException ("Impossible de créer " + result.getName ());
                try (final InputStream in = new java.io.FileInputStream (result); final OutputStream out = this.getContentResolver ().openOutputStream (target.getUri ()))
                {
                    if (out == null)
                        throw new IOException ("Impossible d'écrire " + result.getName ());
                    final byte [] buffer = new byte [1 << 16];
                    int n;
                    while ((n = in.read (buffer)) > 0)
                        out.write (buffer, 0, n);
                }
                saved++;
            }
            this.log ("\nTerminé : " + saved + " fichier(s) .sf2 enregistré(s) (" + count + " instrument(s) convertis, " + converter.getFailedCount () + " échec(s)).");
            if (saved == 0)
                this.log ("Aucun SF2 créé. Les NKI sont peut-être protégés, ou il n'y a pas de .nki dans le dossier.");
        }
        catch (final Exception | OutOfMemoryError ex)
        {
            final String message = ex.getLocalizedMessage ();
            this.log ("\nErreur : " + (message == null ? ex.getClass ().getName () : message));
        }
        finally
        {
            deleteRecursively (work);
            this.runOnUiThread ( () -> {
                this.progress.setVisibility (View.GONE);
                this.convertButton.setEnabled (true);
            });
        }
    }


    private int copyTree (final DocumentFile folder, final File target) throws IOException
    {
        int count = 0;
        for (final DocumentFile child: folder.listFiles ())
        {
            final String name = child.getName ();
            if (name == null)
                continue;
            final File destination = new File (target, name);
            if (child.isDirectory ())
            {
                if (!destination.mkdirs () && !destination.isDirectory ())
                    throw new IOException ("Dossier non créé : " + name);
                count += this.copyTree (child, destination);
            }
            else
            {
                try (final InputStream in = this.getContentResolver ().openInputStream (child.getUri ()); final OutputStream out = new FileOutputStream (destination))
                {
                    if (in == null)
                        continue;
                    final byte [] buffer = new byte [1 << 16];
                    int n;
                    while ((n = in.read (buffer)) > 0)
                        out.write (buffer, 0, n);
                    count++;
                }
            }
        }
        return count;
    }


    private static void collect (final File folder, final List<File> results)
    {
        final File [] children = folder.listFiles ();
        if (children == null)
            return;
        for (final File child: children)
        {
            if (child.isDirectory ())
                collect (child, results);
            else if (child.getName ().toLowerCase ().endsWith (".sf2"))
                results.add (child);
        }
    }


    private static void deleteRecursively (final File file)
    {
        final File [] children = file.listFiles ();
        if (children != null)
            for (final File child: children)
                deleteRecursively (child);
        file.delete ();
    }
}
