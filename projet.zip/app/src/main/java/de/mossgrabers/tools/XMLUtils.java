package de.mossgrabers.tools;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


/** XML helper functions (compatible re-implementation for Android). */
public class XMLUtils
{
    private XMLUtils ()
    {
        // Intentionally empty
    }


    private static DocumentBuilder createBuilder () throws ParserConfigurationException
    {
        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance ();
        factory.setValidating (false);
        factory.setNamespaceAware (false);
        return factory.newDocumentBuilder ();
    }


    /**
     * Parse an XML document.
     *
     * @param source The source
     * @return The document
     * @throws SAXException Could not parse
     */
    public static Document parseDocument (final InputSource source) throws SAXException
    {
        try
        {
            return createBuilder ().parse (source);
        }
        catch (final java.io.IOException | ParserConfigurationException ex)
        {
            throw new SAXException (ex);
        }
    }


    /**
     * Create a new empty document.
     *
     * @return The document
     * @throws ParserConfigurationException Could not create
     */
    public static Document newDocument () throws ParserConfigurationException
    {
        return createBuilder ().newDocument ();
    }


    /**
     * Get the first child element with the given name.
     *
     * @param node The parent node
     * @param name The name
     * @return The element or null
     */
    public static Element getChildElementByName (final Node node, final String name)
    {
        final NodeList children = node.getChildNodes ();
        for (int i = 0; i < children.getLength (); i++)
            if (children.item (i) instanceof final Element element && name.equals (element.getNodeName ()))
                return element;
        return null;
    }


    /**
     * Get all child elements.
     *
     * @param node The parent node
     * @return The elements
     */
    public static List<Element> getChildElements (final Node node)
    {
        final NodeList children = node.getChildNodes ();
        final List<Element> result = new ArrayList<> (children.getLength ());
        for (int i = 0; i < children.getLength (); i++)
            if (children.item (i) instanceof final Element element)
                result.add (element);
        return result;
    }


    /**
     * Get all direct child elements with the given name.
     *
     * @param node The parent node
     * @param name The name
     * @return The elements
     */
    public static List<Element> getChildElementsByName (final Node node, final String name)
    {
        return getChildElementsByName (node, name, false);
    }


    /**
     * Get the child elements with the given name.
     *
     * @param node The parent node
     * @param name The name
     * @param recursive If true, all descendants are searched
     * @return The elements
     */
    public static List<Element> getChildElementsByName (final Node node, final String name, final boolean recursive)
    {
        final NodeList children;
        if (recursive)
        {
            if (!(node instanceof final Element element))
                return Collections.emptyList ();
            children = element.getElementsByTagName (name);
        }
        else
            children = node.getChildNodes ();
        final List<Element> result = new ArrayList<> (children.getLength ());
        for (int i = 0; i < children.getLength (); i++)
            if (children.item (i) instanceof final Element element && name.equals (element.getNodeName ()))
                result.add (element);
        return result;
    }


    /**
     * Read the text of a child element.
     *
     * @param element The parent
     * @param name The name of the child
     * @return The text or null if there is no such child
     */
    public static String read (final Element element, final String name)
    {
        final Element child = getChildElementByName (element, name);
        return child == null ? null : readTextContent (child);
    }


    /**
     * Read the text content of a node.
     *
     * @param node The node
     * @return The text
     */
    public static String readTextContent (final Node node)
    {
        final String text = node.getTextContent ();
        return text == null ? "" : text;
    }


    /**
     * Get an integer attribute.
     *
     * @param element The element
     * @param name The name of the attribute
     * @param defaultValue The value to return if it does not exist or is invalid
     * @return The value
     */
    public static int getIntegerAttribute (final Element element, final String name, final int defaultValue)
    {
        final String value = element.getAttribute (name);
        if (value == null || value.isEmpty ())
            return defaultValue;
        try
        {
            return Integer.parseInt (value);
        }
        catch (final NumberFormatException ex)
        {
            return defaultValue;
        }
    }


    /**
     * Convert a document to a string.
     *
     * @param document The document
     * @return The XML text
     * @throws TransformerException Could not convert
     */
    public static String toString (final Document document) throws TransformerException
    {
        final Transformer transformer = TransformerFactory.newInstance ().newTransformer ();
        transformer.setOutputProperty (OutputKeys.METHOD, "xml");
        transformer.setOutputProperty (OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty (OutputKeys.INDENT, "yes");
        final StringWriter writer = new StringWriter ();
        transformer.transform (new DOMSource (document), new StreamResult (writer));
        return writer.toString ();
    }
}
