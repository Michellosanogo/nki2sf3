// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.core.settings;

import java.util.Map;

import de.mossgrabers.convertwithmoss.core.INotifier;
import de.mossgrabers.tools.ui.BasicConfig;


/**
 * Interface for configuring a task.
 *
 * @author Jürgen Moßgraber
 */
public interface ICoreTaskSettings
{
    /**
     * Save the settings of the task.
     *
     * @param configuration Where to store to
     */
    void saveSettings (BasicConfig configuration);


    /**
     * Load the settings of the task.
     *
     * @param configuration Where to load from
     */
    void loadSettings (BasicConfig configuration);


    /**
     * Check if the settings which are required for the execution of the task are correct, when set
     * from the user interface.
     *
     * @param notifier Where to report errors
     * @return True if correct and the task can be executed
     */
    boolean checkSettingsUI (INotifier notifier);


    /**
     * Check if the settings which are required for the execution of the task are correct, when set
     * from the command line interface.
     *
     * @param notifier Where to report errors
     * @param parameters The parameters from which to configure the settings
     * @return True if correct and the task can be executed
     */
    boolean checkSettingsCLI (INotifier notifier, Map<String, String> parameters);


    /**
     * Get all parameter names which are used by these settings.
     *
     * @return The names
     */
    String [] getCLIParameterNames ();


    /**
     * Parse a boolean command line parameter. A parameter which is not given on the command line
     * must keep the default of its option, which is the state its check-box has in the user
     * interface. Testing the value alone turns every option off which is enabled by default, so the
     * same conversion produces a different result from the command line than from the GUI.
     *
     * @param value The value of the parameter, null if the parameter was not given
     * @param defaultValue The value to use if the parameter was not given
     * @return The parsed value
     */
    static boolean parseBoolean (final String value, final boolean defaultValue)
    {
        return value == null ? defaultValue : "1".equals (value);
    }
}
