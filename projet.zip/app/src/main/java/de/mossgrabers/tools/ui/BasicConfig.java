package de.mossgrabers.tools.ui;

/** Placeholder for the configuration class of the desktop version (not used on Android). */
public class BasicConfig
{
    /**
     * Constructor.
     *
     * @param name The name
     */
    public BasicConfig (final String name)
    {
        // Intentionally empty
    }
}
