package de.mossgrabers.tools;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;


/** File helper functions (compatible re-implementation for Android). */
public final class FileUtils
{
    private FileUtils ()
    {
        // Intentionally empty
    }


    /**
     * Make a file canonical, if possible.
     *
     * @param file The file
     * @return The canonical file
     */
    public static File makeCanonical (final File file)
    {
        try
        {
            return file.getCanonicalFile ();
        }
        catch (final IOException ex)
        {
            return file.getAbsoluteFile ();
        }
    }


    /**
     * Get the name of a file without the file ending.
     *
     * @param file The file
     * @return The name
     */
    public static String getNameWithoutType (final File file)
    {
        return getNameWithoutType (file.getName ());
    }


    /**
     * Remove the file ending of a name.
     *
     * @param name The name
     * @return The name without ending
     */
    public static String getNameWithoutType (final String name)
    {
        final int pos = name.lastIndexOf ('.');
        return pos > 0 ? name.substring (0, pos) : name;
    }


    /**
     * Read a UTF-8 text file.
     *
     * @param file The file
     * @return The content
     * @throws IOException Could not read
     */
    public static String readUTF8 (final File file) throws IOException
    {
        return new String (Files.readAllBytes (file.toPath ()), StandardCharsets.UTF_8);
    }


    /**
     * Replace characters which are not allowed in file names.
     *
     * @param name The name
     * @return The safe name
     */
    public static String createSafeFilename (final String name)
    {
        final String safe = name.replaceAll ("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim ();
        return safe.isEmpty () ? "_" : safe;
    }
}
