// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.core;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import de.mossgrabers.convertwithmoss.core.model.IEnvelope;
import de.mossgrabers.convertwithmoss.core.model.IEnvelopeModulator;
import de.mossgrabers.convertwithmoss.core.model.IFilter;
import de.mossgrabers.convertwithmoss.core.model.IGroup;
import de.mossgrabers.convertwithmoss.core.model.ISampleZone;


/**
 * A detected source for a multi-sample.
 *
 * @author Jürgen Moßgraber
 */
public interface IMultisampleSource extends ISource
{
    /**
     * Get the folder which contains the multi-sample source or the file itself.
     *
     * @return The folder
     */
    File getSourceFile ();


    /**
     * Set the folder which contains the multi-sample source or the file itself.
     *
     * @param folder The folder
     */
    void setFolder (File folder);


    /**
     * Get the sub-folders which contain the samples up to the source path.
     *
     * @return The sub folders
     */
    String [] getSubPath ();


    /**
     * Set the sub-folders which contain the samples up to the source path.
     *
     * @param subFolders The sub folders
     */
    void setSubPath (String [] subFolders);


    /**
     * Inserts the given folder before the last part of the current sub-path. Ensures that the given
     * name works on all OSs.
     *
     * @param additionalFolder The name of the folder to insert
     */
    void extendSubPath (final String additionalFolder);


    /**
     * Get the description of the groups which belong to the multi-sample.
     *
     * @return The descriptions
     */
    List<IGroup> getGroups ();


    /**
     * Get all groups which are considered to be part of a round-robin sequence. See
     * {@link IGroup#isGroupRoundRobin ()}.
     *
     * @return All round-robin groups with the sequence position index, see
     *         {@link ISampleZone#getSequencePosition ()}
     */
    default Map<IGroup, Integer> getRoundRobinGroups ()
    {
        final Map<IGroup, Integer> roundRobinGroups = new HashMap<> ();
        for (final IGroup group: this.getGroups ())
            if (group.isGroupRoundRobin ())
                roundRobinGroups.put (group, Integer.valueOf (group.getSampleZones ().get (0).getSequencePosition ()));
        return roundRobinGroups;
    }


    /**
     * If all zones of all groups are set to play round-robin.
     *
     * @return True if all sample zones have round-robin enabled
     */
    default boolean isFullRoundRobin ()
    {
        for (final IGroup group: this.getNonEmptyGroups (false))
            if (!group.isFullRoundRobin ())
                return false;
        return true;
    }


    /**
     * If at least one zone in this group is set to play round-robin.
     *
     * @return True if at least one sample zone has round-robin enabled
     */
    default boolean hasRoundRobin ()
    {
        for (final IGroup group: this.getNonEmptyGroups (false))
            if (group.hasRoundRobin ())
                return true;
        return false;
    }


    /**
     * Collect all sample zones from all groups into one list.
     *
     * @param filterReleaseTriggers Removes all groups which do only contain release triggers
     * @return All sample zones of the multi-sample
     */
    default List<ISampleZone> getAllSampleZones (final boolean filterReleaseTriggers)
    {
        final List<IGroup> groups = this.getNonEmptyGroups (filterReleaseTriggers);
        final List<ISampleZone> sampleZones = new ArrayList<> ();
        for (final IGroup group: groups)
            sampleZones.addAll (group.getSampleZones ());
        return sampleZones;
    }


    /**
     * Get all sample zones of the multi-sample ordered by their root note and then by their
     * low-velocity (for each root note).
     *
     * @param filterReleaseTriggers Removes all groups which do only contain release triggers
     * @return All sample zones of the multi-sample ordered by root note and low-velocity
     */
    default TreeMap<Integer, TreeMap<Integer, List<ISampleZone>>> getOrderedSampleZones (final boolean filterReleaseTriggers)
    {
        final TreeMap<Integer, TreeMap<Integer, List<ISampleZone>>> result = new TreeMap<> ();
        for (final ISampleZone sampleZone: this.getAllSampleZones (filterReleaseTriggers))
        {
            final TreeMap<Integer, List<ISampleZone>> velocityLayers = result.computeIfAbsent (Integer.valueOf (sampleZone.getKeyRoot ()), ignoredKey -> new TreeMap<> ());
            final List<ISampleZone> sameZone = velocityLayers.computeIfAbsent (Integer.valueOf (sampleZone.getVelocityLow ()), ignoredKey -> new ArrayList<> ());
            sameZone.add (sampleZone);
        }
        return result;
    }


    /**
     * Get only the groups which do contain at least one sample.
     *
     * @param filterReleaseTriggers Removes all groups which do only contain release triggers
     * @return The group without empty ones
     */
    List<IGroup> getNonEmptyGroups (final boolean filterReleaseTriggers);


    /**
     * Set the groups with the related sample zones.
     *
     * @param groups The groups with the related sample zones
     */
    void setGroups (List<IGroup> groups);


    /**
     * Checks all samples in all groups for filter settings. Only if all samples contain the same
     * filter settings a result is returned.
     *
     * @return The filter if a global filter setting is found
     */
    Optional<IFilter> getGlobalFilter ();


    /**
     * Sets a filter on all samples in all groups.
     *
     * @param filter The filter to set
     */
    void setGlobalFilter (IFilter filter);


    /**
     * Set the envelope on all sample zones of the multi-sample.
     *
     * @param depth The depth to set in the range of [-1,1]
     * @param envelope The envelope to set
     */
    void setGlobalPitchEnvelope (double depth, IEnvelope envelope);


    /**
     * Checks all samples in all groups for velocity modulation on the amplitude settings. Only if
     * all samples contain the same modulation value a result is returned.
     *
     * @return The modulation value
     */
    Optional<Double> getGlobalAmplitudeVelocity ();


    /**
     * Checks all samples in all groups for amplitude envelope modulation settings. Only if all
     * samples contain the same settings a result is returned.
     *
     * @return The amplitude if a global envelope setting is found
     */
    Optional<IEnvelopeModulator> getGlobalAmplitudeModulator ();


    /**
     * Checks all samples in all groups for panning. Only if all samples contain the same panning
     * value a result is returned.
     *
     * @return The global panning value in the range of [-1..1], -1 is full left, 0 centered and 1
     *         full right
     */
    Optional<Double> getGlobalPanning ();


    /**
     * Checks all samples in all groups for gain. Only if all samples contain the same gain value a
     * result is returned.
     *
     * @return The global gain value
     */
    Optional<Double> getGlobalGain ();


    /**
     * Checks all samples in all groups for tuning. Only if all samples contain the same tuning
     * value a result is returned.
     *
     * @return The global tuning value
     */
    Optional<Double> getGlobalTuning ();


    /**
     * Get the lowest key covered by a sample in all of the groups.
     *
     * @return The lowest playing key (0-127)
     */
    int getLowestKey ();


    /**
     * Get the highest key covered by a sample in all of the groups.
     *
     * @return The highest playing key (0-127)
     */
    int getHighestKey ();


    /**
     * Get the polyphony of the instrument, which is the maximum number of voices which can sound at
     * the same time. A value of 1 means that the instrument is monophonic.
     * <p>
     * Known encodings of this attribute are: TAL Sampler <code>PROGRAM_NUM_VOICES</code>, Reason
     * SXT <code>keyPolyphony</code>, Logic EXS24 <code>POLYPHONY_VOICES</code>, DecentSampler
     * <code>polyphony</code>, the maximum number of voices of the Expert Sleepers Disting EX,
     * 1010music <code>polymode</code> and Ableton <code>NumVoices</code>.
     *
     * @return The maximum number of simultaneous voices, 0 if the polyphony is not specified
     */
    int getPolyphony ();


    /**
     * Set the polyphony of the instrument, which is the maximum number of voices which can sound at
     * the same time.
     *
     * @param polyphony The maximum number of simultaneous voices, 0 if the polyphony is not
     *            specified
     */
    void setPolyphony (int polyphony);


    /**
     * Check if the instrument is played monophonic with legato, which means that the envelopes are
     * not re-triggered as long as another key is already held down. This is only relevant if the
     * instrument is monophonic.
     * <p>
     * Known encodings of this attribute are: Reason SXT <code>keyMode</code> and
     * <code>groupMono</code>, Logic EXS24 <code>MONO_LEGATO</code>, DecentSampler
     * <code>&lt;monophonic&gt;</code>, Synthstrom Deluge <code>polyphonic</code>, 1010music
     * <code>legatomode</code> and Ableton <code>PortamentoMode</code>.
     *
     * @return True if the instrument is played monophonic with legato
     */
    boolean isMonophonicLegato ();


    /**
     * Set the instrument to be played monophonic with legato, which means that the envelopes are
     * not re-triggered as long as another key is already held down.
     *
     * @param isMonophonicLegato True to play the instrument monophonic with legato
     */
    void setMonophonicLegato (boolean isMonophonicLegato);


    /**
     * Get the portamento time of the instrument, which is the time it takes to glide from the pitch
     * of the previously played key to the pitch of the currently played key.
     * <p>
     * Known encodings of this attribute are: Reason SXT <code>portamento</code>, Logic EXS24
     * <code>GLIDE</code> and Ableton <code>PortamentoTime</code>.
     *
     * @return The portamento time in seconds, 0 if there is no portamento
     */
    double getPortamentoTime ();


    /**
     * Set the portamento time of the instrument, which is the time it takes to glide from the pitch
     * of the previously played key to the pitch of the currently played key.
     *
     * @param portamentoTime The portamento time in seconds, 0 for no portamento
     */
    void setPortamentoTime (double portamentoTime);
}
