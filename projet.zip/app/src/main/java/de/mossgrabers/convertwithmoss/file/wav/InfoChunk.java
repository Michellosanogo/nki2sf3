// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.file.wav;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import de.mossgrabers.convertwithmoss.file.riff.AbstractListChunk;
import de.mossgrabers.convertwithmoss.file.riff.IRiffChunk;
import de.mossgrabers.convertwithmoss.file.riff.InfoRiffChunkId;
import de.mossgrabers.convertwithmoss.file.riff.RawRIFFChunk;
import de.mossgrabers.convertwithmoss.file.riff.RiffChunkId;


/**
 * Class for a list chunk with info sub-chunks.
 *
 * @author Jürgen Moßgraber
 */
public class InfoChunk extends AbstractListChunk
{
    // This must not be static since it is not thread safe!
    private static final SimpleDateFormat [] CREATION_DATE_PARSERS = new SimpleDateFormat []
    {
        // 'Month Day, Year' where Month is initially capitalized and is the conventional full
        // English spelling of the month, Day is the date in decimal followed by a comma, and Year
        // is the full decimal year.
        new SimpleDateFormat ("MMMM d, yyyy", Locale.ENGLISH),
        // Other variations found which do not comply to the specification
        new SimpleDateFormat ("dd'st' MMMM yyyy", Locale.ENGLISH),
        new SimpleDateFormat ("dd'nd' MMMM yyyy", Locale.ENGLISH),
        new SimpleDateFormat ("dd'rd' MMMM yyyy", Locale.ENGLISH),
        new SimpleDateFormat ("dd'th' MMMM yyyy", Locale.ENGLISH),
        new SimpleDateFormat ("dd MMMM yyyy", Locale.ENGLISH),
        new SimpleDateFormat ("MM/dd/yyyy h:mm:ss a"),
        new SimpleDateFormat ("MM/dd/yyyy hh:mm:ss"),
        new SimpleDateFormat ("MM/dd/yyyy"),
        new SimpleDateFormat ("yyyy-MM-dd h:mm:ss a"),
        new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss"),
        new SimpleDateFormat ("yyyy-MM-dd"),
        new SimpleDateFormat ("EEEE d MMMM yyyy, HH:mm:ss", Locale.ENGLISH)
    };


    /**
     * Default constructor.
     */
    public InfoChunk ()
    {
        super (InfoRiffChunkId.INFO_ID.getFourCC ());
    }


    /**
     * Get all info fields from the sub-chunks.
     *
     * @return The sub-chunk content with their descriptive name as the key
     */
    public Map<String, String> getInfoFields ()
    {
        final Map<String, String> fields = new TreeMap<> ();
        for (final IRiffChunk chunk: this.subChunks)
            fields.put (chunk.getId ().getDescription (), chunkDataToAsciiString (chunk));
        return fields;
    }


    /**
     * Get the value of 1 info sub-chunks.
     *
     * @param infoChunkID The ID of the info chunk to get
     * @return The sub-chunk content as an ASCII string
     */
    public Optional<String> getInfoField (final RiffChunkId infoChunkID)
    {
        final int id = infoChunkID.getFourCC ();
        for (final IRiffChunk chunk: this.subChunks)
            if (chunk.getId ().getFourCC () == id)
                return Optional.ofNullable (chunkDataToAsciiString (chunk));
        return Optional.empty ();
    }


    /**
     * Get the value of an info field.
     *
     * @param riffIDs The IDs of the info fields to check
     * @return The first present value of the given IDs is returned
     */
    public Optional<String> getInfoField (final RiffChunkId... riffIDs)
    {
        for (final RiffChunkId id: riffIDs)
        {
            final Optional<String> value = this.getInfoField (id);
            if (value.isPresent ())
                return Optional.of (value.get ());
        }
        return Optional.empty ();
    }


    /**
     * Create a new info-sub-chunk and add it to this info chunk.
     *
     * @param infoChunkID The ID of the info sub-chunk to create
     * @param value The sub-chunk content
     * @param maxLength The maximum text length including 2 zero bytes at the end
     */
    public void addInfoTextField (final RiffChunkId infoChunkID, final String value, final int maxLength)
    {
        byte [] content = value.getBytes (StandardCharsets.US_ASCII);

        final int paddingLength = content.length % 2 == 0 ? 2 : 1;
        final int fullLength = content.length + paddingLength;

        final int diff = fullLength - maxLength;
        if (diff > 0)
            content = Arrays.copyOf (content, fullLength - diff);

        content = Arrays.copyOf (content, content.length + paddingLength);
        this.addInfoField (infoChunkID, content);
    }


    /**
     * Create a new info-sub-chunk and add it to this info chunk.
     *
     * @param infoChunkID The ID of the info sub-chunk to create
     * @param content The sub-chunk content
     */
    public void addInfoField (final RiffChunkId infoChunkID, final byte [] content)
    {
        final RawRIFFChunk riffChunk = new RawRIFFChunk (InfoRiffChunkId.INFO_ID.getFourCC (), infoChunkID, content.length);
        riffChunk.setData (content);
        this.add (riffChunk);
    }


    /**
     * Get the creation date as a date object.
     *
     * @return The date object
     */
    public Date getCreationDate ()
    {
        final Optional<String> dateTime = this.getInfoField (InfoRiffChunkId.INFO_ICRD, InfoRiffChunkId.INFO_IDIT, InfoRiffChunkId.INFO_YEAR);
        if (dateTime.isPresent ())
            synchronized (CREATION_DATE_PARSERS)
            {
                for (int i = 0; i < CREATION_DATE_PARSERS.length; i++)
                {
                    final Optional<Date> date = parseDate (i, dateTime.get ());
                    if (date.isPresent ())
                        return date.get ();
                }
            }
        return new Date ();
    }


    /**
     * Set the creation date as a date object.
     *
     * @param date The date object
     */
    public void addCreationDate (final Date date)
    {
        synchronized (CREATION_DATE_PARSERS)
        {
            this.addInfoTextField (InfoRiffChunkId.INFO_ICRD, CREATION_DATE_PARSERS[0].format (date == null ? new Date () : date), 256);
        }
    }


    private static final Optional<Date> parseDate (final int parserIndex, final String dateTime)
    {
        try
        {
            return Optional.of (CREATION_DATE_PARSERS[parserIndex].parse (dateTime));
        }
        catch (final java.text.ParseException ignoredException)
        {
            return Optional.empty ();
        }
    }


    /** {@inheritDoc} */
    @Override
    public String infoText ()
    {
        final StringBuilder sb = new StringBuilder ();
        for (final IRiffChunk chunk: this.subChunks)
        {
            if (!sb.isEmpty ())
                sb.append ('\n');
            sb.append (chunk.getId ().getDescription ()).append (": ").append (chunkDataToAsciiString (chunk));
        }
        return sb.toString ();
    }


    /**
     * Get the chunk data as an ASCII string.
     *
     * @param chunk The chunk from which to read the data
     * @return The ASCII string
     */
    public static String chunkDataToAsciiString (final IRiffChunk chunk)
    {
        final ByteArrayOutputStream out = new ByteArrayOutputStream ();
        try
        {
            chunk.writeData (out);
        }
        catch (final IOException ignoredException)
        {
            return "";
        }
        return new String (out.toByteArray (), StandardCharsets.US_ASCII);
    }
}
