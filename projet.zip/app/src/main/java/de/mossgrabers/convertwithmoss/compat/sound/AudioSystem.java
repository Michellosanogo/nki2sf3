package de.mossgrabers.convertwithmoss.compat.sound;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;


/**
 * Minimal replacement for javax.sound.sampled.AudioSystem, which does not exist on Android. Reads
 * WAV and AIFF/AIFC (uncompressed PCM), converts between PCM formats and writes WAV files.
 */
public final class AudioSystem
{
    /** Value for an unknown length. */
    public static final int NOT_SPECIFIED = -1;

    private static final int MARK_LIMIT = 4 * 1024 * 1024;


    private static final class Parsed
    {
        AudioFileFormat format;
        long            dataLength = -1;
    }


    private AudioSystem ()
    {
        // Intentionally empty
    }


    /**
     * Read the format of an audio file.
     *
     * @param file The file
     * @return The format
     * @throws UnsupportedAudioFileException Unknown or unsupported format
     * @throws IOException Could not read the file
     */
    public static AudioFileFormat getAudioFileFormat (final File file) throws UnsupportedAudioFileException, IOException
    {
        try (final InputStream in = new BufferedInputStream (new FileInputStream (file)))
        {
            return parse (new DataInputStream (in)).format;
        }
    }


    /**
     * Read the format of an audio stream. The stream is reset afterwards.
     *
     * @param stream The stream
     * @return The format
     * @throws UnsupportedAudioFileException Unknown or unsupported format
     * @throws IOException Could not read the stream
     */
    public static AudioFileFormat getAudioFileFormat (final InputStream stream) throws UnsupportedAudioFileException, IOException
    {
        final InputStream in = stream.markSupported () ? stream : new BufferedInputStream (stream);
        in.mark (MARK_LIMIT);
        try
        {
            return parse (new DataInputStream (in)).format;
        }
        finally
        {
            in.reset ();
        }
    }


    /**
     * Open an audio file for reading.
     *
     * @param file The file
     * @return The audio stream
     * @throws UnsupportedAudioFileException Unknown or unsupported format
     * @throws IOException Could not read the file
     */
    public static AudioInputStream getAudioInputStream (final File file) throws UnsupportedAudioFileException, IOException
    {
        final InputStream in = new BufferedInputStream (new FileInputStream (file));
        try
        {
            return getAudioInputStream (in);
        }
        catch (final UnsupportedAudioFileException | IOException | RuntimeException ex)
        {
            in.close ();
            throw ex;
        }
    }


    /**
     * Open an audio stream for reading.
     *
     * @param stream The stream, positioned at the start of the file
     * @return The audio stream, positioned at the audio data
     * @throws UnsupportedAudioFileException Unknown or unsupported format
     * @throws IOException Could not read the stream
     */
    public static AudioInputStream getAudioInputStream (final InputStream stream) throws UnsupportedAudioFileException, IOException
    {
        final Parsed parsed = parse (new DataInputStream (stream));
        final AudioFormat format = parsed.format.getFormat ();
        final long frames = parsed.dataLength >= 0 ? parsed.dataLength / format.getFrameSize () : NOT_SPECIFIED;
        return new AudioInputStream (stream, format, frames);
    }


    /**
     * Convert the audio data of a stream to another PCM format.
     *
     * @param targetFormat The wanted format
     * @param source The source stream
     * @return The converted stream
     * @throws IllegalArgumentException If the conversion is not supported
     */
    public static AudioInputStream getAudioInputStream (final AudioFormat targetFormat, final AudioInputStream source)
    {
        final AudioFormat sf = source.getFormat ();
        if (sameFormat (sf, targetFormat))
            return source;
        if (sf.getChannels () != targetFormat.getChannels () || Math.abs (sf.getSampleRate () - targetFormat.getSampleRate ()) > 0.5f)
            throw new IllegalArgumentException ("Conversion of channels or sample rate is not supported.");
        if (isInteger (sf) && isInteger (targetFormat) || sf.getEncoding ().equals (AudioFormat.Encoding.PCM_FLOAT) && isInteger (targetFormat))
        {
            try
            {
                final byte [] data = source.readAllBytes ();
                final byte [] converted = convertPcm (data, sf, targetFormat);
                return new AudioInputStream (new java.io.ByteArrayInputStream (converted), targetFormat, converted.length / targetFormat.getFrameSize ());
            }
            catch (final IOException ex)
            {
                throw new IllegalArgumentException (ex);
            }
        }
        throw new IllegalArgumentException ("Conversion from " + sf.getEncoding () + " to " + targetFormat.getEncoding () + " is not supported.");
    }


    /**
     * Get the file types which can be written for a stream.
     *
     * @param stream The stream
     * @return The types
     */
    public static AudioFileFormat.Type [] getAudioFileTypes (final AudioInputStream stream)
    {
        return new AudioFileFormat.Type []
        {
            AudioFileFormat.Type.WAVE
        };
    }


    /**
     * Write the audio data as a file.
     *
     * @param stream The audio data
     * @param type The file type, only WAVE is supported
     * @param file The file to write
     * @return The number of written bytes
     * @throws IOException Could not write
     */
    public static int write (final AudioInputStream stream, final AudioFileFormat.Type type, final File file) throws IOException
    {
        try (final OutputStream out = new java.io.BufferedOutputStream (new FileOutputStream (file)))
        {
            return write (stream, type, out);
        }
    }


    /**
     * Write the audio data as a WAV file.
     *
     * @param stream The audio data
     * @param type The file type, only WAVE is supported
     * @param out Where to write to
     * @return The number of written bytes
     * @throws IOException Could not write
     */
    public static int write (final AudioInputStream stream, final AudioFileFormat.Type type, final OutputStream out) throws IOException
    {
        if (!AudioFileFormat.Type.WAVE.equals (type))
            throw new IllegalArgumentException ("File type " + type + " is not supported.");
        final AudioFormat f = stream.getFormat ();
        byte [] data = stream.readAllBytes ();
        final int bits = f.getSampleSizeInBits ();
        final boolean isFloat = f.getEncoding ().equals (AudioFormat.Encoding.PCM_FLOAT);
        final int bytesPerSample = (bits + 7) / 8;

        if (f.isBigEndian () && bytesPerSample > 1)
        {
            data = data.clone ();
            for (int i = 0; i + bytesPerSample <= data.length; i += bytesPerSample)
                for (int a = i, b = i + bytesPerSample - 1; a < b; a++, b--)
                {
                    final byte t = data[a];
                    data[a] = data[b];
                    data[b] = t;
                }
        }
        if (bits == 8 && f.getEncoding ().equals (AudioFormat.Encoding.PCM_SIGNED))
        {
            data = data.clone ();
            for (int i = 0; i < data.length; i++)
                data[i] = (byte) (data[i] + 128);
        }

        final int frameSize = bytesPerSample * f.getChannels ();
        final int rate = Math.round (f.getSampleRate ());
        final int tag = isFloat ? 3 : 1;
        final ByteBuffer header = ByteBuffer.allocate (44).order (ByteOrder.LITTLE_ENDIAN);
        header.put ("RIFF".getBytes (java.nio.charset.StandardCharsets.US_ASCII));
        header.putInt (36 + data.length);
        header.put ("WAVEfmt ".getBytes (java.nio.charset.StandardCharsets.US_ASCII));
        header.putInt (16);
        header.putShort ((short) tag);
        header.putShort ((short) f.getChannels ());
        header.putInt (rate);
        header.putInt (rate * frameSize);
        header.putShort ((short) frameSize);
        header.putShort ((short) bits);
        header.put ("data".getBytes (java.nio.charset.StandardCharsets.US_ASCII));
        header.putInt (data.length);
        out.write (header.array ());
        out.write (data);
        out.flush ();
        return 44 + data.length;
    }


    // ---------------------------------------------------------------------------------------
    // Parsing
    // ---------------------------------------------------------------------------------------

    private static Parsed parse (final DataInputStream in) throws UnsupportedAudioFileException, IOException
    {
        final byte [] id = new byte [4];
        try
        {
            in.readFully (id);
        }
        catch (final EOFException ex)
        {
            throw new UnsupportedAudioFileException ("File too short.");
        }
        final String head = new String (id, java.nio.charset.StandardCharsets.US_ASCII);
        if ("RIFF".equals (head))
            return parseWav (in);
        if ("FORM".equals (head))
            return parseAiff (in);
        throw new UnsupportedAudioFileException ("Unknown audio format.");
    }


    private static int readIntLE (final DataInputStream in) throws IOException
    {
        return Integer.reverseBytes (in.readInt ());
    }


    private static int readShortLE (final DataInputStream in) throws IOException
    {
        return Short.reverseBytes (in.readShort ()) & 0xFFFF;
    }


    private static String readId (final DataInputStream in) throws IOException
    {
        final byte [] b = new byte [4];
        in.readFully (b);
        return new String (b, java.nio.charset.StandardCharsets.US_ASCII);
    }


    private static void skipFully (final DataInputStream in, final long count) throws IOException
    {
        long remaining = count;
        while (remaining > 0)
        {
            final long skipped = in.skip (remaining);
            if (skipped <= 0)
            {
                if (in.read () < 0)
                    throw new EOFException ();
                remaining--;
            }
            else
                remaining -= skipped;
        }
    }


    private static Parsed parseWav (final DataInputStream in) throws UnsupportedAudioFileException, IOException
    {
        readIntLE (in);
        if (!"WAVE".equals (readId (in)))
            throw new UnsupportedAudioFileException ("Not a WAVE file.");

        AudioFormat format = null;
        try
        {
            while (true)
            {
                final String chunkId = readId (in);
                final long size = readIntLE (in) & 0xFFFFFFFFL;
                if ("fmt ".equals (chunkId))
                {
                    if (size < 16)
                        throw new UnsupportedAudioFileException ("Invalid fmt chunk.");
                    int tag = readShortLE (in);
                    final int channels = readShortLE (in);
                    final int rate = readIntLE (in);
                    readIntLE (in);
                    final int blockAlign = readShortLE (in);
                    final int bits = readShortLE (in);
                    long consumed = 16;
                    if (tag == 0xFFFE && size >= 40)
                    {
                        readShortLE (in);
                        readShortLE (in);
                        readIntLE (in);
                        tag = readShortLE (in);
                        consumed += 10;
                    }
                    skipFully (in, size - consumed + (size & 1));
                    final AudioFormat.Encoding encoding;
                    if (tag == 1)
                        encoding = bits == 8 ? AudioFormat.Encoding.PCM_UNSIGNED : AudioFormat.Encoding.PCM_SIGNED;
                    else if (tag == 3)
                        encoding = AudioFormat.Encoding.PCM_FLOAT;
                    else
                        throw new UnsupportedAudioFileException ("Compressed WAV files are not supported (format tag " + tag + ").");
                    if (channels < 1 || bits < 1)
                        throw new UnsupportedAudioFileException ("Invalid WAV format.");
                    final int frameSize = blockAlign > 0 ? blockAlign : (bits + 7) / 8 * channels;
                    format = new AudioFormat (encoding, rate, bits, channels, frameSize, rate, false);
                }
                else if ("data".equals (chunkId))
                {
                    if (format == null)
                        throw new UnsupportedAudioFileException ("No fmt chunk before data.");
                    final Parsed result = new Parsed ();
                    result.dataLength = size == 0xFFFFFFFFL || size > Integer.MAX_VALUE ? -1 : size;
                    final int frames = result.dataLength >= 0 ? (int) (result.dataLength / format.getFrameSize ()) : NOT_SPECIFIED;
                    result.format = new AudioFileFormat (AudioFileFormat.Type.WAVE, format, frames, result.dataLength >= 0 ? (int) result.dataLength + 44 : NOT_SPECIFIED);
                    return result;
                }
                else
                    skipFully (in, size + (size & 1));
            }
        }
        catch (final EOFException ex)
        {
            throw new UnsupportedAudioFileException ("Incomplete WAV file.");
        }
    }


    private static double readExtended (final DataInputStream in) throws IOException
    {
        final int exponentAndSign = in.readUnsignedShort ();
        final long mantissa = in.readLong ();
        final int exponent = exponentAndSign & 0x7FFF;
        if (exponent == 0 && mantissa == 0)
            return 0;
        final double value = (mantissa >>> 11) * Math.pow (2, exponent - 16383 - 52);
        return (exponentAndSign & 0x8000) != 0 ? -value : value;
    }


    private static Parsed parseAiff (final DataInputStream in) throws UnsupportedAudioFileException, IOException
    {
        in.readInt ();
        final String form = readId (in);
        final boolean isAifc = "AIFC".equals (form);
        if (!isAifc && !"AIFF".equals (form))
            throw new UnsupportedAudioFileException ("Not an AIFF file.");

        AudioFormat format = null;
        long frames = 0;
        try
        {
            while (true)
            {
                final String chunkId = readId (in);
                final long size = in.readInt () & 0xFFFFFFFFL;
                if ("COMM".equals (chunkId))
                {
                    final int channels = in.readUnsignedShort ();
                    frames = in.readInt () & 0xFFFFFFFFL;
                    final int bits = in.readUnsignedShort ();
                    final double rate = readExtended (in);
                    long consumed = 18;
                    boolean bigEndian = true;
                    AudioFormat.Encoding encoding = AudioFormat.Encoding.PCM_SIGNED;
                    if (isAifc && size >= 22)
                    {
                        final String compression = readId (in);
                        consumed += 4;
                        if ("sowt".equals (compression))
                            bigEndian = false;
                        else if ("fl32".equals (compression) || "FL32".equals (compression))
                            encoding = AudioFormat.Encoding.PCM_FLOAT;
                        else if (!"NONE".equals (compression) && !"twos".equals (compression))
                            throw new UnsupportedAudioFileException ("Compressed AIFC files are not supported.");
                    }
                    skipFully (in, size - consumed + (size & 1));
                    format = new AudioFormat (encoding, (float) rate, bits, channels, (bits + 7) / 8 * channels, (float) rate, bigEndian);
                }
                else if ("SSND".equals (chunkId))
                {
                    if (format == null)
                        throw new UnsupportedAudioFileException ("No COMM chunk before SSND.");
                    final int offset = in.readInt ();
                    in.readInt ();
                    skipFully (in, offset);
                    final Parsed result = new Parsed ();
                    result.dataLength = frames * format.getFrameSize ();
                    result.format = new AudioFileFormat (AudioFileFormat.Type.AIFF, format, (int) frames, (int) result.dataLength + 54);
                    return result;
                }
                else
                    skipFully (in, size + (size & 1));
            }
        }
        catch (final EOFException ex)
        {
            throw new UnsupportedAudioFileException ("Incomplete AIFF file.");
        }
    }


    // ---------------------------------------------------------------------------------------
    // Conversion
    // ---------------------------------------------------------------------------------------

    private static boolean isInteger (final AudioFormat f)
    {
        return f.getEncoding ().equals (AudioFormat.Encoding.PCM_SIGNED) || f.getEncoding ().equals (AudioFormat.Encoding.PCM_UNSIGNED);
    }


    private static boolean sameFormat (final AudioFormat a, final AudioFormat b)
    {
        return a.getEncoding ().equals (b.getEncoding ()) && a.getSampleSizeInBits () == b.getSampleSizeInBits () && a.getChannels () == b.getChannels () && a.getFrameSize () == b.getFrameSize () && a.isBigEndian () == b.isBigEndian () && Math.abs (a.getSampleRate () - b.getSampleRate ()) < 0.5f;
    }


    private static byte [] convertPcm (final byte [] data, final AudioFormat src, final AudioFormat dst)
    {
        final int srcBytes = (src.getSampleSizeInBits () + 7) / 8;
        final int dstBytes = (dst.getSampleSizeInBits () + 7) / 8;
        final int samples = data.length / srcBytes;
        final byte [] out = new byte [samples * dstBytes];
        final boolean srcFloat = src.getEncoding ().equals (AudioFormat.Encoding.PCM_FLOAT);
        final boolean srcUnsigned = src.getEncoding ().equals (AudioFormat.Encoding.PCM_UNSIGNED);
        final boolean dstUnsigned = dst.getEncoding ().equals (AudioFormat.Encoding.PCM_UNSIGNED);
        final int dstBits = dst.getSampleSizeInBits ();

        for (int s = 0; s < samples; s++)
        {
            // Decode to a signed, left aligned 32 bit value
            int v;
            final int o = s * srcBytes;
            if (srcFloat)
            {
                final int raw = readRaw (data, o, srcBytes, src.isBigEndian ());
                final double d = Float.intBitsToFloat (raw);
                v = (int) Math.max (Integer.MIN_VALUE, Math.min (Integer.MAX_VALUE, Math.round (d * 2147483648.0)));
            }
            else
            {
                int raw = readRaw (data, o, srcBytes, src.isBigEndian ());
                if (srcUnsigned)
                    raw -= 1 << (src.getSampleSizeInBits () - 1);
                v = raw << (32 - srcBytes * 8);
            }

            // Encode
            int result = v >> (32 - dstBytes * 8);
            if (dstUnsigned)
                result += 1 << (dstBits - 1);
            writeRaw (out, s * dstBytes, dstBytes, dst.isBigEndian (), result);
        }
        return out;
    }


    private static int readRaw (final byte [] data, final int offset, final int bytes, final boolean bigEndian)
    {
        int value = 0;
        if (bigEndian)
        {
            for (int i = 0; i < bytes; i++)
                value = value << 8 | data[offset + i] & 0xFF;
        }
        else
        {
            for (int i = bytes - 1; i >= 0; i--)
                value = value << 8 | data[offset + i] & 0xFF;
        }
        // Sign extend
        final int shift = 32 - bytes * 8;
        return shift > 0 ? value << shift >> shift : value;
    }


    private static void writeRaw (final byte [] out, final int offset, final int bytes, final boolean bigEndian, final int value)
    {
        for (int i = 0; i < bytes; i++)
        {
            final int b = value >> 8 * i & 0xFF;
            out[bigEndian ? offset + bytes - 1 - i : offset + i] = (byte) b;
        }
    }
}
