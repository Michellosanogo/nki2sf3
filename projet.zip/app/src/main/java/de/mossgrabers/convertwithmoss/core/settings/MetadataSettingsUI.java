// Headless version for Android (no JavaFX). Based on the work of Jürgen Moßgraber - mossgrabers.de
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.core.settings;

import java.util.Map;

import de.mossgrabers.convertwithmoss.core.INotifier;
import de.mossgrabers.tools.StringUtils;
import de.mossgrabers.tools.ui.BasicConfig;


/**
 * Encapsulates metadata fields used by different detectors (no user interface on Android).
 */
public class MetadataSettingsUI implements IMetadataConfig, ICoreTaskSettings
{
    private static final String PREFER_FOLDER_NAME        = "PreferFolderName";
    private static final String CATEGORY_FROM_NAME_PREFIX = "CategoryFromNamePrefix";
    private static final String DEFAULT_CREATOR           = "DefaultCreator";
    private static final String TAG_CREATORS              = "Creators";

    protected final String      prefix;

    private boolean             preferFolderName;
    private boolean             categoryFromNamePrefix;
    private String              defaultCreator            = "moss";
    private String []           creators                  = new String [0];


    /**
     * Constructor.
     *
     * @param prefix The prefix to use for the properties tags
     */
    public MetadataSettingsUI (final String prefix)
    {
        this.prefix = prefix;
    }


    /** {@inheritDoc} */
    @Override
    public void loadSettings (final BasicConfig configuration)
    {
        // Not used on Android
    }


    /** {@inheritDoc} */
    @Override
    public void saveSettings (final BasicConfig configuration)
    {
        // Not used on Android
    }


    /** {@inheritDoc} */
    @Override
    public boolean checkSettingsUI (final INotifier notifier)
    {
        return true;
    }


    /** {@inheritDoc} */
    @Override
    public boolean checkSettingsCLI (final INotifier notifier, final Map<String, String> parameters)
    {
        String value = parameters.remove (this.prefix + PREFER_FOLDER_NAME);
        this.preferFolderName = "1".equals (value);
        value = parameters.remove (this.prefix + CATEGORY_FROM_NAME_PREFIX);
        this.categoryFromNamePrefix = "1".equals (value);
        final String creator = parameters.remove (this.prefix + DEFAULT_CREATOR);
        if (creator != null)
            this.defaultCreator = creator;
        value = parameters.remove (this.prefix + TAG_CREATORS);
        this.creators = value == null ? new String [0] : StringUtils.splitByComma (value);
        return true;
    }


    /** {@inheritDoc} */
    @Override
    public String [] getCLIParameterNames ()
    {
        return new String []
        {
            this.prefix + PREFER_FOLDER_NAME,
            this.prefix + CATEGORY_FROM_NAME_PREFIX,
            this.prefix + DEFAULT_CREATOR,
            this.prefix + TAG_CREATORS
        };
    }


    /** {@inheritDoc} */
    @Override
    public boolean isPreferFolderName ()
    {
        return this.preferFolderName;
    }


    /** {@inheritDoc} */
    @Override
    public boolean isCategoryFromNamePrefix ()
    {
        return this.categoryFromNamePrefix;
    }


    /** {@inheritDoc} */
    @Override
    public String getCreatorName ()
    {
        return this.defaultCreator;
    }


    /** {@inheritDoc} */
    @Override
    public String [] getCreatorTags ()
    {
        return this.creators;
    }
}
