package de.mossgrabers.tools.ui;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.MissingResourceException;
import java.util.ResourceBundle;


/** Message and resource helper functions (compatible re-implementation for Android). */
public final class Functions
{
    private static ResourceBundle messages;


    private Functions ()
    {
        // Intentionally empty
    }


    /**
     * Set the bundle with the message texts.
     *
     * @param bundle The bundle
     */
    public static void init (final ResourceBundle bundle)
    {
        messages = bundle;
    }


    /**
     * Get a message text.
     *
     * @param messageID The ID of the message
     * @param replaceStrings Texts which replace %1, %2, ...
     * @return The text
     */
    public static String getMessage (final String messageID, final String... replaceStrings)
    {
        if (messages == null)
            return messageID;
        try
        {
            return replacePercentNWithStrings (messages.getString (messageID), replaceStrings);
        }
        catch (final MissingResourceException ex)
        {
            return messageID;
        }
    }


    /**
     * Get a message text which contains the text of an exception.
     *
     * @param messageID The ID of the message
     * @param throwable The exception
     * @return The text
     */
    public static String getMessage (final String messageID, final Throwable throwable)
    {
        final String text = throwable.getLocalizedMessage ();
        return getMessage (messageID, text == null ? throwable.getClass ().getName () : text);
    }


    /**
     * Get a text. If it starts with an @, the rest is a message ID.
     *
     * @param text The text
     * @return The text
     */
    public static String getText (final String text)
    {
        final String t = noEmptyString (text);
        if (t == null)
            return "";
        return t.charAt (0) == '@' ? getMessage (t.substring (1)) : t;
    }


    /**
     * Returns null for empty strings.
     *
     * @param text The text
     * @return The text or null
     */
    public static String noEmptyString (final String text)
    {
        return text == null || text.isEmpty () ? null : text;
    }


    /**
     * Returns an empty string for null.
     *
     * @param text The text
     * @return The text
     */
    public static String noNullString (final String text)
    {
        return text == null ? "" : text;
    }


    /**
     * Replace %1, %2, ... in a text.
     *
     * @param text The text
     * @param replaceStrings The replacements
     * @return The text
     */
    public static String replacePercentNWithStrings (final String text, final String [] replaceStrings)
    {
        String result = text;
        if (replaceStrings == null)
            return result;
        for (int i = 0; i < replaceStrings.length; i++)
        {
            final String placeholder = "%" + (i + 1);
            final int index = result.indexOf (placeholder);
            if (index != -1 && replaceStrings[i] != null)
                result = result.substring (0, index) + replaceStrings[i] + result.substring (index + 2);
        }
        return result;
    }


    /**
     * Read a text resource.
     *
     * @param path The path of the resource
     * @return The content
     * @throws IOException Could not read
     */
    public static String textFileFor (final String path) throws IOException
    {
        return new String (rawFileFor (path), StandardCharsets.UTF_8);
    }


    /**
     * Read a binary resource.
     *
     * @param path The path of the resource
     * @return The content
     * @throws IOException Could not read
     */
    public static byte [] rawFileFor (final String path) throws IOException
    {
        final String name = path.startsWith ("/") ? path.substring (1) : path;
        try (final InputStream in = Functions.class.getClassLoader ().getResourceAsStream (name))
        {
            if (in == null)
                throw new IOException ("Resource not found: " + path);
            return in.readAllBytes ();
        }
    }
}
