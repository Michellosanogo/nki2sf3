// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import de.mossgrabers.convertwithmoss.core.model.IAudioMetadata;
import de.mossgrabers.convertwithmoss.core.model.IGroup;
import de.mossgrabers.convertwithmoss.core.model.ISampleData;
import de.mossgrabers.convertwithmoss.core.model.ISampleLoop;
import de.mossgrabers.convertwithmoss.core.model.ISampleZone;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultGroup;
import de.mossgrabers.convertwithmoss.exception.CombinationNotPossibleException;
import de.mossgrabers.convertwithmoss.format.KeyMapping;
import de.mossgrabers.convertwithmoss.format.wav.WavFileSampleData;


/**
 * Enumeration for different channel configurations of zones.
 *
 * @author Jürgen Moßgraber
 */
public enum ZoneChannels
{
    /** All zones reference mono samples. */
    MONO,
    /** All zones reference stereo samples. */
    STEREO,
    /** All zones reference mono samples which are either hard panned left or right. */
    SPLIT_STEREO,
    /** Mixed mono and stereo samples. */
    MIXED;


    private static final SampleZoneComparator SAMPLE_ZONE_COMPARATOR = new SampleZoneComparator ();


    /**
     * Checks for the channel setup across all zones of the given groups.
     *
     * @param groups The groups to check
     * @return The channel configuration
     * @throws IOException Could not detect the number of channels
     */
    public static ZoneChannels detectChannelConfiguration (final List<IGroup> groups) throws IOException
    {
        Boolean stereo = null;
        Boolean splitStereo = null;

        for (final IGroup group: groups)
            for (final ISampleZone sampleZone: group.getSampleZones ())
            {
                final Optional<ISampleData> sampleData = sampleZone.getSampleData ();
                if (sampleData.isEmpty ())
                    continue;
                final boolean isStereo = sampleData.get ().getAudioMetadata ().getChannels () == 2;
                if (stereo == null)
                {
                    // First iteration, store if mono or stereo
                    stereo = Boolean.valueOf (isStereo);
                    // If it is already stereo, it cannot be split stereo
                    if (isStereo && splitStereo == null)
                        splitStereo = Boolean.FALSE;
                }
                else
                {
                    // Mixed mono/stereo
                    if (stereo.booleanValue () != isStereo)
                        return ZoneChannels.MIXED;

                    // Check for split stereo which needs to be hard panned left or right
                    if (!isStereo && (splitStereo == null || splitStereo.booleanValue ()))
                    {
                        final double panning = sampleZone.getPanning ();
                        splitStereo = Boolean.valueOf (panning <= -1 || panning >= 1);
                    }
                }
            }

        if (stereo != null && stereo.booleanValue ())
            return ZoneChannels.STEREO;

        return splitStereo != null && splitStereo.booleanValue () ? ZoneChannels.SPLIT_STEREO : ZoneChannels.MONO;
    }


    /**
     * Checks if hard panned mono zones really are the left and right channel of one recording. A
     * wide sound is often created by layering the same mono samples hard panned left and right and
     * detuning the two layers against each other. Such zones look like split stereo but combining
     * them creates a dual mono file and discards the tuning of one of the layers, so they have to
     * be kept as the separate layers they are.
     *
     * @param groups The groups to check, must have been detected as {@link #SPLIT_STEREO}
     * @return True if the zones really are split stereo and may be combined
     */
    public static boolean isSplitStereo (final List<IGroup> groups)
    {
        final List<ISampleZone> leftSampleZones = new ArrayList<> ();
        final List<ISampleZone> rightSampleZones = new ArrayList<> ();
        ZoneChannels.getSplitStereo (groups, leftSampleZones, rightSampleZones);

        // Zones which do not pair up are left to the combination itself, which fails there as
        // before
        final int size = leftSampleZones.size ();
        if (size == 0 || size != rightSampleZones.size ())
            return true;

        // Sort both arrays so that the matching pairs are at the same index, the same way the
        // combination does it
        Collections.sort (leftSampleZones, SAMPLE_ZONE_COMPARATOR);
        Collections.sort (rightSampleZones, SAMPLE_ZONE_COMPARATOR);

        for (int i = 0; i < size; i++)
        {
            final ISampleZone leftSampleZone = leftSampleZones.get (i);
            final ISampleZone rightSampleZone = rightSampleZones.get (i);
            // The two channels of one recording are two different samples which share their
            // tuning and their mapping
            if (leftSampleZone.getName ().equals (rightSampleZone.getName ()) || !areMappedAlike (leftSampleZone, rightSampleZone))
                return false;
        }

        return true;
    }


    /**
     * Test if two zones are mapped alike, which the two channels of one recording are. The pairs
     * are matched by their position in the sorted lists, which pairs zones of different ranges when
     * the left and the right zones are not the same set - e.g. two velocity layers, one panned hard
     * left and one hard right - and those must not be combined into stereo samples.
     *
     * @param leftSampleZone The zone panned hard left
     * @param rightSampleZone The zone panned hard right
     * @return True if they share their key range, root note, velocity range, play range and tuning
     */
    private static boolean areMappedAlike (final ISampleZone leftSampleZone, final ISampleZone rightSampleZone)
    {
        if (leftSampleZone.getKeyRoot () != rightSampleZone.getKeyRoot () || leftSampleZone.getKeyLow () != rightSampleZone.getKeyLow () || leftSampleZone.getKeyHigh () != rightSampleZone.getKeyHigh ())
            return false;
        if (leftSampleZone.getVelocityLow () != rightSampleZone.getVelocityLow () || leftSampleZone.getVelocityHigh () != rightSampleZone.getVelocityHigh () || leftSampleZone.getStart () != rightSampleZone.getStart () || leftSampleZone.getStop () != rightSampleZone.getStop ())
            return false;
        return Math.abs (leftSampleZone.getTuning () - rightSampleZone.getTuning ()) <= 0.0001;
    }


    /**
     * Creates stereo sample zones (with stereo sample files) from split stereo sample zones.
     * Important: the input must have been checked to be split stereo with the
     * detectChannelConfiguration method.
     *
     * @param groups The groups containing the sample zones
     * @return The group containing all resulting stereo sample zones if combination is possible
     * @throws IOException Could not combine the files
     */
    public static Optional<IGroup> combineSplitStereo (final List<IGroup> groups) throws IOException
    {
        // First, separate hard panned left/right channels
        final List<ISampleZone> leftSampleZones = new ArrayList<> ();
        final List<ISampleZone> rightSampleZones = new ArrayList<> ();
        ZoneChannels.getSplitStereo (groups, leftSampleZones, rightSampleZones);
        return combineSplitStereo (leftSampleZones, rightSampleZones);
    }


    /**
     * Creates stereo sample zones (with stereo sample files) from split stereo sample zones.
     * Important: the input must have been checked to be split stereo with the
     * detectChannelConfiguration method.
     *
     * @param leftSampleZones All sample zones of the left channel
     * @param rightSampleZones All sample zones of the right channel
     * @return The group containing all resulting stereo sample zones if combination is possible
     * @throws IOException Could not combine the files
     */
    public static Optional<IGroup> combineSplitStereo (final List<ISampleZone> leftSampleZones, final List<ISampleZone> rightSampleZones) throws IOException
    {
        // Size of left/right must match
        final int size = leftSampleZones.size ();
        if (size != rightSampleZones.size ())
            return Optional.empty ();

        // Sort both arrays by all of their relevant attributes which means that the matching pairs
        // are at the same index
        Collections.sort (leftSampleZones, SAMPLE_ZONE_COMPARATOR);
        Collections.sort (rightSampleZones, SAMPLE_ZONE_COMPARATOR);

        // Audio metadata must match as well as the loops of the left/right pairs!
        for (int i = 0; i < size; i++)
            if (!compareSampleZones (leftSampleZones.get (i), rightSampleZones.get (i)))
                return Optional.empty ();

        // Finally, combine the left/right pairs
        final IGroup group = new DefaultGroup ();
        for (int i = 0; i < size; i++)
        {
            final ByteArrayOutputStream leftBuffer = new ByteArrayOutputStream ();
            final ByteArrayOutputStream rightBuffer = new ByteArrayOutputStream ();
            final ISampleZone leftSampleZone = leftSampleZones.get (i);
            final ISampleZone rightSampleZone = rightSampleZones.get (i);
            final Optional<ISampleData> leftSampleData = leftSampleZone.getSampleData ();
            final Optional<ISampleData> rightSampleData = rightSampleZone.getSampleData ();
            if (leftSampleData.isEmpty () || rightSampleData.isEmpty ())
                throw new IOException ("Empty sample in the source.");
            leftSampleData.get ().writeSample (leftBuffer);
            rightSampleData.get ().writeSample (rightBuffer);
            try (final InputStream inLeft = new ByteArrayInputStream (leftBuffer.toByteArray ()); final InputStream inRight = new ByteArrayInputStream (rightBuffer.toByteArray ()))
            {
                leftSampleZone.setSampleData (new WavFileSampleData (inLeft).combine (new WavFileSampleData (inRight)));
            }
            catch (final CombinationNotPossibleException ex)
            {
                throw new IOException (ex);
            }

            leftSampleZone.setPanning (0);
            leftSampleZone.setName (createCombinedName (leftSampleZone.getName (), rightSampleZone.getName ()));

            group.addSampleZone (leftSampleZone);
        }

        return Optional.of (group);
    }


    /**
     * Create the name of a stereo zone from the names of its two channels: the part they share. The
     * channel is usually marked at the end of the name ('Piano C3 L', 'Piano C3 R'), sometimes at
     * its start ('L Piano C3'); a name which is not shared at all is kept as the left one, since an
     * empty name would make all combined zones write the same sample file.
     *
     * @param leftName The name of the left channel
     * @param rightName The name of the right channel
     * @return The combined name
     */
    private static String createCombinedName (final String leftName, final String rightName)
    {
        String commonName = KeyMapping.findCommonPrefix (leftName, rightName);
        if (commonName.endsWith ("_") || commonName.endsWith ("-"))
            commonName = commonName.substring (0, commonName.length () - 1);
        commonName = commonName.trim ();
        if (!commonName.isEmpty ())
            return commonName;

        // A suffix is only shared from a separator on, otherwise 'left_C3' and 'right_C3' would
        // share 't_C3'
        final String commonSuffix = findCommonSuffix (leftName, rightName);
        for (int i = 0; i < commonSuffix.length (); i++)
            if (isSeparator (commonSuffix.charAt (i)))
            {
                commonName = commonSuffix.substring (i + 1).trim ();
                if (!commonName.isEmpty ())
                    return commonName;
                break;
            }
        return leftName;
    }


    /**
     * Test if a character separates the words of a name.
     *
     * @param character The character
     * @return True if it is a separator
     */
    private static boolean isSeparator (final char character)
    {
        return character == '_' || character == '-' || Character.isWhitespace (character);
    }


    /**
     * Find the common suffix of two names.
     *
     * @param first The first name
     * @param second The second name
     * @return The common suffix, empty if there is none
     */
    private static String findCommonSuffix (final String first, final String second)
    {
        int length = 0;
        while (length < first.length () && length < second.length () && first.charAt (first.length () - 1 - length) == second.charAt (second.length () - 1 - length))
            length++;
        return first.substring (first.length () - length);
    }


    /**
     * Splits all sample zones from all groups into left/right arrays.
     *
     * @param groups All groups
     * @param leftSampleZones All samples zones which are panned hard left
     * @param rightSampleZones All samples zones which are panned hard right
     */
    private static void getSplitStereo (final List<IGroup> groups, final List<ISampleZone> leftSampleZones, final List<ISampleZone> rightSampleZones)
    {
        for (final IGroup group: groups)
            for (final ISampleZone sampleZone: group.getSampleZones ())
                if (sampleZone.getPanning () <= -1)
                    leftSampleZones.add (sampleZone);
                else
                    rightSampleZones.add (sampleZone);
    }


    private static boolean compareSampleZones (final ISampleZone leftSampleZone, final ISampleZone rightSampleZone) throws IOException
    {
        if (!areMappedAlike (leftSampleZone, rightSampleZone))
            return false;

        final List<ISampleLoop> loopsLeft = leftSampleZone.getLoops ();
        final List<ISampleLoop> loopsRight = rightSampleZone.getLoops ();
        if (loopsLeft.size () != loopsRight.size ())
            return false;
        if (!loopsLeft.isEmpty ())
        {
            final ISampleLoop loopLeft = loopsLeft.get (0);
            final ISampleLoop loopRight = loopsRight.get (0);
            if (loopLeft.getStart () != loopRight.getStart () || loopLeft.getEnd () != loopRight.getEnd () || loopLeft.getType () != loopRight.getType ())
                return false;
        }

        final Optional<ISampleData> leftSampleData = leftSampleZone.getSampleData ();
        final Optional<ISampleData> rightSampleData = rightSampleZone.getSampleData ();
        if (leftSampleData.isEmpty () || rightSampleData.isEmpty ())
            throw new IOException ("Empty sample in the source.");
        final IAudioMetadata metadataLeft = leftSampleData.get ().getAudioMetadata ();
        final IAudioMetadata metadataRight = rightSampleData.get ().getAudioMetadata ();
        return metadataLeft.getNumberOfSamples () == metadataRight.getNumberOfSamples () && metadataLeft.getBitResolution () == metadataRight.getBitResolution () && metadataLeft.getSampleRate () == metadataRight.getSampleRate ();
    }


    private static class SampleZoneComparator implements Comparator<ISampleZone>
    {
        /** {@inheritDoc} */
        @Override
        public int compare (final ISampleZone o1, final ISampleZone o2)
        {
            int result = Integer.compare (o1.getKeyRoot (), o2.getKeyRoot ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getKeyLow (), o2.getKeyLow ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getKeyHigh (), o2.getKeyHigh ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getNoteCrossfadeLow (), o2.getNoteCrossfadeLow ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getNoteCrossfadeHigh (), o2.getNoteCrossfadeHigh ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getVelocityLow (), o2.getVelocityLow ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getVelocityHigh (), o2.getVelocityHigh ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getVelocityCrossfadeLow (), o2.getVelocityCrossfadeLow ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getVelocityCrossfadeHigh (), o2.getVelocityCrossfadeHigh ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getStart (), o2.getStart ());
            if (result != 0)
                return result;

            result = Integer.compare (o1.getStop (), o2.getStop ());
            if (result != 0)
                return result;

            result = Double.compare (o1.getTuning (), o2.getTuning ());
            if (result != 0)
                return result;

            result = o1.getTrigger ().ordinal () - o2.getTrigger ().ordinal ();
            if (result != 0)
                return result;

            return o1.getName ().compareTo (o2.getName ());
        }
    }
}
