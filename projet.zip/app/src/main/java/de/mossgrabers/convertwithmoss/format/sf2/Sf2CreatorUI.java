// Headless version for Android (no JavaFX). Based on the work of Jürgen Moßgraber - mossgrabers.de
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.format.sf2;

import java.util.Map;

import de.mossgrabers.convertwithmoss.core.INotifier;
import de.mossgrabers.convertwithmoss.core.settings.ICoreTaskSettings;
import de.mossgrabers.tools.ui.BasicConfig;


/**
 * Settings for the SoundFont 2 creator (no user interface on Android).
 */
public class Sf2CreatorUI implements ICoreTaskSettings
{
    private static final String    SF2_DOWNSAMPLE_TO_16BIT = "Sf2DownsampleTo16Bit";
    private static final String [] CLI_PARAMETER_NAMES     =
    {
        SF2_DOWNSAMPLE_TO_16BIT
    };

    private boolean                resampleTo16Bit;


    /** {@inheritDoc} */
    @Override
    public void loadSettings (final BasicConfig config)
    {
        // Not used on Android
    }


    /** {@inheritDoc} */
    @Override
    public void saveSettings (final BasicConfig config)
    {
        // Not used on Android
    }


    /** {@inheritDoc} */
    @Override
    public boolean checkSettingsUI (final INotifier notifier)
    {
        return true;
    }


    /** {@inheritDoc} */
    @Override
    public boolean checkSettingsCLI (final INotifier notifier, final Map<String, String> parameters)
    {
        final String value = parameters.remove (SF2_DOWNSAMPLE_TO_16BIT);
        this.resampleTo16Bit = "1".equals (value);
        return true;
    }


    /** {@inheritDoc} */
    @Override
    public String [] getCLIParameterNames ()
    {
        return CLI_PARAMETER_NAMES;
    }


    /**
     * Should 24-bit audio be re-sampled to 16-bit?
     *
     * @return True to re-sample
     */
    public boolean isDownsampleTo16Bit ()
    {
        return this.resampleTo16Bit;
    }
}
