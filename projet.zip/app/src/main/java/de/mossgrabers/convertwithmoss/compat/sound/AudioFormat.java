package de.mossgrabers.convertwithmoss.compat.sound;

/** Audio format description (replacement for javax.sound.sampled.AudioFormat). */
public class AudioFormat
{
    /** The encoding of the audio data. */
    public static class Encoding
    {
        /** Signed PCM. */
        public static final Encoding PCM_SIGNED   = new Encoding ("PCM_SIGNED");
        /** Unsigned PCM. */
        public static final Encoding PCM_UNSIGNED = new Encoding ("PCM_UNSIGNED");
        /** Floating point PCM. */
        public static final Encoding PCM_FLOAT    = new Encoding ("PCM_FLOAT");
        /** u-law. */
        public static final Encoding ULAW         = new Encoding ("ULAW");
        /** a-law. */
        public static final Encoding ALAW         = new Encoding ("ALAW");

        private final String         name;


        /**
         * Constructor.
         *
         * @param name The name
         */
        public Encoding (final String name)
        {
            this.name = name;
        }


        /** {@inheritDoc} */
        @Override
        public boolean equals (final Object obj)
        {
            return obj instanceof final Encoding other && this.name.equals (other.name);
        }


        /** {@inheritDoc} */
        @Override
        public int hashCode ()
        {
            return this.name.hashCode ();
        }


        /** {@inheritDoc} */
        @Override
        public String toString ()
        {
            return this.name;
        }
    }

    private final Encoding encoding;
    private final float    sampleRate;
    private final int      sampleSizeInBits;
    private final int      channels;
    private final int      frameSize;
    private final float    frameRate;
    private final boolean  bigEndian;


    /**
     * Constructor.
     *
     * @param encoding The encoding
     * @param sampleRate The sample rate
     * @param sampleSizeInBits The bits per sample
     * @param channels The number of channels
     * @param frameSize The size of a frame in bytes
     * @param frameRate The frame rate
     * @param bigEndian True if big endian
     */
    public AudioFormat (final Encoding encoding, final float sampleRate, final int sampleSizeInBits, final int channels, final int frameSize, final float frameRate, final boolean bigEndian)
    {
        this.encoding = encoding;
        this.sampleRate = sampleRate;
        this.sampleSizeInBits = sampleSizeInBits;
        this.channels = channels;
        this.frameSize = frameSize;
        this.frameRate = frameRate;
        this.bigEndian = bigEndian;
    }


    /**
     * Constructor for PCM formats.
     *
     * @param sampleRate The sample rate
     * @param sampleSizeInBits The bits per sample
     * @param channels The number of channels
     * @param signed True if signed
     * @param bigEndian True if big endian
     */
    public AudioFormat (final float sampleRate, final int sampleSizeInBits, final int channels, final boolean signed, final boolean bigEndian)
    {
        this (signed ? Encoding.PCM_SIGNED : Encoding.PCM_UNSIGNED, sampleRate, sampleSizeInBits, channels, (sampleSizeInBits + 7) / 8 * channels, sampleRate, bigEndian);
    }


    /**
     * Get the encoding.
     *
     * @return The encoding
     */
    public Encoding getEncoding ()
    {
        return this.encoding;
    }


    /**
     * Get the sample rate.
     *
     * @return The sample rate
     */
    public float getSampleRate ()
    {
        return this.sampleRate;
    }


    /**
     * Get the sample size.
     *
     * @return The bits per sample
     */
    public int getSampleSizeInBits ()
    {
        return this.sampleSizeInBits;
    }


    /**
     * Get the number of channels.
     *
     * @return The channels
     */
    public int getChannels ()
    {
        return this.channels;
    }


    /**
     * Get the size of a frame.
     *
     * @return The size in bytes
     */
    public int getFrameSize ()
    {
        return this.frameSize;
    }


    /**
     * Get the frame rate.
     *
     * @return The frame rate
     */
    public float getFrameRate ()
    {
        return this.frameRate;
    }


    /**
     * Is the data big endian?
     *
     * @return True if big endian
     */
    public boolean isBigEndian ()
    {
        return this.bigEndian;
    }
}
