// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.format.ni.kontakt.type;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.List;
import java.util.Optional;

import de.mossgrabers.convertwithmoss.core.IInstrumentSource;
import de.mossgrabers.convertwithmoss.core.IMultisampleSource;
import de.mossgrabers.convertwithmoss.core.IPerformanceSource;
import de.mossgrabers.convertwithmoss.core.settings.IMetadataConfig;


/**
 * Interface to read/write a specific Kontakt format.
 *
 * @author Jürgen Moßgraber
 */
public interface IKontaktFormat
{
    /**
     * Read and parse a file which uses this format type from the given random access file.
     *
     * @param sourceFolder The top source folder for the detection
     * @param sourceFile The source file which contains the XML document
     * @param fileAccess The random access file to read from
     * @return The parsed multi-sample sources
     * @param metadataConfig Default metadata
     * @throws IOException Error reading the file
     */
    List<IMultisampleSource> readNKI (File sourceFolder, File sourceFile, RandomAccessFile fileAccess, IMetadataConfig metadataConfig) throws IOException;


    /**
     * Write a new NKI file from the given multi-sample source.
     *
     * @param out Where to write the data
     * @param safeSampleFolderName The folder where the samples are placed
     * @param multisampleSource The source
     * @param sizeOfSamples The size of all samples
     * @throws IOException Error writing the file
     */
    void writeNKI (OutputStream out, String safeSampleFolderName, IMultisampleSource multisampleSource, int sizeOfSamples) throws IOException;


    /**
     * Read and parse a file which uses this format type from the given random access file.
     *
     * @param sourceFolder The top source folder for the detection
     * @param sourceFile The source file which contains the XML document
     * @param fileAccess The random access file to read from
     * @return The parsed multi-sample sources
     * @param metadataConfig Default metadata
     * @throws IOException Error reading the file
     */
    Optional<IPerformanceSource> readNKM (File sourceFolder, File sourceFile, RandomAccessFile fileAccess, IMetadataConfig metadataConfig) throws IOException;


    /**
     * Write a new NKM file from the given instrument sources (up to 64).
     *
     * @param out Where to write the data
     * @param bankName The name of the bank
     * @param safeSampleFolderNames The folders where the samples are placed. Must be of the same
     *            size as multisampleSources!
     * @param instrumentSources The instrument sources
     * @param sizeOfSamples The size of all samples
     * @throws IOException Error writing the file
     */
    void writeNKM (OutputStream out, String bankName, List<String> safeSampleFolderNames, List<IInstrumentSource> instrumentSources, int sizeOfSamples) throws IOException;
}
