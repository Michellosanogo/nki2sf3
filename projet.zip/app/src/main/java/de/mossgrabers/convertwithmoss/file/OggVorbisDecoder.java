package de.mossgrabers.convertwithmoss.file;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


/**
 * Placeholder for the OGG Vorbis decoder, which is not available in the Android version.
 */
public final class OggVorbisDecoder
{
    private OggVorbisDecoder ()
    {
        // Intentionally empty
    }


    /**
     * Not supported in the Android version.
     *
     * @param inputFile The OGG file
     * @param outputStream Where to write the WAV data
     * @throws IOException Always
     */
    public static void decodeToWav (final File inputFile, final OutputStream outputStream) throws IOException
    {
        throw new IOException ("OGG Vorbis files are not supported in this version.");
    }


    /**
     * Not supported in the Android version.
     *
     * @param inputStream The OGG data
     * @param outputStream Where to write the WAV data
     * @throws IOException Always
     */
    public static void decodeToWav (final InputStream inputStream, final OutputStream outputStream) throws IOException
    {
        throw new IOException ("OGG Vorbis files are not supported in this version.");
    }
}
