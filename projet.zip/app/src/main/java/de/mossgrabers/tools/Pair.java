package de.mossgrabers.tools;

/**
 * A simple pair of a key and a value (compatible re-implementation for Android).
 *
 * @param <T1> The type of the key
 * @param <T2> The type of the value
 */
public class Pair<T1, T2>
{
    private T1 key;
    private T2 value;


    /**
     * Constructor.
     *
     * @param key The key
     * @param value The value
     */
    public Pair (final T1 key, final T2 value)
    {
        this.key = key;
        this.value = value;
    }


    /** Constructor. */
    public Pair ()
    {
        // Intentionally empty
    }


    /**
     * Get the key.
     *
     * @return The key
     */
    public T1 getKey ()
    {
        return this.key;
    }


    /**
     * Get the value.
     *
     * @return The value
     */
    public T2 getValue ()
    {
        return this.value;
    }


    /**
     * Set key and value.
     *
     * @param key The key
     * @param value The value
     */
    public void set (final T1 key, final T2 value)
    {
        this.key = key;
        this.value = value;
    }


    /**
     * Set the key.
     *
     * @param key The key
     */
    public void setKey (final T1 key)
    {
        this.key = key;
    }


    /**
     * Set the value.
     *
     * @param value The value
     */
    public void setValue (final T2 value)
    {
        this.value = value;
    }
}
