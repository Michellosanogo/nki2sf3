// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.format.ni.kontakt.type;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import de.mossgrabers.convertwithmoss.core.IMultisampleSource;
import de.mossgrabers.convertwithmoss.core.INotifier;
import de.mossgrabers.convertwithmoss.core.algorithm.MathUtils;
import de.mossgrabers.convertwithmoss.core.detector.AbstractDetector;
import de.mossgrabers.convertwithmoss.core.model.IEnvelopeModulator;
import de.mossgrabers.convertwithmoss.core.model.IFilter;
import de.mossgrabers.convertwithmoss.core.model.IGroup;
import de.mossgrabers.convertwithmoss.core.model.IMetadata;
import de.mossgrabers.convertwithmoss.core.model.ISampleData;
import de.mossgrabers.convertwithmoss.core.model.ISampleLoop;
import de.mossgrabers.convertwithmoss.core.model.ISampleZone;
import de.mossgrabers.convertwithmoss.core.model.enumeration.LoopType;
import de.mossgrabers.convertwithmoss.core.model.enumeration.TriggerType;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultGroup;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultSampleLoop;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultSampleZone;
import de.mossgrabers.convertwithmoss.file.AudioFileUtils;
import de.mossgrabers.convertwithmoss.format.TagDetector;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.kontakt5.ExternalModulator;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.kontakt5.Group;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.kontakt5.InternalModulator;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.kontakt5.Program;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.kontakt5.Zone;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.kontakt5.ZoneLoop;
import de.mossgrabers.tools.FileUtils;
import de.mossgrabers.tools.Pair;
import de.mossgrabers.tools.ui.Functions;


/**
 * Abstract base class for handling NKI files in a specific format.
 *
 * @author Jürgen Moßgraber
 */
public abstract class AbstractKontaktFormat implements IKontaktFormat
{
    protected final INotifier notifier;
    protected boolean         isBigEndian;


    /**
     * Constructor.
     *
     * @param notifier Where to report errors
     */
    protected AbstractKontaktFormat (final INotifier notifier)
    {
        this.notifier = notifier;
    }


    /**
     * Fill the given multi-sample instance with data from the program.
     *
     * @param multiSample The multi-sample to fill
     * @param program The program from which to get the data
     * @param parts Parts of the name for category detection
     * @param filePaths All file paths
     * @param isMonolith True if all files are stored in a monolith
     * @throws IOException Error finding samples
     */
    @SuppressWarnings("null")
    public void fillInto (final IMultisampleSource multiSample, final Program program, final String [] parts, final List<String> filePaths, final boolean isMonolith) throws IOException
    {
        setMetadata (multiSample, program, parts);

        final List<File> files = this.lookupFiles (filePaths, multiSample.getSourceFile ().getParent (), isMonolith);
        final Map<Integer, Pair<IGroup, Group>> indexedGroups = createGroups (program);
        // The soloed state of the groups is only in effect if the program has group solo enabled;
        // otherwise the flags of the groups are left-overs of a previously active solo
        final boolean hasSoloedGroup = program.isGroupSolo () && program.getGroups ().stream ().anyMatch (Group::isSoloed);
        for (final Zone kontaktZone: program.getZones ())
        {
            // Zones without a sample file might be present
            if (kontaktZone.getFilenameId () < 0)
                continue;

            final Integer groupIndex = Integer.valueOf (kontaktZone.getGroupIndex ());
            final Pair<IGroup, Group> groupPair = indexedGroups.get (groupIndex);
            if (groupPair == null)
                throw new IOException (Functions.getMessage ("IDS_NKI5_MISSING_GROUP", groupIndex.toString ()));

            // A muted group does not sound; if any group is soloed only the soloed groups sound.
            // Without this, alternate articulations stored in muted groups stack onto the active
            // ones
            final Group zoneKontaktGroup = groupPair.getValue ();
            if (hasSoloedGroup ? !zoneKontaktGroup.isSoloed () : zoneKontaktGroup.isMuted ())
                continue;

            final IGroup group = groupPair.getKey ();
            final Group kontaktGroup = groupPair.getValue ();

            final ISampleZone zone = this.createZone (kontaktZone, files);
            group.addSampleZone (zone);

            zone.setStart (kontaktZone.getSampleStart ());
            zone.setStop (kontaktZone.getNumFrames () - kontaktZone.getSampleEnd ());

            zone.setKeyLow (kontaktZone.getLowKey ());
            zone.setKeyHigh (kontaktZone.getHighKey ());
            final int rootKey = kontaktZone.getRootKey ();
            zone.setKeyRoot (rootKey);

            final float volume = program.getInstrumentVolume () * kontaktGroup.getVolume () * kontaktZone.getZoneVolume ();
            zone.setGain (MathUtils.valueToDb (volume));
            zone.setPanning (Math.clamp (program.getInstrumentPan () + kontaktGroup.getPan () + kontaktZone.getZonePan (), -1, 1));

            zone.setTuning (calculateTune (kontaktZone.getZoneTune (), kontaktGroup.getTune (), program.getInstrumentTune ()));
            zone.setKeyTracking (kontaktGroup.isKeyTracking () ? 1 : 0);

            zone.setVelocityLow (kontaktZone.getLowVelocity ());
            zone.setVelocityHigh (kontaktZone.getHighVelocity ());

            zone.setNoteCrossfadeLow (kontaktZone.getFadeLowKey ());
            zone.setNoteCrossfadeHigh (kontaktZone.getFadeHighKey ());
            zone.setVelocityCrossfadeLow (kontaktZone.getFadeLowVelocity ());
            zone.setVelocityCrossfadeHigh (kontaktZone.getFadeHighVelocity ());

            // Only on a group level...
            zone.setReversed (kontaktGroup.isReverse ());

            // Kontakt stores the voice group as a zero based index with -1 for 'no group' but the
            // model uses 0 for 'no group', therefore the index is shifted by one
            final int voiceGroupIdx = kontaktGroup.getVoiceGroupIdx ();
            zone.setExclusiveGroup (voiceGroupIdx < 0 ? 0 : voiceGroupIdx + 1);

            // IMPROVE Fill Filter info, when understood where it is stored
            final IFilter filter = null;

            // Set pitch by pitch-bend and amplitude by velocity modulation
            boolean foundAmpVelocity = false;
            for (final ExternalModulator modulator: kontaktGroup.getExternalModulators ())
            {
                final long sourceType = modulator.getSourceType ();
                final long destType = modulator.getDestType ();
                if (sourceType == ExternalModulator.SOURCE_PITCHBEND && (destType == ExternalModulator.DEST_PITCH || destType == ExternalModulator.DEST_PITCH2))
                {
                    final int cents = Math.round (modulator.getIntensity () * 12) * 100;
                    zone.setBendUp (cents);
                    zone.setBendDown (-cents);
                }
                else if ((sourceType == ExternalModulator.SOURCE_VELOCITY || sourceType == ExternalModulator.SOURCE_VELOCITY2) && (destType == ExternalModulator.DEST_VOLUME || destType == ExternalModulator.DEST_VOLUME2 || destType == ExternalModulator.DEST_VOLUME3))
                {
                    zone.getAmplitudeVelocityModulator ().setDepth (modulator.getIntensity ());
                    // The volume of Kontakt maps its normalized value to decibels with
                    // 60*log10(x). The velocity modulation therefore scales the amplitude with
                    // x^3, which is a convex curve (+1)
                    zone.getAmplitudeVelocityModulator ().setCurve (1);
                    foundAmpVelocity = true;
                }
            }
            if (!foundAmpVelocity)
                zone.getAmplitudeVelocityModulator ().setDepth (0);

            // Set amplitude and pitch modulator
            for (final InternalModulator modulator: kontaktGroup.getInternalModulators ())
            {
                final Optional<IEnvelopeModulator> volumeEnvelope = modulator.getVolumeEnvelope ();
                if (volumeEnvelope.isPresent ())
                {
                    final IEnvelopeModulator amplitudeEnvelopeModulator = zone.getAmplitudeEnvelopeModulator ();
                    final IEnvelopeModulator kontaktEnvelopeModulator = volumeEnvelope.get ();
                    amplitudeEnvelopeModulator.setDepth (kontaktEnvelopeModulator.getDepth ());
                    amplitudeEnvelopeModulator.setSource (kontaktEnvelopeModulator.getSource ());
                }
                final Optional<IEnvelopeModulator> pitchEnvelope = modulator.getPitchEnvelope ();
                if (pitchEnvelope.isPresent ())
                {
                    final IEnvelopeModulator pitchModulator = zone.getPitchEnvelopeModulator ();
                    final IEnvelopeModulator kontaktPitchModulator = pitchEnvelope.get ();
                    pitchModulator.setDepth (kontaktPitchModulator.getDepth ());
                    pitchModulator.setSource (kontaktPitchModulator.getSource ());
                }
                if (filter != null)
                {
                    final Optional<IEnvelopeModulator> cutoffEnvelope = modulator.getFilterCutoffEnvelope ();
                    if (cutoffEnvelope.isPresent ())
                    {
                        final IEnvelopeModulator cutoffModulator = filter.getCutoffEnvelopeModulator ();
                        final IEnvelopeModulator kontaktCutoffModulator = cutoffEnvelope.get ();
                        cutoffModulator.setDepth (kontaktCutoffModulator.getDepth ());
                        cutoffModulator.setSource (kontaktCutoffModulator.getSource ());
                    }
                }
            }

            for (final ZoneLoop zoneLoop: kontaktZone.getLoops ())
            {
                final ISampleLoop loop = new DefaultSampleLoop ();
                final int loopMode = zoneLoop.getMode ();
                // A one-shot ignores note-off events and has no loop
                if (loopMode == ZoneLoop.MODE_ONESHOT)
                    zone.setOneShot (true);
                if (loopMode == ZoneLoop.MODE_UNTIL_END || loopMode == ZoneLoop.MODE_UNTIL_RELEASE)
                {
                    loop.setType (zoneLoop.isAlternating () ? LoopType.ALTERNATING : LoopType.FORWARDS);
                    loop.setLoopUntilRelease (loopMode == ZoneLoop.MODE_UNTIL_RELEASE);
                    loop.setStart (zoneLoop.getLoopStart ());
                    // The length is the number of frames of the loop, the end of the model is
                    // inclusive
                    loop.setEnd (zoneLoop.getLoopStart () + zoneLoop.getLoopLength () - 1);
                    loop.setTuning (12.0 * (Math.log (zoneLoop.getLoopTuning ()) / Math.log (2.0)));
                    loop.setCrossfadeInSamples (zoneLoop.getCrossfadeLength ());
                    zone.addLoop (loop);
                }
            }
        }

        final List<IGroup> sampleGroups = new ArrayList<> ();
        for (final Pair<IGroup, Group> pair: indexedGroups.values ())
            sampleGroups.add (pair.getKey ());
        multiSample.setGroups (sampleGroups);
    }


    private static void setMetadata (final IMultisampleSource source, final Program program, final String [] parts)
    {
        source.setName (program.getName ());

        final IMetadata metadata = source.getMetadata ();

        final String instrumentAuthor = program.getInstrumentAuthor ();
        if (instrumentAuthor != null && !instrumentAuthor.isBlank ())
            metadata.setCreator (instrumentAuthor);
        final String instrumentURL = program.getInstrumentURL ();
        if (instrumentURL != null && !instrumentURL.isBlank ())
            metadata.setDescription ("Website : " + instrumentURL);

        // The icons 'New' (the default) and 'Wave' (a waveform, the generic icon of a sampled
        // sound)
        // say nothing about the category, which is then detected from the names instead
        final String instrumentIconName = program.getInstrumentIconName ();
        if (instrumentIconName == null || instrumentIconName.isBlank () || "New".equals (instrumentIconName) || "Wave".equals (instrumentIconName))
            metadata.setCategory (TagDetector.detectCategory (Collections.singletonList (parts[0]), Arrays.asList (AudioFileUtils.getFolderNames (parts)), false));
        else
            metadata.setCategory (TagDetector.detectCategory (instrumentIconName.split (" ")));
    }


    private static Map<Integer, Pair<IGroup, Group>> createGroups (final Program program)
    {
        final Map<Integer, Pair<IGroup, Group>> map = new TreeMap<> ();
        final List<Group> groups = program.getGroups ();
        for (int i = 0; i < groups.size (); i++)
        {
            final Group kontaktGroup = groups.get (i);
            final IGroup group = new DefaultGroup ();
            group.setName (kontaktGroup.getName ());
            if (kontaktGroup.isReleaseTrigger ())
                group.setTrigger (TriggerType.RELEASE);

            // Additionally record the group values on the group. Note that they are (and must stay)
            // multiplied into each of the sample zones as well, see fillInto. A creator must
            // therefore apply either the group or the zone value but never both.
            final double groupVolume = kontaktGroup.getVolume ();
            if (groupVolume != 1)
                group.setGain (MathUtils.valueToDb (groupVolume));
            // The panning is already stored in the range of [-1..1]
            final double groupPan = kontaktGroup.getPan ();
            if (groupPan != 0)
                group.setPanning (Math.clamp (groupPan, -1, 1));
            // The tuning is stored logarithmically as a frequency ratio, 1 is the neutral value
            final double groupTune = kontaktGroup.getTune ();
            if (groupTune > 0 && groupTune != 1)
                group.setTuning (Math.round (12.0 * Math.log (groupTune) / Math.log (2) * 100000) / 100000.0);

            map.put (Integer.valueOf (i), new Pair<> (group, kontaktGroup));
        }
        return map;
    }


    private List<File> lookupFiles (final List<String> filePaths, final String sourceFilePath, final boolean isMonolith)
    {
        int missingFiles = 0;

        final List<File> files = new ArrayList<> ();
        for (final String filename: filePaths)
        {
            File sampleFile = new File (filename);
            if ((sampleFile.isAbsolute () || filename.startsWith ("/Volumes")) && !sampleFile.exists ())
                sampleFile = new File (sourceFilePath, sampleFile.getName ());
            else
            {
                sampleFile = new File (sourceFilePath, filename);
                if (!sampleFile.exists ())
                    sampleFile = new File (sourceFilePath, sampleFile.getName ());
            }

            if (!sampleFile.exists ())
                missingFiles++;

            files.add (sampleFile);
        }

        // Only search for missing files, if all of them are missing!
        if (isMonolith || missingFiles != files.size ())
            return files;

        final List<File> lookedupFiles = new ArrayList<> ();
        File previousFolder = null;

        for (final File sampleFile: files)
        {
            // Find the sample file starting 2 folders up
            final int height = 2;
            final File file = AbstractDetector.findSampleFile (this.notifier, sampleFile.getParentFile (), previousFolder, sampleFile.getName (), height);
            if (file != null && file.exists ())
            {
                lookedupFiles.add (file);
                previousFolder = file.getParentFile ();
            }
            else
                lookedupFiles.add (sampleFile);
        }
        return lookedupFiles;
    }


    private ISampleZone createZone (final Zone zone, final List<File> files) throws IOException
    {
        final int filenameId = zone.getFilenameId ();
        if (filenameId < 0 || filenameId >= files.size ())
            throw new IOException (Functions.getMessage ("IDS_NKI5_WRONG_FILE_INDEX", Integer.toString (filenameId)));

        // Check if it is an absolute path, try to find the sample file...
        final File sampleFile = files.get (filenameId);
        // Ignore non-existing files since it might be in a monolith
        final ISampleData sampleData = sampleFile.exists () ? AbstractDetector.createSampleData (sampleFile, this.notifier) : null;
        return new DefaultSampleZone (FileUtils.getNameWithoutType (sampleFile), sampleData);
    }


    private static double calculateTune (final double zoneTune, final double groupTune, final double progTune)
    {
        // All three tune values are stored logarithmically
        final double value = 12.0 * Math.log (zoneTune * groupTune * progTune) / Math.log (2);
        return Math.round (value * 100000) / 100000.0;
    }
}
