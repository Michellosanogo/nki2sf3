package de.mossgrabers.convertwithmoss.compat.sound;

/** Audio file format description (replacement for javax.sound.sampled.AudioFileFormat). */
public class AudioFileFormat
{
    /** The type of an audio file. */
    public static class Type
    {
        /** WAV. */
        public static final Type WAVE = new Type ("WAVE", "wav");
        /** AIFF. */
        public static final Type AIFF = new Type ("AIFF", "aif");

        private final String     name;
        private final String     extension;


        /**
         * Constructor.
         *
         * @param name The name
         * @param extension The file extension
         */
        public Type (final String name, final String extension)
        {
            this.name = name;
            this.extension = extension;
        }


        /**
         * Get the file extension.
         *
         * @return The extension
         */
        public String getExtension ()
        {
            return this.extension;
        }


        /** {@inheritDoc} */
        @Override
        public boolean equals (final Object obj)
        {
            return obj instanceof final Type other && this.name.equals (other.name);
        }


        /** {@inheritDoc} */
        @Override
        public int hashCode ()
        {
            return this.name.hashCode ();
        }


        /** {@inheritDoc} */
        @Override
        public String toString ()
        {
            return this.name;
        }
    }

    private final Type        type;
    private final AudioFormat format;
    private final int         frameLength;
    private final int         byteLength;


    /**
     * Constructor.
     *
     * @param type The file type
     * @param format The audio format
     * @param frameLength The number of frames
     * @param byteLength The length of the file in bytes
     */
    public AudioFileFormat (final Type type, final AudioFormat format, final int frameLength, final int byteLength)
    {
        this.type = type;
        this.format = format;
        this.frameLength = frameLength;
        this.byteLength = byteLength;
    }


    /**
     * Get the type.
     *
     * @return The type
     */
    public Type getType ()
    {
        return this.type;
    }


    /**
     * Get the format.
     *
     * @return The format
     */
    public AudioFormat getFormat ()
    {
        return this.format;
    }


    /**
     * Get the number of frames.
     *
     * @return The frames, -1 if not specified
     */
    public int getFrameLength ()
    {
        return this.frameLength;
    }


    /**
     * Get the length of the file.
     *
     * @return The length in bytes, -1 if not specified
     */
    public int getByteLength ()
    {
        return this.byteLength;
    }
}
