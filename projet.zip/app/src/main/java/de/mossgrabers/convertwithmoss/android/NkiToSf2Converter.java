package de.mossgrabers.convertwithmoss.android;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import de.mossgrabers.convertwithmoss.core.INotifier;
import de.mossgrabers.convertwithmoss.core.IMultisampleSource;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.KontaktDetector;
import de.mossgrabers.convertwithmoss.format.sf2.Sf2Creator;
import de.mossgrabers.tools.ui.Functions;


/**
 * Converts Native Instruments Kontakt (NKI) instruments to SoundFont 2 (SF2) files. This class
 * wraps the conversion engine of ConvertWithMoss and works on normal files and folders.
 */
public final class NkiToSf2Converter implements INotifier
{
    private static final long        TIMEOUT_MINUTES = 60;

    private final Consumer<String>   logger;
    private final CountDownLatch     finished        = new CountDownLatch (1);
    private final AtomicInteger      converted       = new AtomicInteger ();
    private final AtomicInteger      failed          = new AtomicInteger ();


    /**
     * Constructor.
     *
     * @param logger Receives the log lines
     */
    public NkiToSf2Converter (final Consumer<String> logger)
    {
        this.logger = logger;
        try
        {
            Functions.init (ResourceBundle.getBundle ("Strings"));
        }
        catch (final RuntimeException ex)
        {
            // Messages stay as IDs
        }
    }


    /**
     * Convert all NKI files found in the source folder.
     *
     * @param sourceFolder The folder which contains the NKI files and the samples
     * @param outputFolder The folder to write the SF2 files to
     * @return The number of created SF2 files
     * @throws IOException Could not prepare the output folder
     * @throws InterruptedException The conversion was interrupted
     */
    public int convert (final File sourceFolder, final File outputFolder) throws IOException, InterruptedException
    {
        if (!outputFolder.isDirectory () && !outputFolder.mkdirs ())
            throw new IOException ("Cannot create " + outputFolder);

        final KontaktDetector detector = new KontaktDetector (this);
        final Sf2Creator creator = new Sf2Creator (this);
        final HashMap<String, String> detectorParameters = new HashMap<> ();
        final HashMap<String, String> creatorParameters = new HashMap<> ();
        if (!detector.getSettings ().checkSettingsCLI (this, detectorParameters) || !creator.getSettings ().checkSettingsCLI (this, creatorParameters))
            throw new IOException ("Settings are not valid.");

        final List<File> noSpecificFiles = new ArrayList<> ();
        detector.detect (sourceFolder, noSpecificFiles, source -> this.save (creator, outputFolder, source), performance -> {
            // Performances are not converted
        }, false);

        if (!this.finished.await (TIMEOUT_MINUTES, TimeUnit.MINUTES))
        {
            detector.cancel ();
            this.log ("Timeout");
        }
        return this.converted.get ();
    }


    private void save (final Sf2Creator creator, final File outputFolder, final IMultisampleSource source)
    {
        try
        {
            creator.createPreset (outputFolder, source);
            this.converted.incrementAndGet ();
        }
        catch (final IOException | RuntimeException | OutOfMemoryError ex)
        {
            this.failed.incrementAndGet ();
            this.logError (ex);
        }
    }


    /**
     * Get the number of instruments which could not be saved.
     *
     * @return The number
     */
    public int getFailedCount ()
    {
        return this.failed.get ();
    }


    /** {@inheritDoc} */
    @Override
    public void log (final String messageID, final String... replaceStrings)
    {
        this.logger.accept (Functions.getMessage (messageID, replaceStrings));
    }


    /** {@inheritDoc} */
    @Override
    public void logError (final String messageID, final String... replaceStrings)
    {
        this.logger.accept ("! " + Functions.getMessage (messageID, replaceStrings));
    }


    /** {@inheritDoc} */
    @Override
    public void logError (final String messageID, final Throwable throwable)
    {
        this.logger.accept ("! " + Functions.getMessage (messageID, throwable));
    }


    /** {@inheritDoc} */
    @Override
    public void logError (final Throwable throwable)
    {
        this.logError (throwable, false);
    }


    /** {@inheritDoc} */
    @Override
    public void logError (final Throwable throwable, final boolean logExceptionStack)
    {
        final String text = throwable.getLocalizedMessage ();
        this.logger.accept ("! " + (text == null ? throwable.getClass ().getName () : text));
    }


    /** {@inheritDoc} */
    @Override
    public void logText (final String text)
    {
        this.logger.accept (text);
    }


    /** {@inheritDoc} */
    @Override
    public void updateButtonStates (final boolean canClose)
    {
        // Not used
    }


    /** {@inheritDoc} */
    @Override
    public void finished (final boolean cancelled)
    {
        this.finished.countDown ();
    }
}
