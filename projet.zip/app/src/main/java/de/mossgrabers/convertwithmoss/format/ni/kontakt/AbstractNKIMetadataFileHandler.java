// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.format.ni.kontakt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.mossgrabers.convertwithmoss.compat.sound.AudioFileFormat;
import de.mossgrabers.convertwithmoss.compat.sound.AudioSystem;
import de.mossgrabers.convertwithmoss.compat.sound.UnsupportedAudioFileException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import de.mossgrabers.convertwithmoss.core.IInstrumentSource;
import de.mossgrabers.convertwithmoss.core.IMultisampleSource;
import de.mossgrabers.convertwithmoss.core.INotifier;
import de.mossgrabers.convertwithmoss.core.IPerformanceSource;
import de.mossgrabers.convertwithmoss.core.algorithm.MathUtils;
import de.mossgrabers.convertwithmoss.core.detector.AbstractDetector;
import de.mossgrabers.convertwithmoss.core.detector.DefaultInstrumentSource;
import de.mossgrabers.convertwithmoss.core.detector.DefaultMultisampleSource;
import de.mossgrabers.convertwithmoss.core.detector.DefaultPerformanceSource;
import de.mossgrabers.convertwithmoss.core.model.IEnvelope;
import de.mossgrabers.convertwithmoss.core.model.IEnvelopeModulator;
import de.mossgrabers.convertwithmoss.core.model.IFilter;
import de.mossgrabers.convertwithmoss.core.model.IGroup;
import de.mossgrabers.convertwithmoss.core.model.IMetadata;
import de.mossgrabers.convertwithmoss.core.model.ISampleData;
import de.mossgrabers.convertwithmoss.core.model.ISampleLoop;
import de.mossgrabers.convertwithmoss.core.model.ISampleZone;
import de.mossgrabers.convertwithmoss.core.model.enumeration.FilterType;
import de.mossgrabers.convertwithmoss.core.model.enumeration.LoopType;
import de.mossgrabers.convertwithmoss.core.model.enumeration.TriggerType;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultEnvelopeModulator;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultFilter;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultGroup;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultSampleLoop;
import de.mossgrabers.convertwithmoss.core.model.implementation.DefaultSampleZone;
import de.mossgrabers.convertwithmoss.core.settings.IMetadataConfig;
import de.mossgrabers.convertwithmoss.exception.ValueNotAvailableException;
import de.mossgrabers.convertwithmoss.file.AudioFileUtils;
import de.mossgrabers.convertwithmoss.file.aiff.AiffFileSampleData;
import de.mossgrabers.convertwithmoss.file.ncw.NcwFileSampleData;
import de.mossgrabers.convertwithmoss.format.TagDetector;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.DecodedPath;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.KontaktIcon;
import de.mossgrabers.convertwithmoss.format.ni.kontakt.type.kontakt2.K2Tag;
import de.mossgrabers.convertwithmoss.format.wav.WavFileSampleData;
import de.mossgrabers.tools.FileUtils;
import de.mossgrabers.tools.XMLUtils;
import de.mossgrabers.tools.ui.Functions;


/**
 * Base class for parsing the NKI XML structure (Kontakt 1 + 2).
 *
 * @author Jürgen Moßgraber
 * @author Philip Stolz
 */
public abstract class AbstractNKIMetadataFileHandler
{
    protected static final String                TEMPLATE_FOLDER     = "de/mossgrabers/convertwithmoss/templates/nki/";
    protected static final String                XML_HEADER          = "<?xml version=\"1.0\"?>\n";

    private static final String                  NULL_ENTRY          = "(null)";
    private static final Pattern                 FILTER_TYPE_PATTERN = Pattern.compile ("^(lp|hp|bp)(\\d+)pole$");
    private static final Pattern                 UTF_PATTERN         = Pattern.compile ("%([0-9a-fA-F]{4})");

    private static final Map<FilterType, String> FILTER_PREFIXES     = new EnumMap<> (FilterType.class);
    static
    {
        FILTER_PREFIXES.put (FilterType.LOW_PASS, "lp");
        FILTER_PREFIXES.put (FilterType.HIGH_PASS, "hp");
        FILTER_PREFIXES.put (FilterType.BAND_PASS, "bp");
    }

    protected final AbstractTagsAndAttributes tags;
    protected final INotifier                 notifier;
    private final Map<String, String>         absolutePathLookupSuccess = new HashMap<> ();


    /**
     * Constructor.
     *
     * @param tags the format specific tags
     * @param notifier Where to report errors
     */
    protected AbstractNKIMetadataFileHandler (final AbstractTagsAndAttributes tags, final INotifier notifier)
    {
        this.tags = tags;
        this.notifier = notifier;
    }


    /**
     * Parses the XML description file for a multi and its instruments.
     *
     * @param sourceFolder The top source folder for the detection
     * @param sourceFile The source file which contains the XML document
     * @param xmlCode The XML content to parse
     * @param metadataConfig Default metadata
     * @param monolithSamples The samples that are contained in the NKI monolith otherwise null
     * @return The parsed multi-sample source
     * @throws IOException An error occurred parsing the XML document
     */
    public Optional<IPerformanceSource> parseMulti (final File sourceFolder, final File sourceFile, final String xmlCode, final IMetadataConfig metadataConfig, final Map<String, ISampleData> monolithSamples) throws IOException
    {
        final Element top = this.getTopLevelElement (xmlCode);
        final IPerformanceSource performanceSource = new DefaultPerformanceSource ();
        performanceSource.setName (FileUtils.getNameWithoutType (sourceFile));

        final Map<String, String> topParameters = this.readParameters (top);
        final List<IInstrumentSource> instrumentSources = this.parseInstrumentSources (sourceFolder, sourceFile, top, metadataConfig, monolithSamples);
        final List<IInstrumentSource> instruments = performanceSource.getInstruments ();
        for (int i = 0; i < instrumentSources.size (); i++)
        {
            final IInstrumentSource instrumentSource = instrumentSources.get (i);

            // Only K2
            final String midiChannelStr = topParameters.get (String.format ("midiChannel_slot0%02d", Integer.valueOf (i)));
            if (midiChannelStr != null)
                instrumentSource.setMidiChannel ((Integer.parseInt (midiChannelStr) - 1) % 16);

            instruments.add (instrumentSource);
        }
        return Optional.of (performanceSource);
    }


    /**
     * Parses the XML description file for instruments.
     *
     * @param sourceFolder The top source folder for the detection
     * @param sourceFile The source file which contains the XML document
     * @param xmlCode The XML content to parse
     * @param metadataConfig Default metadata
     * @param monolithSamples The samples that are contained in the NKI monolith otherwise null
     * @return The parsed multi-sample source
     * @throws IOException An error occurred parsing the XML document
     */
    public List<IMultisampleSource> parseInstruments (final File sourceFolder, final File sourceFile, final String xmlCode, final IMetadataConfig metadataConfig, final Map<String, ISampleData> monolithSamples) throws IOException
    {
        final Element top = this.getTopLevelElement (xmlCode);
        final List<IInstrumentSource> instrumentSources = this.parseInstrumentSources (sourceFolder, sourceFile, top, metadataConfig, monolithSamples);
        final List<IMultisampleSource> multisampleSource = new ArrayList<> (instrumentSources.size ());
        for (final IInstrumentSource instrumentSource: instrumentSources)
            multisampleSource.add (instrumentSource.getMultisampleSource ());
        return multisampleSource;
    }


    private List<IInstrumentSource> parseInstrumentSources (final File sourceFolder, final File sourceFile, final Element top, final IMetadataConfig metadataConfig, final Map<String, ISampleData> monolithSamples) throws IOException
    {
        final List<Element> programElements = this.findProgramElements (top);
        if (programElements.isEmpty ())
            return Collections.emptyList ();

        final String n = metadataConfig.isPreferFolderName () ? sourceFolder.getName () : FileUtils.getNameWithoutType (sourceFile);
        final String [] parts = AudioFileUtils.createPathParts (sourceFile.getParentFile (), sourceFolder, n);

        final List<IInstrumentSource> instrumentSources = new ArrayList<> ();
        for (final Element programElement: programElements)
        {
            final IMultisampleSource multisampleSource = new DefaultMultisampleSource (sourceFile, parts, null);
            final IInstrumentSource instrumentSource = new DefaultInstrumentSource (multisampleSource, 0);
            if (this.parseProgram (programElement, instrumentSource, monolithSamples))
            {
                updateMetadata (metadataConfig, parts, multisampleSource.getMetadata ());
                instrumentSources.add (instrumentSource);
            }
        }
        return instrumentSources;
    }


    private Element getTopLevelElement (final String content) throws IOException
    {
        try
        {
            final Document document = XMLUtils.parseDocument (new InputSource (new StringReader (content)));
            final Element top = document.getDocumentElement ();
            if (!this.isValidTopLevelElement (top))
                throw new IOException (Functions.getMessage ("IDS_NKI_NOT_A_VALID_TOP_LEVEL_ELEMENT", top.getTagName ()));
            return top;
        }
        catch (final SAXException ex)
        {
            throw new IOException (ex);
        }
    }


    /**
     * Tries to fill empty metadata fields by using some guessing on the filename.
     *
     * @param metadataConfig The configuration
     * @param parts The filename and path parts
     * @param metadata Where to set the found metadata
     */
    public static void updateMetadata (final IMetadataConfig metadataConfig, final String [] parts, final IMetadata metadata)
    {
        final String creator = metadata.getCreator ();
        if (creator == null || creator.isBlank ())
            metadata.setCreator (TagDetector.detect (parts, metadataConfig.getCreatorTags (), metadataConfig.getCreatorName ()));

        final List<String> name = Collections.singletonList (parts[0]);
        final List<String> folderNames = Arrays.asList (AudioFileUtils.getFolderNames (parts));

        final String category = metadata.getCategory ();
        if (category == null || category.isBlank () || "New".equals (category))
            metadata.setCategory (TagDetector.detectCategory (name, folderNames, false));

        final String [] keywords = metadata.getKeywords ();
        if (keywords == null || keywords.length == 0)
            metadata.setKeywords (TagDetector.detectKeywords (name, folderNames));
    }


    /**
     * Creates a metadata description file for a bank (multi) of up to 64 programs.
     *
     * @param bankName The name of the bank
     * @param safeSampleFolderNames The folders where the samples are placed. Must be of the same
     *            size as multisampleSources!
     * @param instrumentSources The instrument sources
     * @return The XML document as a text
     * @throws IOException Could not create the text due to missing templates
     */
    public String createBank (final String bankName, final List<String> safeSampleFolderNames, final List<IInstrumentSource> instrumentSources) throws IOException
    {
        int numInstruments = instrumentSources.size ();
        if (numInstruments > 64)
        {
            this.notifier.logError ("IDS_ERR_LIMITED_INSTRUMENTS", Integer.toString (64), Integer.toString (numInstruments));
            numInstruments = 64;
        }

        final String templatePrefix = this.getTemplatePrefix ();
        final StringBuilder sb = new StringBuilder (XML_HEADER);
        final String header = Functions.textFileFor (TEMPLATE_FOLDER + templatePrefix + "_01_Bank_Start.xml");
        sb.append (header.replace ("%BANK_NAME%", bankName));
        for (int i = 0; i < numInstruments; i++)
            sb.append (this.createRawProgram (safeSampleFolderNames.get (i), instrumentSources.get (i), i));
        sb.append (Functions.textFileFor (TEMPLATE_FOLDER + templatePrefix + "_06_Bank_End.xml"));
        return sb.toString ();
    }


    /**
     * Creates a metadata description file for a single program.
     *
     * @param safeSampleFolderName The folder where the samples are placed
     * @param multisampleSource The multi-sample source
     * @param programIndex The index of the program to use (starts with 0)
     * @return The XML document as a text
     * @throws IOException Could not create the text due to missing templates
     */
    public String createProgram (final String safeSampleFolderName, final IMultisampleSource multisampleSource, final int programIndex) throws IOException
    {
        return XML_HEADER + this.createRawProgram (safeSampleFolderName, new DefaultInstrumentSource (multisampleSource, -1), programIndex);
    }


    private String createRawProgram (final String safeSampleFolderName, final IInstrumentSource instrumentSource, final int programIndex) throws IOException
    {
        final IMultisampleSource multisampleSource = instrumentSource.getMultisampleSource ();

        final String templatePrefix = this.getTemplatePrefix ();

        String text = Functions.textFileFor (TEMPLATE_FOLDER + templatePrefix + "_01_Program_Start.xml");
        text = text.replace ("%PROGRAM_INDEX%", Integer.toString (programIndex));
        text = text.replace ("%PROGRAM_NAME%", multisampleSource.getName ());
        int midiChannel = instrumentSource.getMidiChannel ();
        if (midiChannel == IInstrumentSource.MIDI_CHANNEL_OFF)
            midiChannel = 16; // B1 since there is no off-state
        text = text.replace ("%PROGRAM_MIDI_CHANNEL%", Integer.toString (midiChannel == IInstrumentSource.MIDI_CHANNEL_OMNI ? 0 : midiChannel + 1));

        text = text.replace ("%MASTER_VOLUME%", formatDouble (Math.pow (10, instrumentSource.getGain () / 20.0d)));
        text = text.replace ("%MASTER_PANNING%", String.format (Locale.US, "%.02f", Double.valueOf ((instrumentSource.getPanning () + 1.0) / 2.0)));
        text = text.replace ("%MASTER_TRANSPOSE%", Integer.toString (instrumentSource.getTranspose ()));
        text = text.replace ("%MASTER_TUNE%", formatDouble (Math.pow (2.0, instrumentSource.getTuning () / 12.0)));
        text = text.replace ("%MASTER_LOW_KEY%", Integer.toString (instrumentSource.getClipKeyLow ()));
        text = text.replace ("%MASTER_HIGH_KEY%", Integer.toString (instrumentSource.getClipKeyHigh ()));

        // Add all groups
        final String result = this.addGroups (templatePrefix, safeSampleFolderName, multisampleSource.getNonEmptyGroups (false));
        return text + result + Functions.textFileFor (TEMPLATE_FOLDER + templatePrefix + "_06_Program_End.xml");
    }


    protected abstract String getTemplatePrefix ();


    protected String addGroups (final String templatePrefix, final String safeSampleFolderName, final List<IGroup> groups) throws IOException
    {
        final String groupTemplate = Functions.textFileFor (TEMPLATE_FOLDER + templatePrefix + "_02_Group.xml");
        final String zoneTemplate = Functions.textFileFor (TEMPLATE_FOLDER + templatePrefix + "_04_Zone.xml");
        final String loopTemplate = Functions.textFileFor (TEMPLATE_FOLDER + templatePrefix + "_05_Loop.xml");

        final StringBuilder groupsText = new StringBuilder ();
        final StringBuilder zonesText = new StringBuilder ();

        // Samples are numbered across all groups!
        int sampleCount = 0;
        boolean isReverse = false;

        for (int groupCount = 0; groupCount < groups.size (); groupCount++)
        {
            final IGroup group = groups.get (groupCount);

            // Set the group index and name
            String name = group.getName ();
            if (name == null || name.isBlank ())
                name = "Group " + (groupCount + 1);
            String groupContent = groupTemplate.replace ("%GROUP_INDEX%", Integer.toString (groupCount)).replace ("%GROUP_NAME%", name);

            final List<ISampleZone> zones = group.getSampleZones ();
            for (final ISampleZone zone: zones)
            {
                String zoneContent = this.addZoneData (zone, safeSampleFolderName, zoneTemplate, sampleCount, groupCount);

                final StringBuilder loopsContent = new StringBuilder ();
                final List<ISampleLoop> loops = zone.getLoops ();
                for (int loopIndex = 0; loopIndex < loops.size (); loopIndex++)
                {
                    final ISampleLoop loop = loops.get (loopIndex);
                    final String loopContent = this.addLoop (loop, loopTemplate, loopIndex);
                    if (loopIndex > 0)
                        loopsContent.append ("\r\n");
                    loopsContent.append (loopContent);

                    isReverse = loop.getType () == LoopType.BACKWARDS;
                }
                // A one-shot which has no loop is described by a loop entry with the one-shot mode
                if (loops.isEmpty () && zone.isOneShot ())
                    loopsContent.append (this.addOneShotLoop (loopTemplate));
                zoneContent = zoneContent.replace ("%ZONE_LOOPS%", loopsContent.toString ());
                zonesText.append (zoneContent);

                sampleCount++;
            }

            // These parameters can only be set on the group. This implementation uses the first
            // found
            final ISampleZone firstZone = zones.isEmpty () ? null : zones.get (0);
            final double pitchBendUp = firstZone == null ? 0 : firstZone.getBendUp ();
            final double ampVelocityMod = firstZone == null ? 1 : firstZone.getAmplitudeVelocityModulator ().getDepth ();
            final boolean keyTracking = firstZone == null || firstZone.getKeyTracking () > 0;
            final boolean isReleaseTrigger = firstZone != null && firstZone.getTrigger () == TriggerType.RELEASE;
            // If the amplitude envelope ignores note-off events the sample is always played back to
            // its end, which means it is a one-shot. Only supported by the Kontakt 2 template.
            final boolean isOneShot = firstZone != null && firstZone.isOneShot ();
            groupContent = addModulators (firstZone, groupContent);
            groupContent = groupContent.replace ("%AMP_VELOCITY_MOD%", formatDouble (ampVelocityMod));
            groupContent = groupContent.replace ("%PITCH_BEND%", formatDouble (pitchBendUp / 1200));
            groupContent = groupContent.replace ("%GROUP_ONE_SHOT%", isOneShot ? "yes" : "no");
            groupContent = groupContent.replace ("%GROUP_KEY_TRACKING%", keyTracking ? "yes" : "no");
            groupContent = groupContent.replace ("%GROUP_RELEASE_TRIGGER%", isReleaseTrigger ? "yes" : "no");
            groupContent = groupContent.replace ("%GROUP_REVERSE%", isReverse ? "yes" : "no");
            // The voice group can only be set on the group, therefore all of its zones need to
            // agree on the exclusive group. The model uses 0 for 'no group' but Kontakt uses a zero
            // based index with -1 for 'no group', therefore the index is shifted by one
            final int exclusiveGroup = getUniformExclusiveGroup (zones);
            groupContent = groupContent.replace ("%GROUP_VOICE_GROUP%", Integer.toString (exclusiveGroup == 0 ? -1 : exclusiveGroup - 1));
            groupsText.append (groupContent);
        }

        return groupsText.toString () + Functions.textFileFor (TEMPLATE_FOLDER + templatePrefix + "_03_Groups_Zones.xml") + zonesText.toString ();
    }


    /**
     * Get the exclusive group which is shared by all given zones.
     *
     * @param zones The zones to check
     * @return The exclusive group or 0 if there are no zones or they do not all use the same one
     */
    private static int getUniformExclusiveGroup (final List<ISampleZone> zones)
    {
        if (zones.isEmpty ())
            return 0;
        final int exclusiveGroup = zones.get (0).getExclusiveGroup ();
        for (final ISampleZone zone: zones)
            if (zone.getExclusiveGroup () != exclusiveGroup)
                return 0;
        return exclusiveGroup;
    }


    private String addZoneData (final ISampleZone zone, final String safeSampleFolderName, final String zoneTemplate, final int sampleCount, final int groupCount)
    {
        String zoneContent = zoneTemplate.replace ("%GROUP_INDEX%", Integer.toString (groupCount)).replace ("%ZONE_INDEX%", Integer.toString (sampleCount));
        final String zoneName = zone.getName ();
        final int keyLow = limitToDefault (zone.getKeyLow (), 0);

        zoneContent = zoneContent.replace ("%ZONE_SAMPLE_START%", Integer.toString (zone.getStart ()));
        zoneContent = zoneContent.replace ("%ZONE_SAMPLE_END%", Integer.toString (zone.getStop ()));
        zoneContent = zoneContent.replace ("%ZONE_VEL_LOW%", Integer.toString (limitToDefault (zone.getVelocityLow (), 1)));
        zoneContent = zoneContent.replace ("%ZONE_VEL_HIGH%", Integer.toString (limitToDefault (zone.getVelocityHigh (), 127)));
        zoneContent = zoneContent.replace ("%ZONE_KEY_LOW%", Integer.toString (keyLow));
        zoneContent = zoneContent.replace ("%ZONE_KEY_HIGH%", Integer.toString (limitToDefault (zone.getKeyHigh (), 127)));
        zoneContent = zoneContent.replace ("%ZONE_VEL_CROSS_LOW%", Integer.toString (limitToDefault (zone.getVelocityCrossfadeLow (), 0)));
        zoneContent = zoneContent.replace ("%ZONE_VEL_CROSS_HIGH%", Integer.toString (limitToDefault (zone.getVelocityCrossfadeHigh (), 0)));
        zoneContent = zoneContent.replace ("%ZONE_KEY_CROSS_LOW%", Integer.toString (limitToDefault (zone.getNoteCrossfadeLow (), 0)));
        zoneContent = zoneContent.replace ("%ZONE_KEY_CROSS_HIGH%", Integer.toString (limitToDefault (zone.getNoteCrossfadeHigh (), 0)));
        zoneContent = zoneContent.replace ("%ZONE_KEY_ROOT%", Integer.toString (limitToDefault (zone.getKeyRoot (), keyLow)));
        zoneContent = zoneContent.replace ("%ZONE_VOLUME%", formatDouble (Math.pow (10, zone.getGain () / 20.0d)));
        zoneContent = zoneContent.replace ("%ZONE_TUNE%", formatDouble (Math.pow (2.0, zone.getTuning () / 12.0)));
        zoneContent = zoneContent.replace ("%ZONE_PAN%", formatDouble (this.denormalizePanning (zone.getPanning ())));

        // Note: we need to use backward slashes otherwise Kontakt can read but not save the file
        // again!
        final String formattedFilename = new StringBuilder (safeSampleFolderName).append ('\\').append (zoneName).append (".wav").toString ().replace ('/', '\\');
        return zoneContent.replace ("%ZONE_SAMPLE_NAME%", formattedFilename);
    }


    private String addLoop (final ISampleLoop loop, final String loopTemplate, final int loopIndex)
    {
        String loopContent = loopTemplate.replace ("%LOOP_INDEX%", Integer.toString (loopIndex));

        loopContent = loopContent.replace ("%LOOP_START%", Integer.toString (loop.getStart ()));
        // Kontakt counts the frames of the loop while the model stores the inclusive end
        loopContent = loopContent.replace ("%LOOP_LENGTH%", Integer.toString (loop.getLength () + 1));
        loopContent = loopContent.replace ("%LOOP_MODE%", loop.isLoopUntilRelease () ? this.tags.untilReleaseValue () : this.tags.untilEndValue ());
        loopContent = loopContent.replace ("%LOOP_ALTERNATING%", loop.getType () == LoopType.ALTERNATING ? "yes" : "no");
        loopContent = loopContent.replace ("%LOOP_TUNING%", Float.toString ((float) Math.pow (2.0, loop.getTuning () / 12.0)));
        // The cross-fade of the format is a length in samples, not the fraction of the loop
        return loopContent.replace ("%LOOP_XFADE%", Integer.toString (loop.getCrossfadeInSamples ()));
    }


    /**
     * Creates a loop entry which marks the zone as a one-shot, which means that note-off events are
     * ignored and the sample is always played back to its end. The loop positions are not used in
     * that mode.
     *
     * @param loopTemplate The template of a loop
     * @return The filled loop template
     */
    private String addOneShotLoop (final String loopTemplate)
    {
        String loopContent = loopTemplate.replace ("%LOOP_INDEX%", "0");

        loopContent = loopContent.replace ("%LOOP_START%", "0");
        loopContent = loopContent.replace ("%LOOP_LENGTH%", "0");
        loopContent = loopContent.replace ("%LOOP_MODE%", this.tags.oneshotValue ());
        loopContent = loopContent.replace ("%LOOP_ALTERNATING%", "no");
        loopContent = loopContent.replace ("%LOOP_TUNING%", Float.toString (1.0f));
        return loopContent.replace ("%LOOP_XFADE%", "0");
    }


    private static String addModulators (final ISampleZone sampleMetadata, final String groupContentTemplate)
    {
        final IEnvelopeModulator amplitudeModulator = sampleMetadata == null ? new DefaultEnvelopeModulator (1) : sampleMetadata.getAmplitudeEnvelopeModulator ();
        final IEnvelope amplitudeEnvelope = amplitudeModulator.getSource ();
        String groupContent = groupContentTemplate.replace ("%ENVELOPE_INTENSITY%", formatDouble (amplitudeModulator.getDepth ()));
        groupContent = groupContent.replace ("%ENVELOPE_ATTACK_CURVE%", formatDouble (-amplitudeEnvelope.getAttackSlope ()));
        groupContent = groupContent.replace ("%ENVELOPE_ATTACK%", formatDouble (limitToDefault (amplitudeEnvelope.getAttackTime (), 0) * 1000.0d));
        groupContent = groupContent.replace ("%ENVELOPE_DECAY%", formatDouble (limitToDefault (amplitudeEnvelope.getDecayTime (), 0) * 1000.0d));
        groupContent = groupContent.replace ("%ENVELOPE_HOLD%", formatDouble (limitToDefault (amplitudeEnvelope.getHoldTime (), 0) * 1000.0d));
        groupContent = groupContent.replace ("%ENVELOPE_RELEASE%", formatDouble (limitToDefault (amplitudeEnvelope.getReleaseTime (), 1) * 1000.0d));
        groupContent = groupContent.replace ("%ENVELOPE_SUSTAIN%", formatDouble (limitToDefault (amplitudeEnvelope.getSustainLevel (), 1)));

        final IEnvelopeModulator pitchModulator = sampleMetadata == null ? new DefaultEnvelopeModulator (0) : sampleMetadata.getPitchEnvelopeModulator ();
        final IEnvelope pitchEnvelope = pitchModulator.getSource ();
        groupContent = groupContent.replace ("%PITCH_ENVELOPE_INTENSITY%", formatDouble (pitchModulator.getDepth ()));
        groupContent = groupContent.replace ("%PITCH_ENVELOPE_ATTACK_CURVE%", formatDouble (-pitchEnvelope.getAttackSlope ()));

        // If the start level is not 0 (which is normally the case for a pitch envelope, we assume
        // it to be the attack level and then only use the decay value, since this is the most
        // common application for pitch envelopes.
        if (pitchEnvelope.getStartLevel () != 0)
        {
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_ATTACK%", formatDouble (0));
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_DECAY%", formatDouble (limitToDefault (pitchEnvelope.getAttackTime (), 0) * 1000.0d));
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_HOLD%", formatDouble (0));
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_RELEASE%", formatDouble (0));
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_SUSTAIN%", formatDouble (0));
        }
        else
        {
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_ATTACK%", formatDouble (limitToDefault (pitchEnvelope.getAttackTime (), 0) * 1000.0d));
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_DECAY%", formatDouble (limitToDefault (pitchEnvelope.getDecayTime (), 0) * 1000.0d));
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_HOLD%", formatDouble (limitToDefault (pitchEnvelope.getHoldTime (), 0) * 1000.0d));
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_RELEASE%", formatDouble (limitToDefault (pitchEnvelope.getReleaseTime (), 0) * 1000.0d));
            groupContent = groupContent.replace ("%PITCH_ENVELOPE_SUSTAIN%", formatDouble (limitToDefault (pitchEnvelope.getSustainLevel (), 0)));
        }

        final Optional<IFilter> filterOpt = sampleMetadata == null ? Optional.empty () : sampleMetadata.getFilter ();
        final IFilter filter = filterOpt.isPresent () ? filterOpt.get () : new DefaultFilter (FilterType.LOW_PASS, 2, IFilter.MAX_FREQUENCY, 0);
        groupContent = groupContent.replace ("%FILTER_TYPE%", createFilterType (filter));

        final double legacyCutoff = MathUtils.normalizeFrequency (Math.clamp (filter.getCutoff (), 43.6, 21800), 21800.0);
        groupContent = groupContent.replace ("%FILTER_CUTOFF%", formatDouble (legacyCutoff));
        groupContent = groupContent.replace ("%FILTER_RESONANCE%", formatDouble (filter.getResonance ()));

        final IEnvelopeModulator filterCutoffModulator = filter.getCutoffEnvelopeModulator ();
        final IEnvelope filterCutoffEnvelope = filterCutoffModulator.getSource ();
        groupContent = groupContent.replace ("%FILTER_CUTOFF_ENVELOPE_INTENSITY%", formatDouble (filterCutoffModulator.getDepth ()));
        groupContent = groupContent.replace ("%FILTER_CUTOFF_ENVELOPE_ATTACK_CURVE%", formatDouble (-filterCutoffEnvelope.getAttackSlope ()));
        groupContent = groupContent.replace ("%FILTER_CUTOFF_ENVELOPE_ATTACK%", formatDouble (limitToDefault (filterCutoffEnvelope.getAttackTime (), 0) * 1000.0d));
        groupContent = groupContent.replace ("%FILTER_CUTOFF_ENVELOPE_DECAY%", formatDouble (limitToDefault (filterCutoffEnvelope.getDecayTime (), 0) * 1000.0d));
        groupContent = groupContent.replace ("%FILTER_CUTOFF_ENVELOPE_HOLD%", formatDouble (limitToDefault (filterCutoffEnvelope.getHoldTime (), 0) * 1000.0d));
        groupContent = groupContent.replace ("%FILTER_CUTOFF_ENVELOPE_RELEASE%", formatDouble (limitToDefault (filterCutoffEnvelope.getReleaseTime (), 1) * 1000.0d));
        groupContent = groupContent.replace ("%FILTER_CUTOFF_ENVELOPE_SUSTAIN%", formatDouble (limitToDefault (filterCutoffEnvelope.getSustainLevel (), 1)));

        final double cutoffVelocityDepth = filter.getCutoffVelocityModulator ().getDepth ();
        groupContent = groupContent.replace ("%FILTER_CUTOFF_VELOCITY_MOD%", formatDouble (limitToDefault (cutoffVelocityDepth, 0)));

        return groupContent;
    }


    private static String createFilterType (final IFilter filter)
    {
        return FILTER_PREFIXES.getOrDefault (filter.getType (), "lp") + filter.getPoles () + "pole";
    }


    private static double limitToDefault (final double value, final double defaultValue)
    {
        return value < 0 ? defaultValue : value;
    }


    private static int limitToDefault (final int value, final int defaultValue)
    {
        return value < 0 ? defaultValue : value;
    }


    /**
     * Checks whether a given element is a valid top-level element.
     *
     * @param top The top-level element.
     * @return True if top is a valid top-level element, false else
     */
    protected abstract boolean isValidTopLevelElement (final Element top);


    /**
     * Returns the program elements in the metadata file.
     *
     * @param top The top element of the document
     * @return An array of program elements, an empty array if nothing was found
     */
    protected abstract List<Element> findProgramElements (final Element top);


    /**
     * Parses a program element and retrieves a IMultisampleSource object representing the program.
     *
     * @param programElement The program element to be parsed
     * @param instrumentSource Where to store the parsed data
     * @param monolithSamples The samples that are contained in the NKI monolith otherwise null
     * @return True if successful
     * @throws IOException Could not create path for samples
     */
    private boolean parseProgram (final Element programElement, final IInstrumentSource instrumentSource, final Map<String, ISampleData> monolithSamples) throws IOException
    {
        final IMultisampleSource multisampleSource = instrumentSource.getMultisampleSource ();

        final String programName = this.tags.programName ();
        if (!programElement.hasAttribute (programName))
            return false;

        final Map<String, String> programParameters = this.readParameters (programElement);
        readMetadata (programParameters, multisampleSource.getMetadata ());

        // Present only in K1
        this.readInstrumentParameters (instrumentSource, programParameters);

        final List<Element> groupElements = this.getGroupElements (programElement);
        final List<Element> zoneElements = this.getZoneElements (programElement);

        final String sourcePath = multisampleSource.getSourceFile ().getParentFile ().getCanonicalPath ();
        final List<IGroup> groups = this.getGroups (programParameters, groupElements, zoneElements, sourcePath, monolithSamples);
        if (groups.isEmpty ())
        {
            this.notifier.logError ("IDS_NKI_NO_VEL_GROUP_DETECTED");
            return false;
        }

        multisampleSource.setGroups (groups);

        String name = programElement.getAttribute (programName);
        // Kontakt seems to behave like this...
        if ("Instrument 1".equals (name) && groups.size () == 1)
            name = groups.get (0).getName ();
        multisampleSource.setName (name);

        return true;
    }


    /**
     * Read additional parameter like the MIDI channel which are specific to the instrument.
     *
     * @param instrumentSource The instrument source
     * @param programParameters The program parameter
     */
    protected void readInstrumentParameters (final IInstrumentSource instrumentSource, final Map<String, String> programParameters)
    {
        final String lowKey = programParameters.get ("lowKey");
        if (lowKey != null)
            instrumentSource.setClipKeyLow (Integer.parseInt (lowKey));
        final String highKey = programParameters.get ("highKey");
        if (highKey != null)
            instrumentSource.setClipKeyHigh (Integer.parseInt (highKey));
    }


    private static void readMetadata (final Map<String, String> programParameters, final IMetadata metadata)
    {
        final String iconIdx = programParameters.get ("catIconIdx");
        if (iconIdx != null && !iconIdx.isBlank ())
            try
            {
                final int index = Integer.parseInt (iconIdx);
                // 0 is Organ but might simply not be set there use auto-detection instead, 28 is
                // New where we use auto-detection as well
                if (index > 0 && index < 28)
                {
                    final String iconName = KontaktIcon.getName (index);
                    if (iconName != null)
                        metadata.setCategory (iconName);
                }
            }
            catch (final NumberFormatException ignoredException)
            {
                // Ignore
            }
        final String author = programParameters.get ("instrumentAuthor");
        if (author != null)
            metadata.setCreator (author);
        final String description = programParameters.get ("instrumentCredits");
        if (description != null && !NULL_ENTRY.equals (description))
            metadata.setDescription (description.replace (NULL_ENTRY, ""));
    }


    /**
     * Reads the parameters of a program under an XML element.
     *
     * @param element The XML element
     * @return A map with the parameters and their values, an empty map if no parameters are found
     */
    private Map<String, String> readParameters (final Element element)
    {
        final Element parametersElement = XMLUtils.getChildElementByName (element, this.tags.parameters ());
        return this.readValueMap (parametersElement);
    }


    /**
     * Reads a value map from a given XML element.
     *
     * @param element The XML element
     * @return The value map. If nothing can be read, an empty map is returned.
     */
    protected Map<String, String> readValueMap (final Element element)
    {
        if (element == null)
            return Collections.emptyMap ();

        final HashMap<String, String> result = new HashMap<> ();
        for (final Element valueElement: XMLUtils.getChildElementsByName (element, this.tags.value ()))
        {
            final String valueName = valueElement.getAttribute (this.tags.valueNameAttribute ());
            final String valueValue = valueElement.getAttribute (this.tags.valueValueAttribute ());
            if (valueName != null && valueValue != null)
                result.put (valueName, valueValue);
        }
        return result;
    }


    /**
     * Retrieves a program's group elements as an array.
     *
     * @param programElement The XML program element
     * @return The array of group elements
     */
    private List<Element> getGroupElements (final Element programElement)
    {
        final Element groupsElement = XMLUtils.getChildElementByName (programElement, this.tags.groups ());
        return groupsElement != null ? XMLUtils.getChildElementsByName (groupsElement, this.tags.group ()) : null;
    }


    /**
     * Retrieves a program's zone elements as an array.
     *
     * @param programElement The XML program element
     * @return The array of zone elements
     */
    private List<Element> getZoneElements (final Element programElement)
    {
        final Element zoneElement = XMLUtils.getChildElementByName (programElement, this.tags.zones ());
        return zoneElement != null ? XMLUtils.getChildElementsByName (zoneElement, this.tags.zone ()) : null;
    }


    /**
     * Creates groups from a program's parameters and its group and zone elements.
     *
     * @param programParameters The program parameters
     * @param groupElements The group elements
     * @param zoneElements The zone elements
     * @param sourcePath The canonical path which contains the NKI file
     * @param monolithSamples The samples that are contained in the NKI monolith otherwise null
     * @return the groups created (empty list is returned if nothing was created)
     * @throws IOException Could not get sample file(s)
     */
    private List<IGroup> getGroups (final Map<String, String> programParameters, final List<Element> groupElements, final List<Element> zoneElements, final String sourcePath, final Map<String, ISampleData> monolithSamples) throws IOException
    {
        if (groupElements == null || zoneElements == null)
            return Collections.emptyList ();

        final LinkedList<IGroup> groups = new LinkedList<> ();
        for (final Element groupElement: groupElements)
        {
            final Optional<IGroup> group = this.getGroup (programParameters, groupElement, zoneElements, sourcePath, monolithSamples);
            if (group.isPresent ())
                groups.add (group.get ());
        }
        return groups;
    }


    /**
     * Creates one group from a program's parameters, a given group element and the program's zone
     * elements.
     *
     * @param programParameters The program parameters
     * @param groupElement The group element from which the group is created
     * @param zoneElements The program's zone elements
     * @param sourcePath The canonical path which contains the NKI file
     * @param monolithSamples The samples that are contained in the NKI monolith otherwise null
     * @return The group created from the zone element (null, if there is no group element)
     * @throws IOException Could not get sample file(s)
     */
    private Optional<IGroup> getGroup (final Map<String, String> programParameters, final Element groupElement, final List<Element> zoneElements, final String sourcePath, final Map<String, ISampleData> monolithSamples) throws IOException
    {
        if (groupElement == null)
            return Optional.empty ();

        final IGroup group = new DefaultGroup ();
        group.setName (this.getGroupName (groupElement));
        final Map<String, String> groupParameters = this.readParameters (groupElement);
        this.readGroupValues (group, groupParameters);
        final Optional<IFilter> filter = this.readFilter (groupElement);

        final Map<String, IEnvelopeModulator> groupInternalModulators = this.readGroupInternalModulators (groupElement);
        final List<ExternalModulation> extModulators = this.readExtModulators (groupElement);
        final int pitchBend = this.readGroupPitchBend (extModulators);
        final double ampVelocityMod = this.readGroupAmplitudeVelocityModulator (extModulators);

        group.setTrigger (this.getTriggerTypeFromGroupElement (groupParameters));
        final Element [] groupZones = this.findGroupZones (groupElement, zoneElements);
        final List<ISampleZone> zones = this.getSampleMetadataFromZones (programParameters, groupParameters, groupInternalModulators, groupElement, groupZones, pitchBend, ampVelocityMod, sourcePath, monolithSamples, filter);
        group.setSampleZones (zones);
        // The one-shot setting is stored on the group's amplitude envelope but the model keeps it
        // on the zone
        if (this.readGroupOneShot (groupElement))
            for (final ISampleZone zone: zones)
                zone.setOneShot (true);
        this.parseRoundRobin (groupElement, zones);
        return Optional.of (group);
    }


    /**
     * Reads the gain, panning and tuning of a group and stores them on the group. Note that these
     * values are (and must stay) applied to each of the sample zones of the group as well, see the
     * reading of a sample zone. A creator must therefore apply either the group or the zone value
     * but never both.
     *
     * @param group The group on which to store the values
     * @param groupParameters The parameters of the group
     */
    private void readGroupValues (final IGroup group, final Map<String, String> groupParameters)
    {
        try
        {
            // The volume is a linear factor, 1 is the neutral value
            final double groupVolume = AbstractNKIMetadataFileHandler.getDouble (groupParameters, this.tags.groupVolParam ());
            if (groupVolume != 1)
                group.setGain (20.0d * Math.log10 (groupVolume));
        }
        catch (final ValueNotAvailableException ignoredException)
        {
            // The parameter is optional, keep the neutral default
        }

        try
        {
            final double groupPan = this.normalizePanning (AbstractNKIMetadataFileHandler.getDouble (groupParameters, this.tags.groupPanParam ()));
            if (groupPan != 0)
                group.setPanning (Math.clamp (groupPan, -1.0d, 1.0d));
        }
        catch (final ValueNotAvailableException ignoredException)
        {
            // The parameter is optional, keep the neutral default
        }

        try
        {
            final double groupTune = this.tags.calculateGroupTune (AbstractNKIMetadataFileHandler.getDouble (groupParameters, this.tags.groupTuneParam ()));
            if (groupTune != 0)
                group.setTuning (groupTune);
        }
        catch (final ValueNotAvailableException ignoredException)
        {
            // The parameter is optional, keep the neutral default
        }
    }


    /**
     * Reads the note-off-less mode of the group's amplitude envelope. If it is enabled, note-off
     * events are ignored and the sample is always played back to its end (one-shot). The parameter
     * is only present from Kontakt 2 onwards.
     *
     * @param groupElement The group element
     * @return True if the group is played back as a one-shot
     */
    private boolean readGroupOneShot (final Element groupElement)
    {
        final Element modulatorsElement = XMLUtils.getChildElementByName (groupElement, this.tags.intModulatorsElement ());
        if (modulatorsElement == null)
            return false;

        for (final Element modulatorElement: XMLUtils.getChildElementsByName (modulatorsElement, this.tags.intModulatorElement ()))
        {
            final Element envElement = XMLUtils.getChildElementByName (modulatorElement, this.tags.envelopeElement ());
            if (envElement == null || this.hasNameValuePairs (modulatorElement, this.tags.bypassParam (), this.tags.yes ()))
                continue;
            final Optional<String> modulationTarget = this.getModulationTarget (modulatorElement);
            if (modulationTarget.isPresent () && this.tags.targetVolValue ().equals (modulationTarget.get ()) && this.hasNameValuePairs (envElement, this.tags.noteOffLessModeParam (), this.tags.yes ()))
                return true;
        }
        return false;
    }


    protected abstract void parseRoundRobin (final Element groupElement, final List<ISampleZone> zones);


    /**
     * Creates sample metadata from zones.
     *
     * @param programParameters The program's parameters
     * @param groupParameters The group's parameters
     * @param groupModulators The group's modulation envelopes
     * @param groupElement The group element from which the metadata is created
     * @param groupZones The zone elements belonging to the group
     * @param pitchBend The pitchbend range (half tone steps)
     * @param ampVelocityMod The amplitude modulation by velocity
     * @param sourcePath The canonical path which contains the NKI file
     * @param monolithSamples The samples that are contained in the NKI monolith otherwise null
     * @param filter The filter or null if none is applied
     * @return A list of sample metadata object. If nothing can be created, an empty list is
     *         returned.
     * @throws IOException Could not get sample file
     */
    private List<ISampleZone> getSampleMetadataFromZones (final Map<String, String> programParameters, final Map<String, String> groupParameters, final Map<String, IEnvelopeModulator> groupModulators, final Element groupElement, final Element [] groupZones, final int pitchBend, final double ampVelocityMod, final String sourcePath, final Map<String, ISampleData> monolithSamples, final Optional<IFilter> filter) throws IOException
    {
        if (groupElement == null || groupZones == null)
            return Collections.emptyList ();

        final LinkedList<ISampleZone> sampleMetadataList = new LinkedList<> ();

        for (final Element zoneElement: groupZones)
        {
            final Optional<File> sampleFileOpt = this.getZoneSampleFile (zoneElement, sourcePath, !monolithSamples.isEmpty ());
            if (sampleFileOpt.isEmpty ())
                continue;

            final File sampleFile = sampleFileOpt.get ();
            final Optional<ISampleData> sampleData = this.getSampleData (sampleFile, monolithSamples);
            if (sampleData.isPresent ())
            {
                final ISampleZone zone = new DefaultSampleZone (FileUtils.getNameWithoutType (sampleFile), sampleData.get ());
                if (filter.isPresent ())
                    zone.setFilter (filter.get ());
                this.readSampleZone (programParameters, groupParameters, groupModulators, pitchBend, ampVelocityMod, sampleMetadataList, zoneElement, zone);
            }
        }

        return sampleMetadataList;
    }


    private Optional<ISampleData> getSampleData (final File sampleFile, final Map<String, ISampleData> monolithSamples) throws IOException
    {
        if (!monolithSamples.isEmpty ())
            return Optional.of (monolithSamples.get (sampleFile.getName ()));

        if (sampleFile.getName ().toLowerCase ().endsWith (".ncw"))
            return Optional.of (new NcwFileSampleData (sampleFile));

        // Check the type of the source sample for compatibility and handle them
        // accordingly
        try
        {
            final AudioFileFormat.Type type = AudioSystem.getAudioFileFormat (sampleFile).getType ();
            if (AudioFileFormat.Type.WAVE.equals (type))
            {
                if (AudioFileUtils.checkSampleFile (sampleFile, this.notifier))
                    return Optional.of (new WavFileSampleData (sampleFile));
            }
            else if (AudioFileFormat.Type.AIFF.equals (type))
                return Optional.of (new AiffFileSampleData (sampleFile));

            this.notifier.logError ("IDS_ERR_SOURCE_FORMAT_NOT_SUPPORTED", type.toString ());
        }
        catch (final UnsupportedAudioFileException ex)
        {
            this.notifier.logError ("IDS_ERR_SOURCE_FORMAT_NOT_SUPPORTED_LONG", ex.getMessage (), sampleFile.getName ());
        }
        catch (final NoSuchFileException ignoredException)
        {
            this.notifier.logError ("IDS_ERR_SAMPLE_FILE_DOES_NOT_EXIST", sampleFile.getAbsolutePath ());
        }
        catch (final IOException ignoredException)
        {
            this.notifier.logError ("IDS_ERR_SOURCE_FORMAT_NOT_SUPPORTED", sampleFile.getName ());
        }
        return Optional.empty ();
    }


    private void readSampleZone (final Map<String, String> programParameters, final Map<String, String> groupParameters, final Map<String, IEnvelopeModulator> groupModulators, final int pitchBend, final double ampVelocityMod, final LinkedList<ISampleZone> sampleMetadataList, final Element zoneElement, final ISampleZone zone)
    {
        try
        {
            final Optional<ISampleData> sampleData = zone.getSampleData ();
            if (sampleData.isPresent ())
                sampleData.get ().addZoneData (zone, true, true);
        }
        catch (final FileNotFoundException ex)
        {
            this.notifier.logError ("IDS_NOTIFY_FILE_NOT_FOUND", ex);
        }
        catch (final IOException ex)
        {
            this.notifier.logError ("IDS_NOTIFY_ERR_BROKEN_WAV", ex);
            return;
        }

        final Map<String, String> zoneParameters = this.readParameters (zoneElement);
        try
        {
            zone.setKeyRoot (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.rootKeyParam ()));
            zone.setKeyLow (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.lowKeyParam ()));
            zone.setKeyHigh (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.highKeyParam ()));
            zone.setVelocityLow (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.lowVelocityParam ()));
            zone.setVelocityHigh (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.highVelocityParam ()));
            zone.setNoteCrossfadeLow (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.fadeLowParam ()));
            zone.setNoteCrossfadeHigh (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.fadeHighParam ()));
            zone.setVelocityCrossfadeLow (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.fadeLowVelParam ()));
            zone.setVelocityCrossfadeHigh (AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.fadeHighVelParam ()));

            final int sampleStart = AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.sampleStartParam ());
            final int sampleEnd = AbstractNKIMetadataFileHandler.getInt (zoneParameters, this.tags.sampleEndParam ());

            if (sampleEnd > sampleStart)
            {
                zone.setStart (sampleStart);
                zone.setStop (sampleEnd);
            }

            final String keyTracking = AbstractNKIMetadataFileHandler.getString (groupParameters, this.tags.keyTrackingParam ());
            final double keyTrackingValue = keyTracking.equals (this.tags.yes ()) ? 1.0d : 0.0d;
            zone.setKeyTracking (keyTrackingValue);

            final double zoneVol = AbstractNKIMetadataFileHandler.getDouble (zoneParameters, this.tags.zoneVolParam ());
            final double groupVol = AbstractNKIMetadataFileHandler.getDouble (groupParameters, this.tags.groupVolParam ());
            final double progVol = AbstractNKIMetadataFileHandler.getDouble (programParameters, this.tags.progVolParam ());
            zone.setGain (20.0d * Math.log10 (zoneVol * groupVol * progVol));

            final double zoneTune = AbstractNKIMetadataFileHandler.getDouble (zoneParameters, this.tags.zoneTuneParam ());
            final double groupTune = AbstractNKIMetadataFileHandler.getDouble (groupParameters, this.tags.groupTuneParam ());
            final double progTune = AbstractNKIMetadataFileHandler.getDouble (programParameters, this.tags.progTuneParam ());
            zone.setTuning (this.tags.calculateTune (zoneTune, groupTune, progTune));

            final double zonePan = AbstractNKIMetadataFileHandler.getDouble (zoneParameters, this.tags.zonePanParam ());
            final double groupPan = AbstractNKIMetadataFileHandler.getDouble (groupParameters, this.tags.groupPanParam ());
            final double progPan = AbstractNKIMetadataFileHandler.getDouble (programParameters, this.tags.progPanParam ());
            final double totalPan = this.normalizePanning (zonePan) + this.normalizePanning (groupPan) + this.normalizePanning (progPan);
            zone.setPanning (Math.clamp (totalPan, -1.0d, 1.0d));

            if (ampVelocityMod >= 0)
            {
                zone.getAmplitudeVelocityModulator ().setDepth (ampVelocityMod);
                // The volume of Kontakt maps its normalized value to decibels with 60*log10(x).
                // The velocity modulation therefore scales the amplitude with x^3, which is a
                // convex curve (+1)
                zone.getAmplitudeVelocityModulator ().setCurve (1);
            }
        }
        catch (final ValueNotAvailableException e)
        {
            this.notifier.logError ("IDS_NKI_ERROR_MISSING_VALUE", e);
            return;
        }

        this.setModulators (groupModulators, zone);

        if (groupParameters.containsKey (this.tags.reverseParam ()))
        {
            final String reversed = groupParameters.get (this.tags.reverseParam ());
            zone.setReversed (reversed.equals (this.tags.yes ()));
        }

        // Kontakt stores the voice group as a zero based index with -1 for 'no group' but the model
        // uses 0 for 'no group', therefore the index is shifted by one
        final String voiceGroup = groupParameters.get (this.tags.voiceGroupParam ());
        if (voiceGroup != null && !voiceGroup.isBlank ())
            try
            {
                final int voiceGroupIndex = Integer.parseInt (voiceGroup.trim ());
                zone.setExclusiveGroup (voiceGroupIndex < 0 ? 0 : voiceGroupIndex + 1);
            }
            catch (final NumberFormatException ignoredException)
            {
                // Ignore an unparsable voice group
            }

        this.readLoopInformation (zoneElement, zone);

        sampleMetadataList.add (zone);

        if (pitchBend >= 0)
        {
            zone.setBendUp (pitchBend);
            zone.setBendDown (-pitchBend);
        }
    }


    private void setModulators (final Map<String, IEnvelopeModulator> groupEnvelopes, final ISampleZone sampleMetadata)
    {
        final IEnvelopeModulator groupAmpModulator = groupEnvelopes.get (this.tags.targetVolValue ());
        if (groupAmpModulator != null)
        {
            final IEnvelope source = groupAmpModulator.getSource ();
            final IEnvelopeModulator amplitudeModulator = sampleMetadata.getAmplitudeEnvelopeModulator ();
            amplitudeModulator.setDepth (groupAmpModulator.getDepth ());

            final IEnvelope amplitudeEnvelope = amplitudeModulator.getSource ();
            amplitudeEnvelope.setAttackSlope (source.getAttackSlope ());
            amplitudeEnvelope.setAttackTime (source.getAttackTime ());
            amplitudeEnvelope.setHoldTime (source.getHoldTime ());
            amplitudeEnvelope.setDecayTime (source.getDecayTime ());
            amplitudeEnvelope.setSustainLevel (source.getSustainLevel ());
            amplitudeEnvelope.setReleaseTime (source.getReleaseTime ());
        }

        final IEnvelopeModulator groupPitchModulator = groupEnvelopes.get (this.tags.targetPitchValue ());
        if (groupPitchModulator != null)
        {
            final IEnvelope source = groupPitchModulator.getSource ();
            final IEnvelopeModulator pitchModulator = sampleMetadata.getPitchEnvelopeModulator ();
            pitchModulator.setDepth (groupPitchModulator.getDepth ());

            final IEnvelope pitchEnvelope = pitchModulator.getSource ();
            pitchEnvelope.setAttackSlope (source.getAttackSlope ());
            pitchEnvelope.setAttackTime (source.getAttackTime ());
            pitchEnvelope.setHoldTime (source.getHoldTime ());
            pitchEnvelope.setDecayTime (source.getDecayTime ());
            pitchEnvelope.setSustainLevel (source.getSustainLevel ());
            pitchEnvelope.setReleaseTime (source.getReleaseTime ());
        }

        final Optional<IFilter> filterOpt = sampleMetadata.getFilter ();
        if (filterOpt.isPresent ())
        {
            final IEnvelopeModulator groupFilterCutoffModulator = groupEnvelopes.get (this.tags.targetFilterCutoffValue ());
            if (groupFilterCutoffModulator != null)
            {
                final IFilter filter = filterOpt.get ();

                final IEnvelope source = groupFilterCutoffModulator.getSource ();
                final IEnvelopeModulator filterCutoffModulator = filter.getCutoffEnvelopeModulator ();
                filterCutoffModulator.setDepth (groupFilterCutoffModulator.getDepth ());

                final IEnvelope filterCutoffEnvelope = filterCutoffModulator.getSource ();
                filterCutoffEnvelope.setAttackSlope (source.getAttackSlope ());
                filterCutoffEnvelope.setAttackTime (source.getAttackTime ());
                filterCutoffEnvelope.setHoldTime (source.getHoldTime ());
                filterCutoffEnvelope.setDecayTime (source.getDecayTime ());
                filterCutoffEnvelope.setSustainLevel (source.getSustainLevel ());
                filterCutoffEnvelope.setReleaseTime (source.getReleaseTime ());
            }
        }
    }


    /**
     * Normalizes a panning value to a range from -1 to 1 where 0 is center and -1 is left.
     *
     * @param panningValue The panning value to normalize
     * @return The normalized panning value
     */
    protected abstract double normalizePanning (final double panningValue);


    /**
     * De-normalizes a panning value from a range from -1 to 1 where 0 is center and -1 is left.
     *
     * @param panningValue The panning value to normalize
     * @return The normalized panning value
     */
    protected double denormalizePanning (final double panningValue)
    {
        return panningValue;
    }


    /**
     * Reads the loop information from a zone element and writes it to a ISampleMetadata object.
     *
     * @param zoneElement The zone element
     * @param sampleMetadata The ISampleMetadata object
     */
    private void readLoopInformation (final Element zoneElement, final ISampleZone sampleMetadata)
    {
        final Element loopsElement = XMLUtils.getChildElementByName (zoneElement, this.tags.loopsElement ());
        if (loopsElement == null)
            return;

        final List<Element> loopElements = XMLUtils.getChildElementsByName (loopsElement, this.tags.loopElement (), false);
        final List<ISampleLoop> loops = sampleMetadata.getLoops ();
        if (!loopElements.isEmpty ())
            loops.clear ();
        for (final Element loopElement: loopElements)
        {
            final Map<String, String> loopParams = this.readValueMap (loopElement);

            int loopStart;
            int loopLength;
            String loopMode;
            int xFadeLength;
            double loopTuning;
            String alternatingLoop;
            try
            {
                loopStart = AbstractNKIMetadataFileHandler.getInt (loopParams, this.tags.loopStartParam ());
                loopLength = AbstractNKIMetadataFileHandler.getInt (loopParams, this.tags.loopLengthParam ());
                loopMode = AbstractNKIMetadataFileHandler.getString (loopParams, this.tags.loopModeParam ());
                loopTuning = AbstractNKIMetadataFileHandler.getDouble (loopParams, this.tags.loopTuningParam ());
                xFadeLength = AbstractNKIMetadataFileHandler.getInt (loopParams, this.tags.xfadeLengthParam ());
                alternatingLoop = AbstractNKIMetadataFileHandler.getString (loopParams, this.tags.alternatingLoopParam ());
            }
            catch (final ValueNotAvailableException ignoredException)
            {
                return;
            }

            // If it is a one shot then there is no loop
            if (loopMode.equals (this.tags.oneshotValue ()))
            {
                sampleMetadata.setOneShot (true);
                continue;
            }

            LoopType loopType = LoopType.FORWARDS;
            if ((loopMode.equals (this.tags.untilEndValue ()) || loopMode.equals (this.tags.untilReleaseValue ())) && alternatingLoop.equals (this.tags.yes ()))
                loopType = LoopType.ALTERNATING;

            final ISampleLoop loop = new DefaultSampleLoop ();
            loop.setStart (loopStart);
            // The length is the number of frames of the loop, the end of the model is inclusive
            loop.setEnd (loopStart + loopLength - 1);
            loop.setTuning (12.0 * (Math.log (loopTuning) / Math.log (2.0)));
            loop.setCrossfadeInSamples (xFadeLength);
            loop.setType (loopType);
            // 'until_release' loops while the key is held and then plays the remainder of the
            // sample on release (sustain loop); 'until_end' loops continuously
            loop.setLoopUntilRelease (loopMode.equals (this.tags.untilReleaseValue ()));
            sampleMetadata.addLoop (loop);
        }
    }


    /**
     * Retrieves a sample file from a zone element.
     *
     * @param zoneElement The zone element
     * @param sourcePath The canonical path which contains the NKI file
     * @param isMonolith True if samples are contained in the NKI as well
     * @return The sample file. Null is returned if file cannot be retrieved successfully.
     * @throws IOException Could not get the file
     */
    private Optional<File> getZoneSampleFile (final Element zoneElement, final String sourcePath, final boolean isMonolith) throws IOException
    {
        final Element sampleElement = XMLUtils.getChildElementByName (zoneElement, this.tags.zoneSample ());
        if (sampleElement == null)
            return Optional.empty ();

        final Map<String, String> sampleParameters = this.readValueMap (sampleElement);
        String encodedSampleFileName = sampleParameters.get (this.tags.sampleFileAttribute ());
        if (encodedSampleFileName == null)
            encodedSampleFileName = sampleParameters.get (this.tags.sampleFileExAttribute ());
        if (encodedSampleFileName == null)
        {
            this.notifier.logError ("IDS_NKI_SAMPLE_FILE_ATTRIBUTE_MISSING");
            return Optional.empty ();
        }

        return this.getFileFromEncodedSampleFileName (encodedSampleFileName, sourcePath, isMonolith);
    }


    /**
     * Decodes an encoded sample file name and returns the respective File if it can be found.
     *
     * @param encodedSampleFileName The encoded sample file name
     * @param sourcePath The canonical path which contains the NKI file
     * @param isMonolith True if samples are contained in the NKI as well
     * @return The File if it can be found, null else
     * @throws IOException Could not decode file name
     */
    protected Optional<File> getFileFromEncodedSampleFileName (final String encodedSampleFileName, final String sourcePath, final boolean isMonolith) throws IOException
    {
        final DecodedPath decodedPath = this.decodeEncodedSampleFileName (encodedSampleFileName);
        if (decodedPath.getLibrary () != null)
            throw new IOException (Functions.getMessage ("IDS_NKI_SAMPLES_IN_LIBRARY_NOT_SUPPORTED"));

        final String samplePath = decodedPath.getPath ();
        if (isMonolith)
            return Optional.of (new File (samplePath));

        final File parentFolder = new File (sourcePath);

        File sampleFile = null;
        if (decodedPath.isAbsolute ())
        {
            final Path absoluteParentPath = Paths.get (samplePath);
            final String originalAbsoluteParentPath = absoluteParentPath.getParent ().toString ();

            // First check if this absolute path was searched before
            final String resultPath = this.absolutePathLookupSuccess.get (originalAbsoluteParentPath);
            if (resultPath != null)
            {
                sampleFile = new File (resultPath, absoluteParentPath.getFileName ().toString ());
                if (sampleFile.exists () && sampleFile.canRead ())
                    return Optional.of (sampleFile);
            }

            // If it is an absolute path, try to find the sample file in all possible sub-paths from
            // the current folder
            File subFolder = null;
            for (int i = absoluteParentPath.getNameCount () - 1; i > 0; i--)
            {
                final String folder = absoluteParentPath.getName (i).toString ();
                subFolder = subFolder == null ? new File (folder) : new File (folder, subFolder.getPath ());
                sampleFile = new File (parentFolder, subFolder.getPath ());
                if (sampleFile.exists () && sampleFile.canRead ())
                    return Optional.of (this.logFoundFolder (sampleFile, originalAbsoluteParentPath));
            }

            // Search all sub-folders
            final String fileName = absoluteParentPath.getFileName ().toString ();
            sampleFile = AbstractDetector.findSampleFile (this.notifier, parentFolder, null, fileName, 0);
            if (sampleFile != null)
                return Optional.of (this.logFoundFolder (sampleFile, originalAbsoluteParentPath));

            this.notifier.logError ("IDS_NKI_SAMPLE_FILE_DOES_NOT_EXIST", samplePath);
            return Optional.empty ();
        }

        sampleFile = new File (parentFolder, samplePath);
        if (sampleFile.exists () && sampleFile.canRead ())
            return Optional.of (sampleFile);
        // Search all sub-folders - also triggers searching for different extension cases
        // Also go up 1 folder in case this is a library
        sampleFile = AbstractDetector.findSampleFile (this.notifier, parentFolder, null, sampleFile.getAbsolutePath (), 1);
        if (sampleFile.exists () && sampleFile.canRead ())
            return Optional.of (sampleFile);
        this.notifier.logError ("IDS_NKI_SAMPLE_FILE_DOES_NOT_EXIST", sampleFile.getAbsolutePath ());
        return Optional.empty ();
    }


    private File logFoundFolder (final File sampleFile, final String originalAbsoluteParentPath)
    {
        this.absolutePathLookupSuccess.put (sampleFile.getParent (), originalAbsoluteParentPath);
        return sampleFile;
    }


    /**
     * Decodes an encoded sample file name as used in the NKI's respective sample file attribute.
     *
     * @param encodedSampleFileName The encoded sample file name
     * @return The decoded path
     * @throws IOException Could not decode the file name/path
     */
    protected DecodedPath decodeEncodedSampleFileName (final String encodedSampleFileName) throws IOException
    {
        final DecodedPath decodedPath = new DecodedPath ();
        final StringReader reader = new StringReader (encodedSampleFileName);

        // Indicator for extended path?
        final int startChar = reader.read ();
        if (startChar < 0)
        {
            decodedPath.setPath ("");
            return decodedPath;
        }
        if ((char) startChar != '@')
        {
            decodedPath.setPath (encodedSampleFileName.replace ('\\', '/'));
            return decodedPath;
        }

        final StringBuilder path = new StringBuilder ();
        int id;
        while ((id = reader.read ()) != -1)
            switch (id)
            {
                // The disc letter or name name
                case 'v':
                    final String disc = readFolder (reader, encodedSampleFileName);
                    if (!disc.contains (":"))
                        path.append ('/');
                    path.append (disc).append ('/');
                    decodedPath.setAbsolute (true);
                    break;

                // Folder upwards
                case 'b':
                    path.append ("../");
                    break;

                // A directory
                case 'd':
                    path.append (readFolder (reader, encodedSampleFileName)).append ('/');
                    break;

                // The sample's file name
                case 'F', 'f':
                    final char [] fractionBuffer = new char [id == 'f' ? 6 : 11];
                    if (reader.read (fractionBuffer) != fractionBuffer.length)
                        throw error (encodedSampleFileName);
                    int c;
                    while ((c = reader.read ()) != -1)
                        path.append ((char) c);
                    final String finalPath = decodeUTF8Characters (path.toString ());
                    decodedPath.setPath (finalPath);
                    if (finalPath.startsWith ("/"))
                        decodedPath.setAbsolute (true);
                    return decodedPath;

                // A NKS library
                case 'm':
                    path.append (readFolder (reader, encodedSampleFileName));
                    decodedPath.setLibrary (path.toString ());
                    path.setLength (0);
                    break;

                default:
                    throw error (encodedSampleFileName);
            }

        throw error (encodedSampleFileName);
    }


    private static String decodeUTF8Characters (final String text)
    {
        if (!text.contains ("%"))
            return text;

        final Matcher m = UTF_PATTERN.matcher (text);
        final StringBuffer sb = new StringBuffer ();
        while (m.find ())
            m.appendReplacement (sb, new String (Character.toChars (Integer.parseInt (m.group (1), 16))));
        m.appendTail (sb);

        return sb.toString ();
    }


    /**
     * Retrieves a TriggerType from a group's parameters.
     *
     * @param groupParameters The group element to retrieve the TriggerType from
     * @return The TriggerType that could be retrieved. In doubt, TriggerType.ATTACK is returned.
     */
    protected abstract TriggerType getTriggerTypeFromGroupElement (final Map<String, String> groupParameters);


    /**
     * Retrieves a group element's name.
     *
     * @param groupElement The group element
     * @return The name as a String. If no name was found, "" is returned.
     */
    private String getGroupName (final Element groupElement)
    {
        final String groupName = groupElement.getAttribute (this.tags.groupNameAttribute ());
        return groupName == null ? "" : groupName;
    }


    /**
     * Reads all modulator envelopes from a group element.
     *
     * @param groupElement The group element
     * @return The found envelopes
     */
    private Map<String, IEnvelopeModulator> readGroupInternalModulators (final Element groupElement)
    {
        final Element modulatorsElement = XMLUtils.getChildElementByName (groupElement, this.tags.intModulatorsElement ());
        if (modulatorsElement == null)
            return Collections.emptyMap ();

        final Map<String, IEnvelopeModulator> modulators = new HashMap<> ();
        for (final Element modulatorElement: XMLUtils.getChildElementsByName (modulatorsElement, this.tags.intModulatorElement ()))
        {
            final Element envElement = XMLUtils.getChildElementByName (modulatorElement, this.tags.envelopeElement ());
            if (envElement != null && !this.hasNameValuePairs (modulatorElement, this.tags.bypassParam (), this.tags.yes ()))
            {
                final Optional<String> modulationTarget = this.getModulationTarget (modulatorElement);
                if (modulationTarget.isPresent ())
                {
                    final double modulationIntensity = this.getModulationIntensity (modulatorElement);
                    if (modulationIntensity != 0)
                    {
                        final Optional<IEnvelopeModulator> modulatorOpt = this.readModulatorFromElement (envElement);
                        if (modulatorOpt.isPresent ())
                        {
                            final IEnvelopeModulator modulator = modulatorOpt.get ();
                            modulator.setDepth (modulationIntensity);
                            modulators.put (modulationTarget.get (), modulator);
                        }
                    }
                }
            }
        }
        return modulators;
    }


    /**
     * Reads the filter settings from a group element. Only present for Kontakt 1.
     *
     * @param groupElement The group element
     * @return The filter or null if none is found
     */
    private Optional<IFilter> readFilter (final Element groupElement)
    {
        final Element filterElement = XMLUtils.getChildElementByName (groupElement, this.tags.groupFilter ());
        if (filterElement == null)
            return Optional.empty ();
        final Map<String, String> valueMap = this.readValueMap (filterElement);
        if (valueMap.isEmpty ())
            return Optional.empty ();
        final String type = valueMap.get ("type");
        if (type == null)
            return Optional.empty ();
        final Matcher matcher = FILTER_TYPE_PATTERN.matcher (type);
        if (!matcher.matches ())
        {
            this.notifier.logError ("IDS_NKI_UNKNOWN_FILTER_TYPE", type);
            return Optional.empty ();
        }
        FilterType filterType;
        switch (matcher.group (1))
        {
            case "lp":
                filterType = FilterType.LOW_PASS;
                break;
            case "hp":
                filterType = FilterType.HIGH_PASS;
                break;
            case "bp":
                filterType = FilterType.BAND_PASS;
                break;
            default:
                return Optional.empty ();
        }

        // The cutoff is stored logarithmically normalized to [0..1] (see the writing side),
        // 1.0 is the fully open filter at 21.8 kHz
        final String cutoffText = valueMap.get ("cutoff");
        final double normalizedCutoff = cutoffText == null ? 1.0 : Double.parseDouble (cutoffText);
        final double cutoff = MathUtils.denormalizeFrequency (Math.clamp (normalizedCutoff, 0, 1), 21800.0);
        final String resonanceText = valueMap.get ("resonance");
        final double resonance = resonanceText == null ? 0 : Double.parseDouble (resonanceText);
        return Optional.of (new DefaultFilter (filterType, Integer.parseInt (matcher.group (2)), cutoff, resonance));
    }


    /**
     * Reads a modulator from a modulator XML element.
     *
     * @param envElement The modulator XML element
     * @return The IModulator, if modulator could be read successfully, otherwise null
     */
    private Optional<IEnvelopeModulator> readModulatorFromElement (final Element envElement)
    {
        final String envType = envElement.getAttribute (this.tags.envTypeAttribute ());
        if (envType == null)
            return Optional.empty ();

        try
        {
            final IEnvelopeModulator modulator = new DefaultEnvelopeModulator (0);
            final IEnvelope env = modulator.getSource ();

            final Map<String, String> envParams = this.readValueMap (envElement);
            env.setAttackSlope (-getDouble (envParams, this.tags.attackCurveParam ()));
            env.setAttackTime (getDouble (envParams, this.tags.attackParam ()) / 1000.0d);
            env.setHoldTime (AbstractNKIMetadataFileHandler.getDouble (envParams, this.tags.holdParam ()) / 1000.0d);
            env.setDecayTime (AbstractNKIMetadataFileHandler.getDouble (envParams, this.tags.decayParam ()) / 1000.0d);

            if (!envType.equals (this.tags.ahdEnvTypeValue ()))
            {
                env.setSustainLevel (AbstractNKIMetadataFileHandler.getDouble (envParams, this.tags.sustainParam ()));
                env.setReleaseTime (AbstractNKIMetadataFileHandler.getDouble (envParams, this.tags.releaseParam ()) / 1000.0d);
            }
            return Optional.of (modulator);
        }
        catch (final ValueNotAvailableException ignoredException)
        {
            return Optional.empty ();
        }
    }


    /**
     * Returns a String value from a value map.
     *
     * @param valueMap The value
     * @param valueName The value's name
     * @return The String value
     * @throws ValueNotAvailableException indicates that the valueName is not in the valueMap
     */
    private static String getString (final Map<String, String> valueMap, final String valueName) throws ValueNotAvailableException
    {
        final String valueStr = valueMap.get (valueName);
        if (valueStr == null)
            throw new ValueNotAvailableException (valueName);
        return valueStr;
    }


    /**
     * Returns an integer value from a value map.
     *
     * @param valueMap The value
     * @param valueName The value's name
     * @return The integer value
     * @throws ValueNotAvailableException indicates that the valueName is not in the valueMap
     */
    private static int getInt (final Map<String, String> valueMap, final String valueName) throws ValueNotAvailableException
    {
        final String valueStr = valueMap.get (valueName);
        if (valueStr == null)
            throw new ValueNotAvailableException (valueName);
        return Integer.parseInt (valueStr);
    }


    /**
     * Returns a double value from a value map.
     *
     * @param valueMap The value
     * @param valueName The value's name
     * @return The double value
     * @throws ValueNotAvailableException Indicates that the valueName is not in the valueMap
     */
    private static double getDouble (final Map<String, String> valueMap, final String valueName) throws ValueNotAvailableException
    {
        final String valueStr = valueMap.get (valueName);
        if (valueStr == null)
            throw new ValueNotAvailableException (valueName);
        return Double.parseDouble (valueStr);
    }


    /**
     * Retrieves the target from the given modulator element.
     *
     * @param modulator The modulator element
     * @return The target value, null if not present
     */
    protected abstract Optional<String> getModulationTarget (Element modulator);


    /**
     * Retrieves the intensity from the given modulator element.
     *
     * @param modulator The modulator element
     * @return The intensity value, 0 if not present or could parsed
     */
    protected abstract double getModulationIntensity (Element modulator);


    /**
     * Checks if an element has a value map containing a required set of (name, value) pairs.
     *
     * @param element The element
     * @param nameValuePairs A number of name, value pairs, e.g. "volume", "1", "bypass", "no"
     * @return True if the element has all name value pairs in its value map, false else.
     */
    protected boolean hasNameValuePairs (final Element element, final String... nameValuePairs)
    {
        if (nameValuePairs == null)
            return true;

        final Map<String, String> parameters = this.readValueMap (element);
        for (int idx = 0; idx < nameValuePairs.length; idx += 2)
        {
            final String name = nameValuePairs[idx];
            if (parameters.containsKey (name))
            {
                final int valueIdx = idx + 1;
                if (valueIdx < nameValuePairs.length)
                {
                    final String value = nameValuePairs[valueIdx];
                    if (!parameters.get (name).equals (value))
                        return false;
                }
            }
            else
                return false;
        }
        return true;
    }


    /**
     * Finds a child element of a given parent element that has a value map containing a required
     * set of (name, value) pairs.
     *
     * @param parentElement The parent element
     * @param elementNameToBeFound The name of the element to be found
     * @param nameValuePairs A number of name, value pairs, e.g. "volume", "1", "bypass", "no"
     * @return The element with the value name pairs. If none could be found, null is returned.
     */
    protected Optional<Element> findElementWithParameters (final Element parentElement, final String elementNameToBeFound, final String... nameValuePairs)
    {
        for (final Element elementOfInterest: XMLUtils.getChildElementsByName (parentElement, elementNameToBeFound))
        {
            final boolean doesMatch = this.hasNameValuePairs (elementOfInterest, nameValuePairs);
            if (doesMatch)
                return Optional.of (elementOfInterest);
        }
        return Optional.empty ();
    }


    /**
     * Reads the pitch bend configuration from the external modulators of a group element.
     *
     * @param extModulators All external modulators of the group
     * @return The number of semi-tones (up=down)
     */
    private int readGroupPitchBend (final List<ExternalModulation> extModulators)
    {
        for (final ExternalModulation extModulator: extModulators)
            if (this.tags.pitchBendValue ().equals (extModulator.source) && this.tags.pitchValue ().equals (extModulator.target))
                return Math.clamp ((int) Math.round (extModulator.intensity * 1200), -9600, 9600);
        return -1;
    }


    /**
     * Reads the value by which the amplitude is modulated by the velocity from a group element.
     *
     * @param extModulators All external modulators of the group
     * @return The number of modulation (0..1)
     */
    private double readGroupAmplitudeVelocityModulator (final List<ExternalModulation> extModulators)
    {
        for (final ExternalModulation extModulator: extModulators)
            if (this.tags.velocityValue ().equals (extModulator.source) && this.tags.volumeValue ().equals (extModulator.target))
                return extModulator.intensity;
        return -1;
    }


    /**
     * Read all external not bypassed modulators from a group element.
     *
     * @param groupElement The group element to read from
     * @return The active modulators
     */
    private List<ExternalModulation> readExtModulators (final Element groupElement)
    {
        final Element modulatorsElement = XMLUtils.getChildElementByName (groupElement, this.tags.extModulatorsElement ());
        if (modulatorsElement == null)
            return Collections.emptyList ();

        final List<ExternalModulation> extModulators = new ArrayList<> ();
        for (final Element modulator: XMLUtils.getChildElementsByName (modulatorsElement, this.tags.extModulatorElement ()))
        {
            final Map<String, String> modulatorParams = this.readValueMap (modulator);
            if (modulatorParams == null)
                continue;
            final String source = modulatorParams.get (this.tags.sourceParam ());
            if (source == null)
                continue;
            final String target = modulatorParams.get (this.tags.targetParam ());
            if (target == null)
            {
                // V2 has (multiple) targets in sub-elemnts
                final Element targetsElement = XMLUtils.getChildElementByName (modulator, K2Tag.K2_TARGETS_ELEMENT);
                if (targetsElement == null)
                    continue;
                for (final Element targetElement: XMLUtils.getChildElementsByName (targetsElement, K2Tag.K2_TARGET_ELEMENT, false))
                    this.createExtModulator (extModulators, source, modulatorParams, this.readValueMap (targetElement));
            }
            else
                this.createExtModulator (extModulators, source, modulatorParams, modulatorParams);
        }

        return extModulators;
    }


    private void createExtModulator (final List<ExternalModulation> extModulators, final String source, final Map<String, String> modulatorElementParams, final Map<String, String> targetElementParams)
    {
        // Ignore bypassed modulators
        final String bypass = modulatorElementParams.get (this.tags.bypassParam ());
        if (bypass != null && bypass.equals ("yes"))
            return;

        final ExternalModulation extModulator = new ExternalModulation ();
        extModulator.source = source;
        extModulator.target = targetElementParams.get (this.tags.targetParam ());
        try
        {
            extModulator.intensity = Double.parseDouble (targetElementParams.get (this.tags.intensityParam ()));
        }
        catch (final NumberFormatException ignoredException)
        {
            return;
        }
        extModulators.add (extModulator);
    }


    /**
     * Finds a group's zone elements.
     *
     * @param groupElement The group element
     * @param zoneElements The zone elements from which to find the zones belonging to the group
     * @return An array of zone elements belonging to the group element
     */
    private Element [] findGroupZones (final Element groupElement, final List<Element> zoneElements)
    {
        final int index = XMLUtils.getIntegerAttribute (groupElement, this.tags.indexAttribute (), -1);
        if (index == -1 || zoneElements == null)
            return new Element [0];

        final List<Element> matchingZoneElements = new ArrayList<> ();
        for (final Element zoneElement: zoneElements)
        {
            final int groupIndex = XMLUtils.getIntegerAttribute (zoneElement, this.tags.groupIndexAttribute (), -1);
            if (groupIndex == index)
                matchingZoneElements.add (zoneElement);
        }
        return matchingZoneElements.toArray (new Element [matchingZoneElements.size ()]);
    }


    private static String formatDouble (final double value)
    {
        return String.format (Locale.US, "%.6f", Double.valueOf (value));
    }


    private static IOException error (final String encodedSampleFileName)
    {
        return new IOException (Functions.getMessage ("IDS_NKI_UNEXPECTED_STATE", encodedSampleFileName));
    }


    private static String readFolder (final StringReader reader, final String encodedSampleFileName) throws IOException
    {
        final char [] lengthBuffer = new char [3];
        if (reader.read (lengthBuffer) != lengthBuffer.length)
            throw error (encodedSampleFileName);
        final int length = Integer.parseInt (new String (lengthBuffer));
        final char [] folder = new char [length];
        if (reader.read (folder) != length)
            throw error (encodedSampleFileName);
        return new String (folder);
    }


    private static class ExternalModulation
    {
        String source;
        String target;
        double intensity;
    }
}
