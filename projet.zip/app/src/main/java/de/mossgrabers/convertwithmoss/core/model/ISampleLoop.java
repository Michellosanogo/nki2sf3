// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.core.model;

import de.mossgrabers.convertwithmoss.core.model.enumeration.LoopType;


/**
 * Interface to the loop of a sample.
 *
 * @author Jürgen Moßgraber
 */
public interface ISampleLoop
{
    /**
     * Is there a loop section?
     *
     * @return The type of the loop
     */
    LoopType getType ();


    /**
     * Is there a loop section.
     *
     * @param type The type of the loop
     */
    void setType (LoopType type);


    /**
     * Should the loop stop when the note enters the release phase of its amplitude envelope? If
     * <code>true</code>, the loop is left at note-off and the remainder of the sample after the
     * loop end is played out - a sustain or 'loop until release' loop (e.g. SoundFont sample mode
     * 3, SFZ <code>loop_sustain</code>, Renoise <code>LoopRelease</code>=true, Kontakt 'until
     * release'). If <code>false</code> (the default), the same loop keeps cycling during the
     * release - a 'loop continuous' loop (e.g. SoundFont sample mode 1, SFZ
     * <code>loop_continuous</code>). This describes the behavior of this very loop on release, not
     * a separate release-phase loop region.
     *
     * @return True if the loop stops at note-off and the remainder is played out (sustain loop)
     */
    boolean isLoopUntilRelease ();


    /**
     * Set whether the loop stops when the note enters the release phase of its amplitude envelope.
     *
     * @param loopUntilRelease True for a sustain / 'until release' loop, false for a continuous
     *            loop
     */
    void setLoopUntilRelease (boolean loopUntilRelease);


    /**
     * Get the start of the loop.
     *
     * @return The start of the loop
     */
    int getStart ();


    /**
     * Set the start of the loop.
     *
     * @param loopStart The start of the loop
     */
    void setStart (int loopStart);


    /**
     * Get the end of the loop. This is inclusive - the sample specified is played as part of the
     * loop.
     *
     * @return The end of the loop
     */
    int getEnd ();


    /**
     * Set the end of the loop. This is inclusive - the sample specified is played as part of the
     * loop.
     *
     * @param loopEnd The end of the loop
     */
    void setEnd (int loopEnd);


    /**
     * Get the loop length in samples.
     *
     * @return The loop length
     */
    int getLength ();


    /**
     * Get the loop tuning. Useful with very short loops such as single-cycle waveforms, which can
     * be slightly out of tune compared to the complete waveform from which they were cut.
     *
     * @return The tuning positive or negative semi-tones, which means that 0.01 represents 1 cent
     *         (1 semi-tone is 100 cent), relative to the zone tuning. 0 = no offset.
     */
    double getTuning ();


    /**
     * Set the loop tuning.
     *
     * @param tuning The tuning positive or negative semi-tones, which means that 0.01 represents 1
     *            cent (1 semi-tone is 100 cent), relative to the zone tuning. 0 = no offset.
     */
    void setTuning (double tuning);


    /**
     * Get the loop cross-fade.
     *
     * @return The cross-fade value in the range of [0..1] which is [0..100%]
     */
    double getCrossfade ();


    /**
     * Get the loop cross-fade in samples (frames).
     *
     * @return The cross-fade value in samples
     */
    int getCrossfadeInSamples ();


    /**
     * Set the loop cross-fade which is relative to the length of the loop. 100% cross-fades the
     * whole loop. 0% creates no cross-fade.
     *
     * @param crossfade The cross-fade value in the range of [0..1] which is [0..100%]
     */
    void setCrossfade (double crossfade);


    /**
     * Set the loop cross-fade in samples (frames). Calculates the relative value from the loop
     * length which means that the loop start and end must have been already set correctly.
     *
     * @param crossfadeSamples The cross-fade value in samples
     */
    void setCrossfadeInSamples (int crossfadeSamples);


    /**
     * Set the loop cross-fade in milli-seconds. Calculates the relative value from the loop length
     * which means that the loop start and end must have been already set correctly.
     *
     * @param crossfadeSeconds The cross-fade value in seconds
     * @param sampleRate The sample rate to calculate between samples and milli-seconds
     */
    void setCrossfadeInSeconds (double crossfadeSeconds, int sampleRate);
}
