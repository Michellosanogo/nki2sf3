// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.core.detector;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import de.mossgrabers.convertwithmoss.core.IMultisampleSource;
import de.mossgrabers.convertwithmoss.core.SafeFileNames;
import de.mossgrabers.convertwithmoss.core.model.IEnvelope;
import de.mossgrabers.convertwithmoss.core.model.IEnvelopeModulator;
import de.mossgrabers.convertwithmoss.core.model.IFilter;
import de.mossgrabers.convertwithmoss.core.model.IGroup;
import de.mossgrabers.convertwithmoss.core.model.ISampleZone;
import de.mossgrabers.convertwithmoss.core.model.enumeration.TriggerType;


/**
 * Holds the data of a multi-sample source.
 *
 * @author Jürgen Moßgraber
 */
public class DefaultMultisampleSource extends DefaultSource implements IMultisampleSource
{
    private File         sourceFile;
    private String []    subPath;
    private List<IGroup> groups             = Collections.emptyList ();

    private int          polyphony          = 0;
    private boolean      isMonophonicLegato = false;
    private double       portamentoTime     = 0;


    /**
     * Constructor. Values must be set by setters!
     */
    public DefaultMultisampleSource ()
    {
        this (null, null, null);
    }


    /**
     * Constructor.
     *
     * @param sourceFile The folder (contains the multi-sample source or the file itself)
     * @param subPath The names of the sub folders which contain the samples
     * @param name The name of the multi-sample
     */
    public DefaultMultisampleSource (final File sourceFile, final String [] subPath, final String name)
    {
        super (name);

        this.sourceFile = sourceFile;
        this.subPath = subPath;
    }


    /** {@inheritDoc} */
    @Override
    public File getSourceFile ()
    {
        return this.sourceFile;
    }


    /** {@inheritDoc} */
    @Override
    public void setFolder (final File folder)
    {
        this.sourceFile = folder;
    }


    /** {@inheritDoc} */
    @Override
    public String [] getSubPath ()
    {
        return this.subPath;
    }


    /** {@inheritDoc} */
    @Override
    public void setSubPath (final String [] subFolders)
    {
        this.subPath = subFolders;
    }


    /** {@inheritDoc} */
    @Override
    public void extendSubPath (final String additionalFolder)
    {
        final String [] parts = this.getSubPath ();
        final String [] result = new String [parts.length + 1];
        result[0] = parts[0];
        result[1] = SafeFileNames.create (additionalFolder);
        System.arraycopy (parts, 1, result, 2, parts.length - 1);
        this.setSubPath (result);
    }


    /** {@inheritDoc} */
    @Override
    public List<IGroup> getGroups ()
    {
        return this.groups;
    }


    /** {@inheritDoc} */
    @Override
    public List<IGroup> getNonEmptyGroups (final boolean filterReleaseTriggers)
    {
        final List<IGroup> cleanedGroups = new ArrayList<> ();
        for (final IGroup group: this.groups)
        {
            final List<ISampleZone> sampleMetadata = group.getSampleZones ();
            if (sampleMetadata.isEmpty ())
                continue;

            if (filterReleaseTriggers)
            {
                // There needs to be at least one sample with a normal attack trigger
                for (final ISampleZone sample: sampleMetadata)
                    if (sample.getTrigger () != TriggerType.RELEASE)
                    {
                        cleanedGroups.add (group);
                        break;
                    }
            }
            else
                cleanedGroups.add (group);
        }
        return cleanedGroups;
    }


    /** {@inheritDoc} */
    @Override
    public void setGroups (final List<IGroup> groups)
    {
        this.groups = new ArrayList<> (groups);
    }


    /** {@inheritDoc} */
    @Override
    public Optional<IFilter> getGlobalFilter ()
    {
        IFilter globalFilter = null;
        for (final IGroup group: this.groups)
            for (final ISampleZone sampleMetadata: group.getSampleZones ())
            {
                final Optional<IFilter> optFilter = sampleMetadata.getFilter ();
                if (optFilter.isEmpty ())
                    return Optional.empty ();

                final IFilter filter = optFilter.get ();
                if (globalFilter == null)
                    globalFilter = filter;
                else if (!globalFilter.equals (filter))
                    return Optional.empty ();
            }
        return Optional.ofNullable (globalFilter);
    }


    /** {@inheritDoc} */
    @Override
    public void setGlobalFilter (final IFilter filter)
    {
        for (final IGroup group: this.groups)
            for (final ISampleZone zone: group.getSampleZones ())
                zone.setFilter (filter);
    }


    /** {@inheritDoc} */
    @Override
    public void setGlobalPitchEnvelope (final double depth, final IEnvelope envelope)
    {
        for (final IGroup group: this.groups)
            for (final ISampleZone zone: group.getSampleZones ())
            {
                final IEnvelopeModulator pitchEnvelopeModulator = zone.getPitchEnvelopeModulator ();
                pitchEnvelopeModulator.setDepth (depth);
                pitchEnvelopeModulator.setSource (envelope);
            }
    }


    /** {@inheritDoc} */
    @Override
    public Optional<Double> getGlobalAmplitudeVelocity ()
    {
        Double globalVelocity = null;
        for (final IGroup group: this.groups)
            for (final ISampleZone sampleZone: group.getSampleZones ())
            {
                final double depth = sampleZone.getAmplitudeVelocityModulator ().getDepth ();
                if (globalVelocity == null)
                    globalVelocity = Double.valueOf (depth);
                else if (globalVelocity.doubleValue () != depth)
                    return Optional.empty ();
            }
        return Optional.ofNullable (globalVelocity);
    }


    /** {@inheritDoc} */
    @Override
    public Optional<IEnvelopeModulator> getGlobalAmplitudeModulator ()
    {
        IEnvelopeModulator modulator = null;
        for (final IGroup group: this.groups)
            for (final ISampleZone sampleMetadata: group.getSampleZones ())
            {
                final IEnvelopeModulator ampModulator = sampleMetadata.getAmplitudeEnvelopeModulator ();
                if (modulator == null)
                    modulator = ampModulator;
                else if (modulator.getDepth () != ampModulator.getDepth () || !modulator.getSource ().equals (ampModulator.getSource ()))
                    return Optional.empty ();
            }
        return modulator == null ? Optional.empty () : Optional.ofNullable (modulator);
    }


    /** {@inheritDoc} */
    @Override
    public Optional<Double> getGlobalPanning ()
    {
        Double globalPanning = null;
        for (final IGroup group: this.groups)
            for (final ISampleZone sampleZone: group.getSampleZones ())
            {
                final double pan = sampleZone.getPanning ();
                if (globalPanning == null)
                    globalPanning = Double.valueOf (pan);
                else if (globalPanning.doubleValue () != pan)
                    return Optional.empty ();
            }
        return globalPanning == null ? Optional.empty () : Optional.of (globalPanning);
    }


    /** {@inheritDoc} */
    @Override
    public Optional<Double> getGlobalGain ()
    {
        Double globalGain = null;
        for (final IGroup group: this.groups)
            for (final ISampleZone sampleZone: group.getSampleZones ())
            {
                final double gain = sampleZone.getGain ();
                if (globalGain == null)
                    globalGain = Double.valueOf (gain);
                else if (globalGain.doubleValue () != gain)
                    return Optional.empty ();
            }
        return globalGain == null ? Optional.empty () : Optional.of (globalGain);
    }


    /** {@inheritDoc} */
    @Override
    public Optional<Double> getGlobalTuning ()
    {
        Double globalTuning = null;
        for (final IGroup group: this.groups)
            for (final ISampleZone sampleZone: group.getSampleZones ())
            {
                final double tuning = sampleZone.getTuning ();
                if (globalTuning == null)
                    globalTuning = Double.valueOf (tuning);
                else if (globalTuning.doubleValue () != tuning)
                    return Optional.empty ();
            }
        return globalTuning == null ? Optional.empty () : Optional.of (globalTuning);
    }


    /** {@inheritDoc} */
    @Override
    public int getLowestKey ()
    {
        int lowestKey = 127;
        for (final IGroup group: this.groups)
            for (final ISampleZone zone: group.getSampleZones ())
                if (zone.getKeyLow () < lowestKey)
                    lowestKey = zone.getKeyLow ();
        return lowestKey;
    }


    /** {@inheritDoc} */
    @Override
    public int getHighestKey ()
    {
        int highestKey = 0;
        for (final IGroup group: this.groups)
            for (final ISampleZone zone: group.getSampleZones ())
                if (zone.getKeyHigh () > highestKey)
                    highestKey = zone.getKeyHigh ();
        return highestKey;
    }


    /** {@inheritDoc} */
    @Override
    public int getPolyphony ()
    {
        return this.polyphony;
    }


    /** {@inheritDoc} */
    @Override
    public void setPolyphony (final int polyphony)
    {
        this.polyphony = polyphony;
    }


    /** {@inheritDoc} */
    @Override
    public boolean isMonophonicLegato ()
    {
        return this.isMonophonicLegato;
    }


    /** {@inheritDoc} */
    @Override
    public void setMonophonicLegato (final boolean isMonophonicLegato)
    {
        this.isMonophonicLegato = isMonophonicLegato;
    }


    /** {@inheritDoc} */
    @Override
    public double getPortamentoTime ()
    {
        return this.portamentoTime;
    }


    /** {@inheritDoc} */
    @Override
    public void setPortamentoTime (final double portamentoTime)
    {
        this.portamentoTime = portamentoTime;
    }
}
