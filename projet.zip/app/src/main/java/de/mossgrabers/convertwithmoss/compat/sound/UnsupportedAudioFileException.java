package de.mossgrabers.convertwithmoss.compat.sound;

/** Thrown if an audio file format is not supported (replacement for javax.sound.sampled). */
public class UnsupportedAudioFileException extends Exception
{
    private static final long serialVersionUID = 1L;

    /** Constructor. */
    public UnsupportedAudioFileException ()
    {
        super ();
    }

    /**
     * Constructor.
     *
     * @param message The message
     */
    public UnsupportedAudioFileException (final String message)
    {
        super (message);
    }
}
