// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2019-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.convertwithmoss.format;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;


/**
 * Detects category tags.
 *
 * @author Jürgen Moßgraber
 */
@SuppressWarnings("javadoc")
public class TagDetector
{
    private static final Pattern                DELIMITER_PATTERN             = Pattern.compile ("[ _-]+");

    private static final Map<String, String []> CATEGORIES                    = new HashMap<> ();
    private static final Map<String, String>    CATEGORY_LOOKUP               = new TreeMap<> (new StringLengthComparator ());
    private static final Map<String, String>    CATEGORY_PREFIX_LOOKUP        = new HashMap<> ();
    private static final Map<String, String>    KEYWORD_LOOKUP                = new TreeMap<> (new StringLengthComparator ());
    private static final List<String>           WORD_DICT                     = new ArrayList<> ();

    public static final String                  CATEGORY_UNKNOWN              = "Unknown";
    public static final String                  CATEGORY_ACOUSTIC_DRUM        = "Acoustic Drum";
    public static final String                  CATEGORY_BASS                 = "Bass";
    public static final String                  CATEGORY_BELL                 = "Bell";
    public static final String                  CATEGORY_BRASS                = "Brass";
    public static final String                  CATEGORY_CHIP                 = "Chip";
    public static final String                  CATEGORY_VOCAL                = "Vocal";
    public static final String                  CATEGORY_CHROMATIC_PERCUSSION = "Chromatic Percussion";
    public static final String                  CATEGORY_CLAP                 = "Clap";
    public static final String                  CATEGORY_DESTRUCTION          = "Destruction";
    public static final String                  CATEGORY_DRONE                = "Drone";
    public static final String                  CATEGORY_DRUM                 = "Drum";
    public static final String                  CATEGORY_ENSEMBLE             = "Ensemble";
    public static final String                  CATEGORY_FX                   = "FX";
    public static final String                  CATEGORY_GUITAR               = "Guitar";
    public static final String                  CATEGORY_HITS                 = "Hits";
    public static final String                  CATEGORY_HI_HAT               = "Hi-Hat";
    public static final String                  CATEGORY_KEYBOARD             = "Keyboard";
    public static final String                  CATEGORY_KICK                 = "Kick";
    public static final String                  CATEGORY_LEAD                 = "Lead";
    public static final String                  CATEGORY_MONOSYNTH            = "Monosynth";
    public static final String                  CATEGORY_ORCHESTRAL           = "Orchestral";
    public static final String                  CATEGORY_ORGAN                = "Organ";
    public static final String                  CATEGORY_PAD                  = "Pad";
    public static final String                  CATEGORY_PERCUSSION           = "Percussion";
    public static final String                  CATEGORY_PIANO                = "Piano";
    public static final String                  CATEGORY_PIPE                 = "Pipe";
    public static final String                  CATEGORY_PLUCK                = "Pluck";
    public static final String                  CATEGORY_SNARE                = "Snare";
    public static final String                  CATEGORY_STRINGS              = "Strings";
    public static final String                  CATEGORY_SYNTH                = "Synth";
    public static final String                  CATEGORY_WINDS                = "Winds";
    public static final String                  CATEGORY_LOOPS                = "Loops";
    public static final String                  CATEGORY_WORLD                = "World";

    /**
     * Separates the words of a text: everything which is not a letter or a digit, the change from a
     * lower to an upper case letter and the change between a letter and a digit.
     */
    private static final Pattern                WORD_SEPARATOR                = Pattern.compile ("[^\\p{L}\\p{N}]+|(?<=\\p{Ll})(?=\\p{Lu})|(?<=\\p{L})(?=\\p{N})|(?<=\\p{N})(?=\\p{L})");

    private static final String []              KEYWORDS                      =
    {
        "acoustic",
        "aggressive",
        "analog",
        "arp",
        "arpeggiated",
        "atmo",
        "bright",
        "channel",
        "chord",
        "clean",
        "constant",
        "crossmod",
        "dark",
        "deep",
        "deephouse",
        "defined",
        "detuned",
        "digital",
        "drumandbass",
        "dry",
        "duo",
        "dynamic",
        "ebm",
        "edm",
        "effects",
        "electric",
        "evolving",
        "expressive",
        "fast",
        "fx",
        "glide",
        "hard",
        "harmonic",
        "host_synced",
        "house",
        "inharmonic",
        "jazz",
        "layered",
        "linnstrument",
        "major",
        "metallic",
        "mod",
        "modern",
        "modulated",
        "mono",
        "mpe",
        "narrow",
        "natural",
        "neurofunk",
        "noisy",
        "organic",
        "osc_sync",
        "percussive",
        "phat",
        "pop",
        "poly",
        "rock",
        "rich",
        "seq",
        "sequenced",
        "slow",
        "slow_release",
        "soft",
        "soft_attack",
        "spacey",
        "sparse",
        "static",
        "sustained",
        "synthetic",
        "techstep",
        "trance",
        "unison",
        "vintage",
        "wet",
        "wide"
    };

    static
    {
        CATEGORIES.put (CATEGORY_ACOUSTIC_DRUM, new String []
        {
            CATEGORY_ACOUSTIC_DRUM
        });
        CATEGORIES.put (CATEGORY_BASS, new String []
        {
            "Acoustic Bs",
            "Bass Guitar",
            "Funk Slide",
            "Picked Bs",
            "Fingered",
            "Fretless",
            "Fretl",
            "Reese",
            "Slap",
            "Funk",
            CATEGORY_BASS,
            "303"
        });
        CATEGORIES.put (CATEGORY_BELL, new String []
        {
            CATEGORY_BELL,
            "Musical Box",
            "Music Box",
            "Fantasia",
            "Tubular",
            "Carillon",
            "Glocke"
        });
        CATEGORIES.put (CATEGORY_BRASS, new String []
        {
            CATEGORY_BRASS,
            "Trombone",
            "Trumpet",
            "Cornet",
            "Trombon",
            "Bugle",
            "Tromb",
            "Horn",
            "Tuba",
            "Trpt",
            "Bras",
            "Brs"
        });
        // 'Wave' is deliberately not a keyword: it is part of the names of the wavetable
        // synthesizers
        // (Waldorf Microwave and Wave, PPG Wave, Korg Wavestation) and of the folders which hold
        // their sounds, and those are not chip sounds
        CATEGORIES.put (CATEGORY_CHIP, new String []
        {
            CATEGORY_CHIP,
            "Commodore",
            "Chiptune",
            "Computer",
            "Nintendo",
            "Gameboy",
            "Arcade",
            "8-Bit",
            "Atari",
            "Amiga",
            "8Bit",
            "C64",
            "CPU"
        });
        CATEGORIES.put (CATEGORY_VOCAL, new String []
        {
            CATEGORY_VOCAL,
            "Microphone",
            "Gregorian",
            "Mixed Cho",
            "Whisper",
            "Female",
            "Vocode",
            "Choral",
            "Speech",
            "Speack",
            "Adlibs",
            "Choir",
            "Voice",
            "Shout",
            "Sing",
            "Male",
            "Vox",
            "Boy",
            "Ahh",
            "Ohh"
        });
        CATEGORIES.put (CATEGORY_CHROMATIC_PERCUSSION, new String []
        {
            CATEGORY_CHROMATIC_PERCUSSION,
            "Glockenspiel",
            "Vibraphone",
            "Vebraphone",
            "Vabraphone",
            "Xylophone",
            "SteelDrum",
            "SteelDrm",
            "Marimba",
            "Celesta",
            "Kalimba",
            "Balafon",
            "Barafon",
            "Talkdr",
            "Mallet",
            "Xylo"
        });
        CATEGORIES.put (CATEGORY_CLAP, new String []
        {
            CATEGORY_CLAP
        });
        CATEGORIES.put (CATEGORY_DESTRUCTION, new String []
        {
            CATEGORY_DESTRUCTION,
            "Distort",
        });
        CATEGORIES.put (CATEGORY_DRONE, new String []
        {
            CATEGORY_DRONE
        });
        CATEGORIES.put (CATEGORY_DRUM, new String []
        {
            CATEGORY_DRUM,
            "Reverse Cym",
            "Drum Kit",
            "Drum-Set",
            "Drumset",
            "Rhythm",
            "Cymbal",
            "Crash",
            "Linn",
            "CR78",
            "Gong",
            "Ride",
            "Kit",
            "Tom",
            "707",
            "808",
            "909"
        });
        CATEGORIES.put (CATEGORY_ENSEMBLE, new String []
        {
            CATEGORY_ENSEMBLE,
            "Str Ens",
            "Slo Ens",
            "Ensmbl"
        });
        CATEGORIES.put (CATEGORY_FX, new String []
        {
            CATEGORY_FX,
            "Helicopter",
            "Telephone",
            "Experiment",
            "Explosion",
            "Turntable",
            "Airplane",
            "Seashore",
            "Applause",
            "Surround",
            "Starship",
            "Scratch",
            "Stadium",
            "Cricket",
            "Thunder",
            "Airport",
            "Bicycle",
            "Printer",
            "Subway",
            "Nature",
            "Effect",
            "Animal",
            "Bubble",
            "Stream",
            "Scream",
            "Humour",
            "Sci-Fi",
            "Office",
            "Truck",
            "Drill",
            "SciFi",
            "Paper",
            "Laugh",
            "Punch",
            "Heart",
            "Alarm",
            "Alien",
            "Metal",
            "Noise",
            "Horse",
            "Siren",
            "Glass",
            "Chirp",
            "Sport",
            "Space",
            "Boat",
            "Park",
            "Wind",
            "Rain",
            "Sand",
            "Bird",
            "Door",
            "Yell",
            "Baby",
            "Cow",
            "Gun",
            "Car",
            "Dog",
            "UFO",
            "Jet"
        });
        CATEGORIES.put (CATEGORY_GUITAR, new String []
        {
            "Electric Guitar",
            "Distortion",
            "Acoustic G",
            "Chorus Gt",
            "Overdrive",
            "Steel Git",
            "Hawaiian",
            "Feedback",
            "Charango",
            "Clean Gt",
            "Muted Gt",
            "Mandolin",
            "Ukulele",
            "Jazz Gt",
            "Mute GT",
            "Funk Gt",
            CATEGORY_GUITAR,
            "RockGit",
            "Ovation",
            "Fender",
            "Gibson",
            "Nylon",
            "Rajao",
            "Banjo",
            "RockGt",
            "GMute",
            "Strat",
            "Mute",
            "Guit",
            "GTR"
        });
        CATEGORIES.put (CATEGORY_HITS, new String []
        {
            "Hit"
        });
        CATEGORIES.put (CATEGORY_HI_HAT, new String []
        {
            CATEGORY_HI_HAT,
            "HiHat",
            "HH",
            "Hats"
        });
        CATEGORIES.put (CATEGORY_KEYBOARD, new String []
        {
            CATEGORY_KEYBOARD,
            "Clavinet",
            "Harpsi",
            "Keys",
            "KEY"
        });
        CATEGORIES.put (CATEGORY_KICK, new String []
        {
            CATEGORY_KICK,
            "bass-drum",
            "bassdrum",
            "BD"
        });
        CATEGORIES.put (CATEGORY_LEAD, new String []
        {
            CATEGORY_LEAD,
            "Solo",
            "Unisono",
            "Sync",
            "Supersaw"
        });
        CATEGORIES.put (CATEGORY_MONOSYNTH, new String []
        {
            CATEGORY_MONOSYNTH,
            "Mono Synth",
            "Monophon",
            "Acid"
        });
        CATEGORIES.put (CATEGORY_ORCHESTRAL, new String []
        {
            CATEGORY_ORCHESTRAL,
            "Soundtrack",
            "Orchestra",
            "Soundtr",
            "Cinema",
            "Score",
            "Orch"
        });
        CATEGORIES.put (CATEGORY_ORGAN, new String []
        {
            "Pipe Organ",
            CATEGORY_ORGAN,
            "Tonewheel",
            "Accordion",
            "Bandoneon",
            "Hammond",
            "Farfisa",
            "Leslie",
            "Gospel",
            "Church",
            "Churh",
            "Org",
            "B3",
            "C3"
        });
        CATEGORIES.put (CATEGORY_PAD, new String []
        {
            CATEGORY_PAD,
            "Mellotron",
            "Ambient",
            "Newage",
            "Heaven",
            "Atmo"
        });
        CATEGORIES.put (CATEGORY_PERCUSSION, new String []
        {
            CATEGORY_PERCUSSION,
            "Tambourine",
            "Wood block",
            "Woodblock",
            "Triangle",
            "Castanet",
            "Angklung",
            "Cowbell",
            "Gamelan",
            "Timbale",
            "Timpani",
            "Maracas",
            "Cabasa",
            "Djembe",
            "Shaker",
            "Tombak",
            "Tonbak",
            "Goblet",
            "Dombac",
            "Dombak",
            "Donbak",
            "Dumbek",
            "Brazil",
            "Stick",
            "Chime",
            "Agogo",
            "Bongo",
            "Conga",
            "Guiro",
            "Cuica",
            "Tabla",
            "Taiko",
            "Perc",
            "Zarb",
            "Zap"
        });
        CATEGORIES.put (CATEGORY_PIANO, new String []
        {
            CATEGORY_PIANO,
            "Electric Piano",
            "Digital Piano",
            "Harpsichord",
            "Honky-Tonk",
            "GrandPiano",
            "UpperGrand",
            "Suitcase",
            "Steinway",
            "Wurlitz",
            "E-Piano",
            "AcPiano",
            "Upright",
            "Klavier",
            "Spinet",
            "Celest",
            "Whirly",
            "Mark I",
            "Rhodes",
            "Grand",
            "SCase",
            "Honky",
            "Clav",
            "E.P",
            "Pno",
            "EP"
        });
        CATEGORIES.put (CATEGORY_PIPE, new String []
        {
            "Didgeridoo",
            "Shakuhachi",
            "Shakuhashi",
            "Shinobue",
            "Recorder",
            "Whistle",
            "Piccolo",
            "Bansuri",
            "Bansri",
            "Flute",
            "Basri",
            "Shino",
            CATEGORY_PIPE
        });
        CATEGORIES.put (CATEGORY_PLUCK, new String []
        {
            CATEGORY_PLUCK,
            "Balalaika",
            "Hackbrett",
            "Dulcimer",
            "Mandolin",
            "Shamisen",
            "Berimbau",
            "Birimbau",
            "Yangchin",
            "Yangqin",
            "Bazouki",
            "Zither",
            "Santur",
            "Sitar",
            "Pick",
            "Harp",
            "Koto",
            "Lyre",
            "Erhu",
            "Biwa",
            "Oud"
        });
        CATEGORIES.put (CATEGORY_SNARE, new String []
        {
            CATEGORY_SNARE,
            "Rim"
        });
        CATEGORIES.put (CATEGORY_STRINGS, new String []
        {
            "Double Bass",
            "Pizzicato",
            "Tremolo",
            "Rich St",
            "Solina",
            "Violin",
            "Fiddle",
            "String",
            "Stacc",
            "Violn",
            "Viola",
            "Cello",
            "Celli",
            "Bowed",
            "Score",
            "Arco",
            "Strn",
            "Pizz",
            "Str"
        });
        CATEGORIES.put (CATEGORY_SYNTH, new String []
        {
            "Electronic-Music",
            "Sequence",
            "Prophet",
            "Trance",
            "Analog",
            "Filter",
            "Square",
            "Sweep",
            "Swell",
            "Pulse",
            "Virus",
            "Stack",
            "Sine",
            "Juno",
            "Mini",
            "Moog",
            "2600",
            "Syn",
            "SAW",
            "OB6",
            "DJ"
        });
        CATEGORIES.put (CATEGORY_WINDS, new String []
        {
            "Klarinette",
            "Harmonica",
            "Harmonium",
            "Clarinet",
            "Bag Pipe",
            "Melodica",
            "Woodwind",
            "Bassoon",
            "Musette",
            "Ocarina",
            "BasClar",
            "Bottle",
            "Hohner",
            "Oboe",
            "Alto",
            "Sax"
        });
        CATEGORIES.put (CATEGORY_LOOPS, new String []
        {
            "Speaker",
            "Record",
            "Player",
            "Loop",
            "Beat",
            "Lps",
            "BPM"
        });
        CATEGORIES.put (CATEGORY_WORLD, new String []
        {
            "Chinese",
            "Jamaica",
            "Mideast",
            "Africa",
            "Tribal",
            "Ethnic",
            "India",
            "Asian",
            "Korea",
            "Japan",
            "Cuba"
        });

        // Create inverse map and order by longest names first, to find the most relevant categories
        for (final Map.Entry<String, String []> e: CATEGORIES.entrySet ())
        {
            final String category = e.getKey ();
            for (final String v: e.getValue ())
                CATEGORY_LOOKUP.put (v.toUpperCase (Locale.US), category);
        }

        // The name of a category is a keyword of its own. Not every keyword list repeats it, and a
        // shorter keyword of another category wins the contains-matching in that case: 'Winds' was
        // detected as FX (from the 'Wind' sound effect) and 'World' was not detected at all. This
        // matters because a category is written as text into many formats and read back from there.
        for (final String category: CATEGORIES.keySet ())
            CATEGORY_LOOKUP.putIfAbsent (category.toUpperCase (Locale.US), category);

        // A category tag at the very start of a name declares the intended category explicitly
        // (a wide-spread naming convention in commercial libraries, e.g. 'PAD Solina' or
        // 'BASS Growler'). All category keywords can be used as such a prefix. Additionally,
        // the following common abbreviations are recognized - only as a name prefix, since they
        // are too ambiguous for the contains-matching of the general detection (e.g. 'GRAN' is
        // contained in 'Grand' and 'ORG' in 'Forge').
        CATEGORY_PREFIX_LOOKUP.putAll (CATEGORY_LOOKUP);
        CATEGORY_PREFIX_LOOKUP.put ("BRAS", CATEGORY_BRASS);
        CATEGORY_PREFIX_LOOKUP.put ("DRM", CATEGORY_DRUM);
        CATEGORY_PREFIX_LOOKUP.put ("FLUT", CATEGORY_PIPE);
        CATEGORY_PREFIX_LOOKUP.put ("GRAN", CATEGORY_SYNTH);
        CATEGORY_PREFIX_LOOKUP.put ("ORG", CATEGORY_ORGAN);
        CATEGORY_PREFIX_LOOKUP.put ("PERC", CATEGORY_PERCUSSION);
        CATEGORY_PREFIX_LOOKUP.put ("PHYS", CATEGORY_SYNTH);
        CATEGORY_PREFIX_LOOKUP.put ("PLUK", CATEGORY_PLUCK);
        CATEGORY_PREFIX_LOOKUP.put ("POLY", CATEGORY_SYNTH);
        CATEGORY_PREFIX_LOOKUP.put ("REES", CATEGORY_BASS);
        CATEGORY_PREFIX_LOOKUP.put ("STRG", CATEGORY_STRINGS);
        CATEGORY_PREFIX_LOOKUP.put ("SWEP", CATEGORY_SYNTH);
        CATEGORY_PREFIX_LOOKUP.put ("VOC", CATEGORY_VOCAL);

        Arrays.asList (KEYWORDS).forEach (value -> KEYWORD_LOOKUP.put (value.toUpperCase (Locale.US), value));

        // Normalize and sort words by descending length for camel case method
        final List<String> words = new ArrayList<> ();
        words.addAll (CATEGORY_LOOKUP.values ());
        Collections.addAll (words, KEYWORDS);
        for (final String w: words)
            WORD_DICT.add (w.toUpperCase (Locale.ROOT));
        WORD_DICT.sort ((a, b) -> Integer.compare (b.length (), a.length ()));
    }


    /**
     * Constructor.
     */
    private TagDetector ()
    {
        // Intentionally empty
    }


    /**
     * Checks if the given label is one of the CATEGORY_* constants. If not detectCategory is called
     * on the label to find one.
     *
     * @param categoryLabel The label for which to get one of the default categories
     * @return The normalized category
     */
    public static String normalizeCategory (final String categoryLabel)
    {
        if (CATEGORIES.keySet ().contains (categoryLabel))
            return categoryLabel;
        return detectCategory (Collections.singletonList (categoryLabel));
    }


    /**
     * Detect a category in the given strings.
     *
     * @param texts The texts
     * @return The detected tag
     */
    public static String detectCategory (final String [] texts)
    {
        return detectCategory (Arrays.asList (texts), false);
    }


    /**
     * Detect a category in the given strings.
     *
     * @param texts The texts
     * @param categoryFromNamePrefix If true, a category tag at the very start of one of the texts
     *            declares the category and takes precedence over keyword matches anywhere in the
     *            texts
     * @return The detected tag
     */
    public static String detectCategory (final String [] texts, final boolean categoryFromNamePrefix)
    {
        return detectCategory (Arrays.asList (texts), categoryFromNamePrefix);
    }


    /**
     * Detect a category in the given strings.
     *
     * @param texts The texts
     * @return The detected tag
     */
    public static String detectCategory (final Collection<String> texts)
    {
        return detectCategory (texts, false);
    }


    /**
     * Detect a category in the given strings.
     *
     * @param texts The texts
     * @param categoryFromNamePrefix If true, a category tag at the very start of one of the texts
     *            declares the category and takes precedence over keyword matches anywhere in the
     *            texts
     * @return The detected tag
     */
    public static String detectCategory (final Collection<String> texts, final boolean categoryFromNamePrefix)
    {
        if (categoryFromNamePrefix)
        {
            final Optional<String> category = detectCategoryByNamePrefix (texts);
            if (category.isPresent ())
                return category.get ();
        }
        return detect (texts, CATEGORY_LOOKUP, CATEGORY_UNKNOWN);
    }


    /**
     * Detect a category from a category tag at the very start of a text (e.g. 'PAD Solina' or 'BASS
     * Growler'). Such a prefix declares the intended category explicitly and therefore takes
     * precedence over keyword matches anywhere in the texts, which can otherwise win accidentally
     * (e.g. 'BELL Vibrato Strings' would be detected as Strings instead of Bell).
     *
     * @param texts The texts, the most specific (e.g. the preset name) first
     * @return The category or null if the first word of none of the texts is a category tag
     */
    private static Optional<String> detectCategoryByNamePrefix (final Collection<String> texts)
    {
        for (final String text: texts)
        {
            final String [] tokens = DELIMITER_PATTERN.split (text.trim ().toUpperCase (Locale.US));
            if (tokens.length > 1)
            {
                final String category = CATEGORY_PREFIX_LOOKUP.get (tokens[0]);
                if (category != null)
                    return Optional.of (category);
            }
        }
        return Optional.empty ();
    }


    /**
     * Detect keywords in the given strings.
     *
     * @param texts The texts
     * @return The detected keywords
     */
    public static String [] detectKeywords (final String [] texts)
    {
        return detectKeywords (Arrays.asList (texts));
    }


    /**
     * Detect keywords in the given strings. A keyword has to be a whole word of a text: 'arp' is
     * not a keyword of a harp, 'mpe' not one of a trumpet and 'harmonic' not one of a harmonica.
     * Words are separated by everything which is not a letter or a digit and by the case and digit
     * changes of a compound name: 'PPG_PadSlow3WaveWideST' has the words PPG, Pad, Slow, 3, Wave,
     * Wide and ST. A keyword of two words like 'osc_sync' matches two neighbouring words, 'Osc
     * Sync' as well as 'OscSync'.
     *
     * @param texts The texts
     * @return The detected keywords
     */
    public static String [] detectKeywords (final Collection<String> texts)
    {
        final Set<String> words = new HashSet<> ();
        for (final String text: texts)
        {
            final String [] textWords = WORD_SEPARATOR.split (text.trim ());
            for (int i = 0; i < textWords.length; i++)
            {
                final String word = textWords[i].toUpperCase (Locale.US);
                words.add (word);
                if (i > 0)
                    words.add (textWords[i - 1].toUpperCase (Locale.US) + "_" + word);
            }
        }

        final Set<String> keywords = new HashSet<> ();
        for (final Map.Entry<String, String> e: KEYWORD_LOOKUP.entrySet ())
            if (words.contains (e.getKey ()))
                keywords.add (e.getValue ());
        return keywords.toArray (new String [keywords.size ()]);
    }


    /**
     * Detect keywords in the texts of a multi-sample and in the names of the folders which contain
     * it. The texts, e.g. the name of the multi-sample, provide keywords as described in
     * {@link #detectKeywords(Collection)}. A folder name only provides keywords if it describes the
     * sound of its content, which means that all of its words are keywords or category names, like
     * 'Digital', 'Mono' or 'Analog Synths'. The name of a library usually is a title instead, which
     * does not describe the sound of each of its presets: 'Digital' in 'Espen Kraft The Digital
     * Collection Vol6 TAL Sampler Oberheim Matrix-12' is the name of a series of libraries, and the
     * Oberheim Matrix-12 is an analog synthesizer.
     *
     * @param texts The texts of the multi-sample itself, e.g. its name
     * @param folderNames The names of the folders which contain the multi-sample
     * @return The detected keywords
     */
    public static String [] detectKeywords (final Collection<String> texts, final Collection<String> folderNames)
    {
        return detectKeywords (addDescribingFolderNames (texts, folderNames));
    }


    /**
     * Detect a category in the texts of a multi-sample and in the names of the folders which
     * contain it. Like for the keywords (see {@link #detectKeywords(Collection, Collection)}) only
     * a folder name which describes the sound of its content takes part. The name of a library is a
     * title: 'Voice' in the folder 'Espen Kraft PX Vol 2 Digital Voices 43 patches SF2' made vocals
     * of 28 of its 43 presets, among them 'D-50 EP Classic' and 'D-50 Dry Organ'.
     *
     * @param texts The texts of the multi-sample itself, e.g. its name, the most specific first
     * @param folderNames The names of the folders which contain the multi-sample, the innermost
     *            first
     * @param categoryFromNamePrefix If true, a category tag at the very start of one of the texts
     *            declares the category and takes precedence over keyword matches anywhere in the
     *            texts
     * @return The detected category
     */
    public static String detectCategory (final Collection<String> texts, final Collection<String> folderNames, final boolean categoryFromNamePrefix)
    {
        return detectCategory (addDescribingFolderNames (texts, folderNames), categoryFromNamePrefix);
    }


    /**
     * Split a text into its words: everything which is not a letter or a digit separates them, as
     * well as the change from a lower to an upper case letter and the change between a letter and a
     * digit. A note name like 'c3' in the name of a sample therefore is not the Hammond C3.
     *
     * @param text The text to split
     * @return The words
     */
    public static String [] splitWords (final String text)
    {
        return WORD_SEPARATOR.split (text.trim ());
    }


    /**
     * Get the texts of a multi-sample followed by the names of the folders which contain it which
     * describe the sound of their content, see {@link #isDescription(String)}.
     *
     * @param texts The texts of the multi-sample itself
     * @param folderNames The names of the folders which contain the multi-sample
     * @return The texts and the describing folder names
     */
    private static List<String> addDescribingFolderNames (final Collection<String> texts, final Collection<String> folderNames)
    {
        final List<String> describingTexts = new ArrayList<> (texts);
        for (final String folderName: folderNames)
            if (isDescription (folderName))
                describingTexts.add (folderName);
        return describingTexts;
    }


    /**
     * Checks if a text consists of nothing but keywords and category names or their plurals, e.g.
     * 'Analog Synths' or 'Soft Basses'. Numbers are ignored, e.g. the one of '01 Soft Pads'.
     *
     * @param text The text to check
     * @return True if all words of the text are keywords or category names
     */
    private static boolean isDescription (final String text)
    {
        final String [] textWords = WORD_SEPARATOR.split (text.trim ());
        boolean skipNextWord = false;

        for (int i = 0; i < textWords.length; i++)
        {
            if (skipNextWord)
            {
                skipNextWord = false;
                continue;
            }

            final String word = textWords[i].toUpperCase (Locale.US);
            if (word.chars ().noneMatch (Character::isLetter) || isTag (word))
                continue;

            // Is it a two-word keyword?
            if (i + 1 < textWords.length && KEYWORD_LOOKUP.containsKey (word + "_" + textWords[i + 1].toUpperCase (Locale.US)))
            {
                skipNextWord = true;
                continue;
            }

            return false;
        }

        return true;
    }


    /**
     * Checks if a word is a keyword or a category name or the plural of one.
     *
     * @param word The word in upper case
     * @return True if it is a keyword or a category name
     */
    private static boolean isTag (final String word)
    {
        if (KEYWORD_LOOKUP.containsKey (word) || CATEGORY_LOOKUP.containsKey (word))
            return true;
        if (!word.endsWith ("S"))
            return false;
        final String singular = word.substring (0, word.length () - 1);
        if (KEYWORD_LOOKUP.containsKey (singular) || CATEGORY_LOOKUP.containsKey (singular))
            return true;
        return word.endsWith ("ES") && CATEGORY_LOOKUP.containsKey (word.substring (0, word.length () - 2));
    }


    /**
     * Detect a tag in the given strings.
     *
     * @param texts The texts
     * @param lookupTags The tag lookups
     * @param defaultTag The tag to return if none matched
     * @return The detected tag
     */
    public static String detect (final String [] texts, final String [] lookupTags, final String defaultTag)
    {
        if (lookupTags == null)
            return defaultTag;

        final Map<String, String> lookupMap = new TreeMap<> (new StringLengthComparator ());
        Arrays.asList (lookupTags).forEach (value -> lookupMap.put (value.toUpperCase (Locale.US), value));

        for (final String text: texts)
        {
            final String t = text.toUpperCase (Locale.US);
            for (final Map.Entry<String, String> e: lookupMap.entrySet ())
                if (t.contains (e.getKey ()))
                    return e.getValue ();
        }
        return defaultTag;
    }


    /**
     * Detect a tag in the given strings.
     *
     * @param texts The texts
     * @param lookupMap The map with the tag lookups
     * @param defaultTag The tag to return if none matched
     * @return The detected tag
     */
    public static String detect (final String [] texts, final Map<String, String> lookupMap, final String defaultTag)
    {
        if (texts == null)
            return defaultTag;
        return detect (Arrays.asList (texts), lookupMap, defaultTag);
    }


    /**
     * Detect a tag in the given strings.
     *
     * @param texts The texts
     * @param lookupMap The map with the tag lookups
     * @param defaultTag The tag to return if none matched
     * @return The detected tag
     */
    public static String detect (final Collection<String> texts, final Map<String, String> lookupMap, final String defaultTag)
    {
        final Map<String, String> results = new HashMap<> ();
        for (final String text: texts)
        {
            final String t = text.toUpperCase (Locale.US);
            for (final Map.Entry<String, String> e: lookupMap.entrySet ())
            {
                final String key = e.getKey ();
                if (t.contains (key))
                    results.put (key, e.getValue ());
            }
        }
        if (results.isEmpty ())
            return defaultTag;
        return Collections.max (results.entrySet (), (entry1, entry2) -> entry1.getKey ().length () - entry2.getKey ().length ()).getValue ();
    }


    /**
     * Comparator to sort by the longest text first.
     */
    static class StringLengthComparator implements Comparator<String>
    {
        /** {@inheritDoc}} */
        @Override
        public int compare (final String s1, final String s2)
        {
            final int diff = s2.length () - s1.length ();
            return diff == 0 ? s1.compareTo (s2) : diff;
        }
    }


    /**
     * Creates camel case from the given input string. All categories and keywords are considered
     * for upper-case.
     *
     * @param input The input string
     * @return The output string in camel case notation
     */
    public static String toCamelCase (final String input)
    {
        if (input == null || input.isEmpty ())
            return input;

        final StringBuilder out = new StringBuilder ();
        final String s = input.toUpperCase (Locale.ROOT);

        int i = 0;
        while (i < s.length ())
        {
            boolean matched = false;

            for (final String w: WORD_DICT)
                if (s.startsWith (w, i))
                {
                    out.append (capitalize (w));
                    i += w.length ();
                    matched = true;
                    break;
                }

            if (!matched)
            {
                // Fallback: single character
                out.append (Character.toLowerCase (s.charAt (i)));
                i++;
            }
        }

        // Ensure first character is upper case
        out.setCharAt (0, Character.toUpperCase (out.charAt (0)));
        return out.toString ();
    }


    private static String capitalize (final String w)
    {
        return w.substring (0, 1) + w.substring (1).toLowerCase (Locale.ROOT);
    }
}
